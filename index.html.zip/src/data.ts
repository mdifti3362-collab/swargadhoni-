import { IslamicItem, SectionNames, InfoTexts } from './types';

export const INITIAL_SECTIONS: string[] = ['hamd', 'nat', 'gazal', 'mankabat'];

export const INITIAL_SECTION_NAMES: SectionNames = {
  hamd: {
    bn: 'হামদ',
    en: 'Hamd'
  },
  nat: {
    bn: 'নাত',
    en: 'Nat'
  },
  gazal: {
    bn: 'গজল',
    en: 'Gazal'
  },
  mankabat: {
    bn: 'মানকাবাত',
    en: 'Mankabat'
  }
};

export const INITIAL_ITEMS: IslamicItem[] = [
  {
    id: '1',
    title: 'আল্লাহ ওগো আল্লাহ তুমি দয়ার সাগর',
    category: 'hamd',
    mediaType: 'both',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    lyrics: `আল্লাহ ওগো আল্লাহ তুমি দয়ার সাগর,
রহমতেরই আকাশ তোমার ক্ষমার নাইকো শেষ।
কুল মাখলুক গেয়ে চলে তোমার গুনগান,
তুমি এক ও অদ্বিতীয় হে মহান রহমান।

চাঁদ সুরুজ আর গ্রহ তারা তোমার হুকুমে চলে,
সাগর নদী পাহাড় পর্বত সেজদা করে ঢলে।
আমায় তুমি ক্ষমা করো ওগো ক্বাদির খোদা,
যেন সদা জপতে পারি তোমার নামের সুধা।`
  },
  {
    id: '2',
    title: 'তুমি রহিম তুমি রহমান আল্লাহু আল্লাহ',
    category: 'hamd',
    mediaType: 'both',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    lyrics: `তুমি রহিম তুমি রহমান আল্লাহু আল্লাহ,
তোমার দয়ার নাইকো শেষ ইয়া রব্বানা।
পাপের সাগরে আমি ডুবে আছি সারাক্ষণ,
তোমার দয়া ছাড়া নাহি কোনো পরিত্রাণ।

নূরের চাদরে ঢাকা তোমার আরশে আযিম,
ক্ষমা করে দাও মোরে রহমানুর রহিম।
তোমার প্রেমে আকুল হোক আমার এই মন,
ধন্য করো হে প্রভু আমার এ জীবন।`
  },
  {
    id: '3',
    title: 'মদিনারই ধূলিবালি সোনার চেয়ে খাঁটি',
    category: 'nat',
    mediaType: 'both',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    lyrics: `মদিনারই ধূলিবালি সোনার চেয়ে খাঁটি,
সেথায় শুয়ে আছেন মোদের দয়াল নবীজী।
আকুল হয়ে ডাকে মন হিজরতেরই কূলে,
কবে যাবো মদিনাতে সব বেদনা ভুলে।

ইয়া রাসূলুল্লাহ্ দয়া করো এই পাপী বান্দারে,
তোমার শাফায়াত যেন পাই হাশরের ময়দানে।
সবুজ গম্বুজ দেখার লাগি মন কাদে দিবা-রজনী,
সালাম জানাই দূর হতে হে দয়ার খনি।`
  },
  {
    id: '4',
    title: 'ইয়া নবী সালাম আলাইকা',
    category: 'nat',
    mediaType: 'both',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    lyrics: `ইয়া নবী সালাম আলাইকা,
ইয়া রাসূল সালাম আলাইকা।
ইয়া হাবীব সালাম আলাইকা,
সালাওয়াতুল্লাহ্ আলাইকা।

উদ্বেলিত হৃদয় মোদের তোমার প্রেমে ধন্য,
সৃষ্টির এই নিখিল জাহান শুধু তোমার জন্য।
ইয়া শাফিউল মুযনিবীন দয়া করো মোরে,
স্থান দিও ঠাঁই তোমার জান্নাতেরই ঘরে।`
  },
  {
    id: '5',
    title: 'তুমি আসবে বলে হে রাসুল',
    category: 'gazal',
    mediaType: 'lyrics',
    lyrics: `তুমি আসবে বলে হে রাসুল,
ফুটলো বনে কতো শত সুরভিত ফুল।
পাখিরা গাহিল গান নদী বয়ে যায়,
ধরণী মাতোয়ারা হলো তোমারি সুবাসে।

মরুর বুকে খেলে গেলো খুশির জোয়ার,
খুলে গেলো রহমতের আটটি ও দুয়ার।
হে নূরে মুজাসসাম তুমি দয়ার আধার,
তোমার প্রেমে ধন্য হোক হৃদয় আমার।`
  },
  {
    id: '6',
    title: 'মেরে পীর তৈয়ব শাহা তৈয়ব শাহা',
    category: 'mankabat',
    mediaType: 'both',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    lyrics: `মেরে পীর তৈয়ব শাহা তৈয়ব শাহা,
তোমার স্মরণে মনে জাগে কতো আশা।
আল্লামা ছৈয়দ তৈয়ব শাহ্ মোদের রাহবার,
সিলসিলায়ে আলিয়া কাদেরিয়া সিলসিলা মোদের।

দ্বীনের আলো ছড়িয়েছ তুমি বাংলার বুকে,
পাগল তোমায় ডাকে সদা পরম সুখে।
ক্বাদেরীয়া তরীকার আলোকবর্তিকা তুমি,
ধন্য হলো তোমার পদধূলিতে এই বঙ্গভূমি।`
  }
];

export const INITIAL_INFO_TEXTS: InfoTexts = {
  utsarga: {
    bn: 'পবিত্র মদিনা শরীফ ও সকল রাসুলপ্রেমীদের প্রতি উৎসর্গিত।\nবিশেষভাবে উৎসর্গ করা হলো আল্লামা ছৈয়দ মুহাম্মদ তৈয়ব শাহ্ (রহ.) এবং আহলে বায়তে রাসুল ও গাউসুল আজম দস্তগীর বড়পীর আব্দুল কাদের জিলানী (রা.)-এর স্মরণে।',
    en: 'Dedicated to Holy Medina Sharif and all lovers of the Prophet (Peace Be Upon Him).\nSpecially dedicated in memory of Allama Syeda Muhammad Tayyab Shah (R.A.), the Holy Household (Ahl al-Bayt), and Ghausul Azam Abdul Qadir Jilani (R.A.).'
  },
  lekhok: {
    bn: 'গজল ও নাত সংকলক:\nসৈয়্যদ মুহাম্মদ এহসান কাদের কাদেরী\nপ্রখ্যাত ইসলামি ব্যক্তিত্ব, বিশিষ্ট গবেষক ও ধর্মপ্রাণ সংকলক। দ্বীনি সাহিত্য প্রচার ও হামদ-নাত চর্চায় তাঁর অবদান অপরিসীম।',
    en: 'Compiler of Ghazals and Naats:\nSyed Muhammad Ehsan Qader Qaderi\nFamous Islamic scholar, writer and researcher, who has contributed immensely to Islamic literature and devotional songs.',
    photoUrl: 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=400&auto=format&fit=crop&q=80'
  },
  developer: {
    bn: 'মোহাম্মদ ইমতিয়াজ হোসেন ইফতি\nপ্রধান সফটওয়্যার ইঞ্জিনিয়ার\n📧 mdifti3362@gmail.com\n📞 +৮৮০১_ _ _ _ _ _ _ _',
    en: 'Mohammed Imteaz Hossen Ifti\nLead Software Engineer\n📧 mdifti3362@gmail.com\n📞 +8801_ _ _ _ _ _ _ _',
    photoUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&auto=format&fit=crop&q=80',
    facebookUrl: 'https://www.facebook.com/mdifti3362'
  },
  facebookUrl: 'https://www.facebook.com/',
  appTitleBn: 'স্বর্গধ্বনি',
  appTitleEn: 'Swargadhoni',
  appLogo: '🎵',
  contactPhone: '+8801825316492',
  contactWhatsapp: 'https://wa.me/8801825316492',
  contactFacebook: 'https://www.facebook.com/swargadhoni',
  showContactBar: true
};

export const TRANSLATIONS = {
  bn: {
    title: 'স্বর্গধ্বনি',
    subtitle: 'হামদ, নাত, গজল ও মানকাবাত সংগ্রহ',
    author: 'সংকলক - সৈয়্যদ মুহাম্মদ এহসান কাদের কাদেরী',
    searchPlaceholder: 'হামদ, নাত, গজল, মানকাবাত সার্চ করুন...',
    all: 'সব',
    online: 'অনলাইন',
    offline: 'অফলাইন',
    utsarga: '🙏 উৎসর্গ',
    lekhok: '📝 সংকলকের তথ্য',
    adminPanel: '👑 এডমিন প্যানেল',
    lyrics: 'রিলিক্স',
    video: 'ভিডিও',
    both: 'ভিডিও + রিলিক্স',
    close: 'বন্ধ করুন',
    noItems: '🔍 কিছু পাওয়া যায়নি',
    lyricsTitle: 'গানের কথা',
    videoLink: '🎬 ইউটিউব ভিডিও লিংক',
    watch: 'দেখুন',
    noVideo: '⚠️ ভিডিও লিংক নেই',
    adminLogin: '🔐 এডমিন লগইন',
    adminPassword: 'পাসওয়ার্ড লিখুন',
    loginBtn: 'প্রবেশ করুন',
    wrongPassword: '❌ ভুল পাসওয়ার্ড!',
    adminControl: '⚙️ এডমিন কন্ট্রোল প্যানেল',
    tabInfo: '📝 তথ্য',
    tabAdd: '➕ নতুন যোগ',
    tabList: '📋 লিস্ট',
    tabSection: '📑 সেকশন',
    tabTheme: '🎨 থিম',
    themeLabel: '🎨 অ্যাপ্লিকেশনের রঙ থিম নির্বাচন করুন',
    themeDivineEmerald: '🌿 বাহারে মদিনা (সবুজ ও সোনালী)',
    themeRoyalIndigo: '🌌 শাহে মদিনা (নীল ও সোনালী)',
    themeCrimsonGlow: '🥀 খুনে মদিনা (লাল ও ব্রোঞ্জ)',
    themeMidnightCharcoal: '🪵 নূরের তাজ (ধূসর ও রূপালী)',
    themeMysticViolet: '🔮 আশেকে রাসুল (বেগুনী ও মেজেন্টা)',
    themeSaved: '✅ থিম সফলভাবে পরিবর্তন করা হয়েছে!',
    utsargaLabel: '🙏 উৎসর্গ টেক্সট',
    lekhokLabel: '📝 সংকলকের তথ্য',
    developerLabel: '👨‍💻 ডেভেলপার তথ্য',
    facebookLabel: '📘 ফেসবুক আইডি লিংক',
    developerPhotoLabel: '👨‍💻 ডেভেলপারের ছবি (লিংক অথবা আপলোড করুন)',
    authorPhotoLabel: '📝 সংকলকের ছবি (লিংক অথবা আপলোড করুন)',
    devFacebookLabel: '📘 ডেভেলপারের ফেসবুক প্রোফাইল লিংক',
    gallerySelect: '🖼️ ছবি গ্যালারি থেকে নির্বাচন করুন:',
    uploadOrClick: 'ফাইল সিলেক্ট করতে এখানে ক্লিক করুন অথবা ড্রাগ করে ড্রপ করুন',
    saveBtn: '💾 তথ্য সংরক্ষণ করুন',
    savedSuccess: '✅ সফলভাবে সংরক্ষিত হয়েছে!',
    categoryLabel: 'বিভাগ নির্বাচন',
    mediaTypeLabel: 'মিডিয়া ধরন',
    titleLabel: 'শিরোনাম',
    videoUrlLabel: 'ইউটিউব ভিডিও লিংক',
    lyricsLabel: 'রিলিক্স টেক্সট',
    addBtn: '➕ আইটেম যোগ করুন',
    addedSuccess: '✅ সফলভাবে যোগ করা হয়েছে!',
    editTitle: 'নতুন শিরোনাম লিখুন:',
    editVideoUrl: 'নতুন ভিডিও লিংক লিখুন:',
    editLyrics: 'নতুন রিলিক্স লিখুন:',
    deleteConfirm: 'আপনি কি নিশ্চিতভাবে মুছে ফেলতে চান?',
    facebookLink: '📘 ফেসবুকে সংকলক',
    createdBy: 'created by Mohammed Imteaz Hossen Ifti',
    currentSections: 'বর্তমান সেকশনসমূহ',
    sectionIdLabel: 'সেকশন আইডি:',
    deleteSectionConfirm: 'এই সেকশনটি মুছলে এর ভেতরের সকল লেখা মুছে যাবে। আপনি কি নিশ্চিত?',
    newSectionName: 'নতুন সেকশনের নাম',
    addSectionBtn: '➕ নতুন সেকশন যোগ করুন',
    sectionAdded: '✅ নতুন সেকশন যোগ করা হয়েছে!',
    fillFields: 'দয়া করে প্রয়োজনীয় ফিল্ডগুলো পূরণ করুন!',
    lyricsOnly: 'শুধু রিলিক্স',
    videoOnly: 'শুধু ভিডিও',
    share: 'শেয়ার',
    shareSuccess: '✅ শেয়ার লিংক এবং লিরিক্স ক্লিপবোর্ডে কপি করা হয়েছে!',
    shareDeviceTitle: 'স্বর্গধ্বনি একাডেমি'
  },
  en: {
    title: 'Swargadhoni',
    subtitle: 'Collection of Hamd, Nat, Ghazal & Mankabat',
    author: 'Author - Syed Muhammad Ehsan Qader Qaderi',
    searchPlaceholder: 'Search Hamd, Nat, Ghazal, Mankabat...',
    all: 'All',
    online: 'Online',
    offline: 'Offline',
    utsarga: '🙏 Dedication',
    lekhok: '📝 Author Info',
    adminPanel: '👑 Admin Panel',
    lyrics: 'Lyrics',
    video: 'Video',
    both: 'Video & Lyrics',
    close: 'Close',
    noItems: '🔍 No matches found',
    lyricsTitle: 'Lyrics',
    videoLink: '🎬 YouTube Video Link',
    watch: 'Watch',
    noVideo: '⚠️ No Video Available',
    adminLogin: '🔐 Admin Login',
    adminPassword: 'Enter password',
    loginBtn: 'Login',
    wrongPassword: '❌ Incorrect Password!',
    adminControl: '⚙️ Admin Control Panel',
    tabInfo: '📝 Info',
    tabAdd: '➕ Add Item',
    tabList: '📋 List',
    tabSection: '📑 Sections',
    tabTheme: '🎨 Theme',
    themeLabel: '🎨 Select Application Color Theme',
    themeDivineEmerald: '🌿 Divine Emerald (Green & Gold)',
    themeRoyalIndigo: '🌌 Royal Indigo (Blue & Gold)',
    themeCrimsonGlow: '🥀 Crimson Glow (Red & Bronze)',
    themeMidnightCharcoal: '🪵 Midnight Charcoal (Slate & Silver)',
    themeMysticViolet: '🔮 Mystic Violet (Purple & Magenta)',
    themeSaved: '✅ Theme successfully updated!',
    utsargaLabel: '🙏 Dedication Text',
    lekhokLabel: '📝 Author Information',
    developerLabel: '👨‍💻 Developer Information',
    facebookLabel: '📘 Facebook URL',
    developerPhotoLabel: '👨‍💻 Developer Photo (URL or Upload)',
    authorPhotoLabel: '📝 Author Photo (URL or Upload)',
    devFacebookLabel: '📘 Developer Facebook URL / ID',
    gallerySelect: '🖼️ Choose from Gallery Presets:',
    uploadOrClick: 'Click to select or drag & drop image here',
    saveBtn: '💾 Save Information',
    savedSuccess: '✅ Successfully Saved!',
    categoryLabel: 'Select Category',
    mediaTypeLabel: 'Media Type',
    titleLabel: 'Title',
    videoUrlLabel: 'YouTube Video URL',
    lyricsLabel: 'Lyrics Text',
    addBtn: '➕ Add Islamic Medley',
    addedSuccess: '✅ Successfully Added!',
    editTitle: 'Enter new title:',
    editVideoUrl: 'Enter new video URL:',
    editLyrics: 'Enter new lyrics:',
    deleteConfirm: 'Are you sure you want to delete this item?',
    facebookLink: '📘 Author on Facebook',
    createdBy: 'created by Mohammed Imteaz Hossen Ifti',
    currentSections: 'Current Sections',
    sectionIdLabel: 'Section ID:',
    deleteSectionConfirm: 'Deleting this section will remove all its items. Are you sure?',
    newSectionName: 'New Section Name',
    addSectionBtn: '➕ Add New Section',
    sectionAdded: '✅ Section Added Successfully!',
    fillFields: 'Please fill in all required fields!',
    lyricsOnly: 'Lyrics Only',
    videoOnly: 'Video Only',
    share: 'Share',
    shareSuccess: '✅ Share link and lyrics successfully copied to clipboard!',
    shareDeviceTitle: 'Swargadhoni Academy'
  }
};

export interface AppThemeConfig {
  id: string;
  nameBn: string;
  nameEn: string;
  primaryBg: string;
  viaBg: string;
  toBg: string;
  cardBg: string;
  cardBorder: string;
  headerBg: string;
  headerBorder: string;
  headerHover: string;
  glowLeft: string;
  glowRight: string;
  accentText: string;
  accentBg: string;
  accentBorder: string;
  badgeBgFrom: string;
  badgeBgTo: string;
  footerBg: string;
  footerBorder: string;
  modalFrom: string;
  modalTo: string;
  modalBtnHover: string;
  navbarBorder: string;
  navbarBg: string;
}

export const PHYSICAL_THEMES: AppThemeConfig[] = [
  {
    id: 'emerald',
    nameBn: '🌿 বাহারে মদিনা (সবুজ ও সোনালী)',
    nameEn: '🌿 Divine Emerald (Green & Gold)',
    primaryBg: '#011613',
    viaBg: '#010e0c',
    toBg: '#010807',
    cardBg: 'rgba(2, 44, 36, 0.35)',
    cardBorder: 'rgba(16, 185, 129, 0.15)',
    headerBg: 'rgba(3, 46, 39, 0.5)',
    headerBorder: 'rgba(16, 185, 129, 0.1)',
    headerHover: 'rgba(3, 46, 39, 0.7)',
    glowLeft: 'rgba(16, 185, 129, 0.05)',
    glowRight: 'rgba(245, 158, 11, 0.04)',
    accentText: '#fcd34d',
    accentBg: 'rgba(245, 158, 11, 0.04)',
    accentBorder: 'rgba(245, 158, 11, 0.15)',
    badgeBgFrom: '#f59e0b',
    badgeBgTo: '#fcd34d',
    footerBg: '#010e0c',
    footerBorder: 'rgba(16, 185, 129, 0.12)',
    modalFrom: '#012d25',
    modalTo: '#011411',
    modalBtnHover: '#011e19',
    navbarBorder: 'rgba(245, 158, 11, 0.2)',
    navbarBg: 'rgba(1, 22, 19, 0.95)',
  },
  {
    id: 'indigo',
    nameBn: '🌌 শাহে মদিনা (নীল ও সোনালী)',
    nameEn: '🌌 Royal Indigo (Blue & Gold)',
    primaryBg: '#040717',
    viaBg: '#02040c',
    toBg: '#010103',
    cardBg: 'rgba(9, 14, 45, 0.45)',
    cardBorder: 'rgba(99, 102, 241, 0.2)',
    headerBg: 'rgba(12, 17, 55, 0.6)',
    headerBorder: 'rgba(99, 102, 241, 0.12)',
    headerHover: 'rgba(12, 17, 55, 0.8)',
    glowLeft: 'rgba(99, 102, 241, 0.06)',
    glowRight: 'rgba(245, 158, 11, 0.05)',
    accentText: '#f6e05e',
    accentBg: 'rgba(245, 158, 11, 0.05)',
    accentBorder: 'rgba(245, 158, 11, 0.2)',
    badgeBgFrom: '#d97706',
    badgeBgTo: '#f6e05e',
    footerBg: '#02040c',
    footerBorder: 'rgba(99, 102, 241, 0.15)',
    modalFrom: '#070d28',
    modalTo: '#020410',
    modalBtnHover: '#0b1038',
    navbarBorder: 'rgba(245, 158, 11, 0.25)',
    navbarBg: 'rgba(4, 7, 23, 0.95)',
  },
  {
    id: 'crimson',
    nameBn: '🥀 খুনে মদিনা (লাল ও ব্রোঞ্জ)',
    nameEn: '🥀 Crimson Glow (Red & Bronze)',
    primaryBg: '#130306',
    viaBg: '#0b0103',
    toBg: '#040001',
    cardBg: 'rgba(42, 4, 10, 0.38)',
    cardBorder: 'rgba(239, 68, 68, 0.18)',
    headerBg: 'rgba(52, 5, 12, 0.52)',
    headerBorder: 'rgba(239, 68, 68, 0.1)',
    headerHover: 'rgba(52, 5, 12, 0.7)',
    glowLeft: 'rgba(239, 68, 68, 0.05)',
    glowRight: 'rgba(217, 119, 6, 0.04)',
    accentText: '#fca5a5',
    accentBg: 'rgba(239, 68, 68, 0.04)',
    accentBorder: 'rgba(239, 68, 68, 0.18)',
    badgeBgFrom: '#dc2626',
    badgeBgTo: '#fca5a5',
    footerBg: '#0b0103',
    footerBorder: 'rgba(239, 68, 68, 0.12)',
    modalFrom: '#29040a',
    modalTo: '#100003',
    modalBtnHover: '#1a0206',
    navbarBorder: 'rgba(239, 68, 68, 0.2)',
    navbarBg: 'rgba(19, 3, 6, 0.95)',
  },
  {
    id: 'violet',
    nameBn: '🔮 আশেকে রাসুল (বেগুনী ও মেজেন্টা)',
    nameEn: '🔮 Mystic Violet (Purple & Magenta)',
    primaryBg: '#0c0419',
    viaBg: '#06010e',
    toBg: '#020005',
    cardBg: 'rgba(26, 8, 52, 0.42)',
    cardBorder: 'rgba(16, 185, 129, 0.15)', // fallback setup
    headerBg: 'rgba(34, 10, 68, 0.52)',
    headerBorder: 'rgba(168, 85, 247, 0.1)',
    headerHover: 'rgba(34, 10, 68, 0.72)',
    glowLeft: 'rgba(168, 85, 247, 0.06)',
    glowRight: 'rgba(232, 121, 249, 0.04)',
    accentText: '#e9d5ff',
    accentBg: 'rgba(168, 85, 247, 0.04)',
    accentBorder: 'rgba(168, 85, 247, 0.18)',
    badgeBgFrom: '#8b5cf6',
    badgeBgTo: '#d8b4fe',
    footerBg: '#06010e',
    footerBorder: 'rgba(168, 85, 247, 0.12)',
    modalFrom: '#190830',
    modalTo: '#070210',
    modalBtnHover: '#110421',
    navbarBorder: 'rgba(168, 85, 247, 0.22)',
    navbarBg: 'rgba(12, 4, 25, 0.95)',
  },
  {
    id: 'charcoal',
    nameBn: '🪵 নূরের তাজ (ধূসর ও রূপালী)',
    nameEn: '🪵 Midnight Charcoal (Slate & Silver)',
    primaryBg: '#0e1014',
    viaBg: '#07080b',
    toBg: '#030304',
    cardBg: 'rgba(24, 27, 34, 0.52)',
    cardBorder: 'rgba(148, 163, 184, 0.2)',
    headerBg: 'rgba(30, 34, 43, 0.62)',
    headerBorder: 'rgba(148, 163, 184, 0.1)',
    headerHover: 'rgba(30, 34, 43, 0.8)',
    glowLeft: 'rgba(148, 163, 184, 0.05)',
    glowRight: 'rgba(245, 158, 11, 0.04)',
    accentText: '#cbd5e1',
    accentBg: 'rgba(148, 163, 184, 0.04)',
    accentBorder: 'rgba(148, 163, 184, 0.18)',
    badgeBgFrom: '#64748b',
    badgeBgTo: '#cbd5e1',
    footerBg: '#07080b',
    footerBorder: 'rgba(148, 163, 184, 0.12)',
    modalFrom: '#181b22',
    modalTo: '#0b0c10',
    modalBtnHover: '#101217',
    navbarBorder: 'rgba(148, 163, 184, 0.22)',
    navbarBg: 'rgba(14, 16, 20, 0.95)',
  },
  {
    id: 'white',
    nameBn: '⚪ নূরানী সাদা (উজ্জ্বল ও শান্ত)',
    nameEn: '⚪ Nurani White (Light & Peaceful)',
    primaryBg: '#fafafa',
    viaBg: '#f4f4f5',
    toBg: '#e4e4e7',
    cardBg: 'rgba(255, 255, 255, 0.95)',
    cardBorder: 'rgba(228, 228, 231, 1)',
    headerBg: 'rgba(244, 244, 245, 0.95)',
    headerBorder: 'rgba(228, 228, 231, 0.9)',
    headerHover: 'rgba(228, 228, 231, 0.95)',
    glowLeft: 'rgba(24, 24, 27, 0.04)',
    glowRight: 'rgba(245, 158, 11, 0.03)',
    accentText: '#0f172a',
    accentBg: 'rgba(15, 23, 42, 0.05)',
    accentBorder: 'rgba(15, 23, 42, 0.1)',
    badgeBgFrom: '#27272a',
    badgeBgTo: '#52525b',
    footerBg: '#f4f4f5',
    footerBorder: 'rgba(228, 228, 231, 1)',
    modalFrom: '#ffffff',
    modalTo: '#fafafa',
    modalBtnHover: '#f4f4f5',
    navbarBorder: 'rgba(228, 228, 231, 0.8)',
    navbarBg: 'rgba(255, 255, 255, 0.98)',
  }
];


