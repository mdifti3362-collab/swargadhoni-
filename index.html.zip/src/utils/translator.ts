/**
 * Comprehensive translation and phonetical transliteration library for Bengali to English.
 * Ensures that if English is selected, not a single word of Bengali remains in certificates or display names.
 */

// Dictionary mapping common Bengali terms to standard English terms
const BANGLA_DICTIONARY: Record<string, string> = {
  'সব': 'All',
  'অনলাইন': 'Online',
  'অফলাইন': 'Offline',
  'রিলিক্স': 'Lyrics',
  'ভিডিও': 'Video',
  'বন্ধ করুন': 'Close',
  'গানের কথা': 'Lyrics',
  'ইউটিউব ভিডিও লিংক': 'YouTube Video Link',
  'স্বর্গধ্বনি': 'Swargadhoni',
  'একাডেমি': 'Academy',
  'একাডেমী': 'Academy',
  'ইসলামি': 'Islamic',
  'ইসলামী': 'Islamic',
  'সংগীত': 'Music',
  'সঙ্গীত': 'Music',
  'চর্চা': 'Practice',
  'কেন্দ্র': 'Center',
  'সনদ': 'Certificate',
  'সনদপত্র': 'Certificate',
  'কোর্স': 'Course',
  'পরীক্ষা': 'Examination',
  'হিফজ': 'Hifz',
  'হিফজুল': 'Hifzul',
  'কুরআন': 'Quran',
  'আল-কুরআন': 'Al-Quran',
  'কোরআন': 'Quran',
  'হামদ': 'Hamd',
  'নাত': 'Naat',
  'গজল': 'Ghazal',
  'মানকাবাত': 'Mankabat',
  'অ্যাওয়ার্ড': 'Award',
  'পুরস্কার': 'Award',
  'সফলতার': 'Success',
  'সাফল্যের': 'Success',
  'যোগ্যতাপত্র': 'Accolade',
  'মানপত্র': 'Certificate of Honor',
  'কর্তৃপক্ষ': 'Authority',
  'স্বাক্ষর': 'Signature',
  'ইস্যু': 'Issue',
  'তারিখ': 'Date',
  'শ্রেণী': 'Class',
  'শ্রেণি': 'Class',
  'গ্রুপ': 'Group',
  'বিভাগ': 'Department',
  'বোর্ড': 'Board',
  'উপস্থিতি': 'Attendance',
  'ফলাফল': 'Result',
  'জিপিএ': 'GPA',
  'গ্রেড': 'Grade',
  'নাম': 'Name',
  'পিতা': 'Father',
  'মাতা': 'Mother',
  'মোবাইল': 'Mobile',
  'ঠিকানা': 'Address',
  'সৈয়্যদ': 'Syed',
  'সৈয়দ': 'Syed',
  'মুহাম্মদ': 'Muhammad',
  'মোহাম্মদ': 'Mohammad',
  'আহমদ': 'Ahmad',
  'আহমেদ': 'Ahmed',
  'হাসান': 'Hasan',
  'হোসেন': 'Hossen',
  'হোসাইন': 'Hossain',
  'আলী': 'Ali',
  'কাদেরী': 'Qaderi',
  'ক্বাদেরী': 'Qaderi',
  'এহসান': 'Ehsan',
  'তৈয়্যব': 'Tayyab',
  'শাহ': 'Shah',
  'শাহ্': 'Shah',
  'আল্লামা': 'Allama',
  'হযরত': 'Hazrat',
  'হজরত': 'Hazrat',
  'মাওলানা': 'Maulana',
  'মুফতি': 'Mufti',
  'হাফেজ': 'Hafez',
  'হাফেয': 'Hafez',
  'ক্বারী': 'Qari',
  'খতিব': 'Khatib',
  'ইমাম': 'Imam',
  'মুহাদ্দিস': 'Muhaddis',
  'গবেষক': 'Researcher',
  'লেখক': 'Author',
  'উৎসর্গ': 'Dedication',
  'পবিত্র': 'Holy',
  'মদিনা': 'Medina',
  'শরীফ': 'Sharif',
  'রাসুলপ্রেমীদের': 'Prophet Lovers',
  'আহলে': 'Ahl',
  'বায়তে': 'Bayt',
  'গাউসুল': 'Ghausul',
  'আজম': 'Azam',
  'বড়পীর': 'Baropir',
};

// Character lookup mapping for phonetical transliteration of Bengali letters
const CHAR_MAP: Record<string, string> = {
  // Vowels
  'অ': 'o', 'আ': 'a', 'ই': 'i', 'ঈ': 'i', 'উ': 'u', 'ঊ': 'u', 'ঋ': 'ri', 'এ': 'e', 'ঐ': 'oi', 'ও': 'o', 'ঔ': 'ou',
  // Consonants
  'ক': 'k', 'খ': 'kh', 'গ': 'g', 'ঘ': 'gh', 'ঙ': 'ng',
  'চ': 'ch', 'ছ': 'chh', 'জ': 'j', 'ঝ': 'jh', 'ঞ': 'n',
  'ট': 't', 'ঠ': 'th', 'ড': 'd', 'ঢ': 'dh', 'ণ': 'n',
  'ত': 't', 'থ': 'th', 'দ': 'd', 'ধ': 'dh', 'ন': 'n',
  'প': 'p', 'ফ': 'f', 'ব': 'b', 'ভ': 'v', 'ম': 'm',
  'য': 'z', 'র': 'r', 'ল': 'l', 'শ': 'sh', 'ষ': 'sh', 'স': 's', 'হ': 'h',
  'ড়': 'r', 'ঢ়': 'rh', 'য়': 'y', 'ৎ': 't',
  // Modifiers (Kars / Matras)
  'া': 'a', 'ি': 'i', 'ী': 'i', 'ু': 'u', 'ূ': 'u', 'ৃ': 'ri', 'ে': 'e', 'ৈ': 'oi', 'ো': 'o', 'ৌ': 'ou',
  'ক্‌': 'k', 'ং': 'ng', 'ঃ': 'h', 'ঁ': 'n', '্য': 'y', '্র': 'r', 'র্': 'r'
};

/**
 * Phonetically transliterates a Bengali word into English characters.
 */
function transliterateWord(word: string): string {
  // Clean special diacritics if any
  let cleanWord = word;
  
  // Try direct dictionary matching
  const directMatch = BANGLA_DICTIONARY[cleanWord];
  if (directMatch) return directMatch;
  
  // Replace sub-parts of words that contain mapped terms
  for (const [bnKey, enVal] of Object.entries(BANGLA_DICTIONARY)) {
    if (cleanWord === bnKey) {
      return enVal;
    }
  }

  let result = '';
  let i = 0;
  
  while (i < cleanWord.length) {
    const char = cleanWord[i];
    
    // Check double character modifiers like ref (র্)
    if (char === '্' && cleanWord[i + 1] === 'য') {
      result += 'y';
      i += 2;
      continue;
    }
    if (char === '্' && cleanWord[i + 1] === 'র') {
      result += 'r';
      i += 2;
      continue;
    }
    
    const en = CHAR_MAP[char];
    if (en !== undefined) {
      // Avoid raw trailing default 'o' for consonant if next letter is a modifier
      result += en;
    } else {
      // Handover non-bengali characters directly (e.g. latin text, punctuation, numbers)
      result += char;
    }
    i++;
  }
  
  // Clean up any double vowels or weird sound pairings
  return result
    .replace(/aa+/g, 'a')
    .replace(/ii+/g, 'i')
    .replace(/uu+/g, 'u')
    .replace(/o+a/g, 'oa')
    .replace(/yi/g, 'i')
    .replace(/sh+/g, 'sh');
}

/**
 * Parses full text to completely construct its English translation representation.
 * Loops through terms and outputs full parsed English tokens.
 */
export function translateToEnglish(text: string | undefined | null): string {
  if (!text) return '';
  
  // Split by line and preserve layout
  const lines = text.split('\n');
  const translatedLines = lines.map(line => {
    // Preserve layout and split by spaces, preserving punctuation
    const wordsAndPunct = line.split(/(\s+|[,.:;?!()\-\[\]{}])/g);
    
    const translatedTokens = wordsAndPunct.map(token => {
      if (!token) return '';
      // If it has spacing or punctuation, keep it
      if (token.trim() === '' || /^[`,.:;?!()\-\[\]{}]+$/.test(token)) {
        return token;
      }
      // If it contains only alphanumeric character/english/numerics, keep it
      if (/^[a-zA-Z0-9$@#%^&*_+=<>\\/]+$/.test(token)) {
        return token;
      }
      
      // Found a Bengali token! Transliterate or Translate it
      const result = transliterateWord(token);
      // Capitalize first letter beautifully
      if (result.length > 0) {
        return result.charAt(0).toUpperCase() + result.slice(1);
      }
      return token;
    });
    
    return translatedTokens.join('');
  });
  
  return translatedLines.join('\n');
}

/**
 * Safely converts numbers (digits) from Bengali to English.
 */
export function convertBengaliNumbers(str: string): string {
  const bnNums = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  let result = str;
  for (let i = 0; i < 10; i++) {
    result = result.replace(new RegExp(bnNums[i], 'g'), String(i));
  }
  return result;
}
