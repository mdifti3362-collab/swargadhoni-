import { initializeApp } from 'firebase/app';
import { getDatabase, ref, set } from 'firebase/database';
import { IslamicItem, SectionNames, InfoTexts, Student, PrayerTimesConfig, StatusBarConfig, AppNotification } from './types';

// Web app's Firebase configuration connecting directly to your Realtime Database
const firebaseConfig = {
  databaseURL: "https://sorgodoni-default-rtdb.asia-southeast1.firebasedatabase.app/"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);

/**
 * Synchronize items array to Firebase
 */
export async function saveItemsToFirebase(items: IslamicItem[]) {
  try {
    await set(ref(db, 'items'), items);
  } catch (err) {
    console.error("Error writing items to Firebase Realtime Database:", err);
  }
}

/**
 * Synchronize a single item/song to Firebase under its specific ID or index to prevent overwrite issues
 */
export async function saveSingleItemToFirebase(item: IslamicItem) {
  if (!item.id) return;
  try {
    await set(ref(db, `items/${item.id}`), item);
  } catch (err) {
    console.error(`Error writing single item ${item.id} to Firebase:`, err);
  }
}

/**
 * Delete a single item/song from Firebase
 */
export async function deleteItemFromFirebase(itemId: string) {
  if (!itemId) return;
  try {
    await set(ref(db, `items/${itemId}`), null);
  } catch (err) {
    console.error(`Error deleting single item ${itemId} from Firebase:`, err);
  }
}

/**
 * Synchronize sections array to Firebase
 */
export async function saveSectionsToFirebase(sections: string[]) {
  try {
    await set(ref(db, 'sections'), sections);
  } catch (err) {
    console.error("Error writing sections to Firebase Realtime Database:", err);
  }
}

/**
 * Synchronize section names mapping to Firebase
 */
export async function saveSectionNamesToFirebase(sectionNames: SectionNames) {
  try {
    await set(ref(db, 'sectionNames'), sectionNames);
  } catch (err) {
    console.error("Error writing sectionNames to Firebase Realtime Database:", err);
  }
}

/**
 * Synchronize authors research information to Firebase
 */
export async function saveInfoToFirebase(info: InfoTexts) {
  try {
    await set(ref(db, 'info'), info);
  } catch (err) {
    console.error("Error writing info to Firebase Realtime Database:", err);
  }
}

/**
 * Synchronize theme selection to Firebase
 */
export async function saveThemeToFirebase(themeId: string) {
  try {
    await set(ref(db, 'theme'), themeId);
  } catch (err) {
    console.error("Error writing theme to Firebase Realtime Database:", err);
  }
}

/**
 * Synchronize full students array to Firebase
 */
export async function saveStudentsToFirebase(students: Student[]) {
  try {
    const studentsObj: Record<string, Student> = {};
    students.forEach((s) => {
      if (s && s.id) {
        studentsObj[s.id] = s;
      }
    });
    await set(ref(db, 'students'), studentsObj);
  } catch (err) {
    console.error("Error writing students list to Firebase Realtime Database:", err);
  }
}

/**
 * Synchronize a single student record to Firebase under their specific ID
 */
export async function saveSingleStudentToFirebase(student: Student) {
  if (!student.id) return;
  try {
    await set(ref(db, `students/${student.id}`), student);
  } catch (err) {
    console.error(`Error writing student ${student.id} to Firebase Realtime Database:`, err);
  }
}

/**
 * Remove a single student record from Firebase under their specific ID
 */
export async function deleteStudentFromFirebase(studentId: string) {
  if (!studentId) return;
  try {
    await set(ref(db, `students/${studentId}`), null);
  } catch (err) {
    console.error(`Error deleting student ${studentId} from Firebase Realtime Database:`, err);
  }
}

/**
 * Synchronize App Download config to Firebase
 */
export async function saveAppDownloadToFirebase(config: { downloadUrl?: string; badgeUrl?: string }) {
  try {
    await set(ref(db, 'appDownload'), config);
  } catch (err) {
    console.error("Error writing appDownload to Firebase Realtime Database:", err);
  }
}

/**
 * Synchronize scrolling notice bar text to Firebase
 */
export async function saveNoticeToFirebase(notice: { textBn: string; textEn: string; enabled: boolean; speed?: number }) {
  try {
    await set(ref(db, 'notice'), notice);
  } catch (err) {
    console.error("Error writing notice to Firebase Realtime Database:", err);
  }
}

/**
 * Synchronize Prayer Times Configuration to Firebase
 */
export async function savePrayerTimesConfigToFirebase(config: PrayerTimesConfig) {
  try {
    await set(ref(db, 'prayerTimesConfig'), config);
  } catch (err) {
    console.error("Error writing prayerTimesConfig to Firebase Realtime Database:", err);
  }
}

/**
 * Synchronize Status Bar Config to Firebase
 */
export async function saveStatusBarConfigToFirebase(config: StatusBarConfig) {
  try {
    await set(ref(db, 'statusBarConfig'), config);
  } catch (err) {
    console.error("Error writing statusBarConfig to Firebase Realtime Database:", err);
  }
}

/**
 * Synchronize Admission Enabled flag to Firebase
 */
export async function saveAdmissionEnabledToFirebase(enabled: boolean) {
  try {
    await set(ref(db, 'isAdmissionEnabled'), enabled);
  } catch (err) {
    console.error("Error writing isAdmissionEnabled to Firebase Realtime Database:", err);
  }
}

/**
 * Synchronize general broadcast notification to Firebase and keep in notification list history
 */
export async function saveNotificationToFirebase(notification: AppNotification | null) {
  try {
    await set(ref(db, 'lastNotification'), notification);
    if (notification) {
      await set(ref(db, `notifications/${notification.id}`), notification);
    }
  } catch (err) {
    console.error("Error writing lastNotification and history to Firebase:", err);
  }
}

/**
 * Delete a specific notification from history list in Firebase
 */
export async function deleteNotificationFromFirebase(notificationId: string) {
  if (!notificationId) return;
  try {
    await set(ref(db, `notifications/${notificationId}`), null);
  } catch (err) {
    console.error(`Error deleting notification ${notificationId} from Firebase:`, err);
  }
}




