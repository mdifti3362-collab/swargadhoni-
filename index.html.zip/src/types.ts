export type MediaCategory = 'hamd' | 'nat' | 'gazal' | 'mankabat' | string;

export interface IslamicItem {
  id: string;
  title: string;
  category: MediaCategory;
  mediaType: 'video' | 'lyrics' | 'both';
  videoUrl?: string;
  lyrics?: string;
  createdAt?: number;
}

export interface SectionNames {
  [key: string]: {
    bn: string;
    en: string;
    icon?: string;
  };
}

export interface InfoTexts {
  utsarga: {
    bn: string;
    en: string;
    photoUrl?: string;
  };
  lekhok: {
    bn: string;
    en: string;
    photoUrl?: string;
  };
  developer: {
    bn: string;
    en: string;
    photoUrl?: string;
    facebookUrl?: string;
  };
  facebookUrl: string;
  appTitleBn?: string;
  appTitleEn?: string;
  appLogo?: string;
  contactPhone?: string;
  contactWhatsapp?: string;
  contactFacebook?: string;
  showContactBar?: boolean;
}

export interface ResultItem {
  id: string;
  examName: string;
  marks: string;
  grade: string;
  date: string;
}

export interface CertificateItem {
  id: string;
  certificateName: string;
  certificateNameEn?: string;
  issueDate: string;
  details?: string;
  detailsEn?: string;
  status?: string;
  watermarkUrl?: string;
  signatureUrl?: string;
  signatureTitle?: string;
  signatureTitleEn?: string;
  sealUrl?: string;
}

export interface Student {
  id: string;
  name: string;
  nameBn?: string;
  nameEn?: string;
  fatherName?: string;
  motherName?: string;
  photo?: string;
  mobile: string;
  address: string;
  createdAt: number;
  batchTime?: string;
  classDaysPerWeek?: string;
  courseDuration?: string;
  status?: 'active' | 'completed' | 'old';
  attendance?: {
    [dateStr: string]: 'present' | 'absent';
  };
  results?: ResultItem[];
  certificates?: CertificateItem[];
}

export interface PrayerTimesConfig {
  showWidget: boolean;
  mode: 'auto' | 'manual';
  manualTimings: {
    Fajr: string;
    Sunrise: string;
    Dhuhr: string;
    Asr: string;
    Maghrib: string;
    Isha: string;
  };
}

export interface StatusBarSlide {
  id: string;
  imageUrl: string;
  captionBn?: string;
  captionEn?: string;
}

export interface StatusBarConfig {
  enabled: boolean;
  slides: StatusBarSlide[];
}

export interface AppNotification {
  id: string;
  titleBn: string;
  titleEn: string;
  bodyBn: string;
  bodyEn: string;
  createdAt: number;
}



