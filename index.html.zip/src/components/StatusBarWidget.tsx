import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Image as ImageIcon, Volume2, Info } from 'lucide-react';
import { StatusBarConfig, StatusBarSlide } from '../types';

interface StatusBarWidgetProps {
  lang: 'bn' | 'en';
  config: StatusBarConfig;
}

export default function StatusBarWidget({ lang, config }: StatusBarWidgetProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  const slides = config?.slides || [];

  // Reset index if slides list changes and becomes shorter
  useEffect(() => {
    if (currentIndex >= slides.length) {
      setCurrentIndex(0);
    }
  }, [slides.length, currentIndex]);

  // Optional auto-slide rotation every 6 seconds to make the status bar dynamic
  useEffect(() => {
    if (slides.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [slides.length]);

  if (!config?.enabled || slides.length === 0) {
    return null;
  }

  const activeSlide = slides[currentIndex];

  const handleNext = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setCurrentIndex((prev) => (prev + 1) % slides.length);
  };

  const handlePrev = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setCurrentIndex((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const activeCaption = lang === 'bn' 
    ? activeSlide.captionBn || activeSlide.captionEn || ''
    : activeSlide.captionEn || activeSlide.captionBn || '';

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative w-full rounded-3xl overflow-hidden border transition-all duration-500 shadow-md bg-gradient-to-r from-emerald-950/20 via-[#01231d]/30 to-emerald-950/25 border-emerald-500/10 hover:border-amber-500/20"
      id="status_bar_widget_wrapper"
    >
      <div className="relative h-[200px] sm:h-[240px] w-full flex items-center justify-center overflow-hidden">
        {/* Animated Slide Carousel */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeSlide.id + '_' + currentIndex}
            initial={{ opacity: 0, scale: 1.02, x: 10 }}
            animate={{ opacity: 1, scale: 1, x: 0 }}
            exit={{ opacity: 0, scale: 0.98, x: -10 }}
            transition={{ duration: 0.35, ease: 'easeInOut' }}
            className="absolute inset-0 w-full h-full flex items-center justify-center"
          >
            {/* Background blurred element for beautiful cinematic effect */}
            <div 
              className="absolute inset-0 bg-cover bg-center blur-xl opacity-30 select-none pointer-events-none transform scale-110"
              style={{ backgroundImage: `url(${activeSlide.imageUrl})` }}
            />

            {/* Main Interactive Slide Image */}
            <img
              src={activeSlide.imageUrl}
              alt={activeCaption || "Status update"}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover sm:object-contain relative z-10 select-none"
            />

            {/* Bottom Dark Gradient Shadow for Legible Caption text rendering */}
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent pt-12 pb-4 px-5 z-20 flex flex-col justify-end text-left select-text">
              {activeCaption && (
                <motion.p 
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-xs sm:text-sm font-medium text-amber-100 max-w-[85%] leading-normal tracking-wide drop-shadow-sm line-clamp-2 md:line-clamp-3 font-sans"
                >
                  {activeCaption}
                </motion.p>
              )}
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Top-Right Pill indicating current Slide count */}
        <div className="absolute top-4 right-4 z-30 bg-black/60 backdrop-blur-md border border-emerald-555/10 px-2.5 py-1 rounded-full text-[10px] font-mono font-bold text-amber-400 select-none">
          {currentIndex + 1} / {slides.length}
        </div>

        {/* Top-Left Live/Notice Badge */}
        <div className="absolute top-4 left-4 z-30 bg-[#022c24]/80 backdrop-blur-md border border-emerald-500/20 px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase text-slate-200 tracking-wider flex items-center gap-1.5 select-none font-sans">
          <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />
          <span>{lang === 'bn' ? 'আপডেট' : 'Updates'}</span>
        </div>

        {/* Interactive Sliding Button Controls */}
        {slides.length > 1 && (
          <>
            <button
              onClick={handlePrev}
              type="button"
              className="absolute left-3 top-1/2 -translate-y-1/2 z-30 w-8 sm:w-10 h-8 sm:h-10 rounded-full flex items-center justify-center bg-black/40 hover:bg-black/75 text-slate-300 hover:text-amber-400 border border-slate-800/40 backdrop-blur-xs transition-colors cursor-pointer select-none"
              id="carousel_prev_button"
              title={lang === 'bn' ? 'পূর্ববর্তী' : 'Previous'}
            >
              <ChevronLeft size={18} className="sm:size-20" />
            </button>

            <button
              onClick={handleNext}
              type="button"
              className="absolute right-3 top-1/2 -translate-y-1/2 z-30 w-8 sm:w-10 h-8 sm:h-10 rounded-full flex items-center justify-center bg-black/40 hover:bg-black/75 text-slate-300 hover:text-amber-400 border border-slate-800/40 backdrop-blur-xs transition-colors cursor-pointer select-none animate-pulse-slow"
              id="carousel_next_button"
              title={lang === 'bn' ? 'পরবর্তী' : 'Next'}
            >
              <ChevronRight size={18} className="sm:size-20" />
            </button>
          </>
        )}

        {/* Bottom Slide Indicator dots/pills */}
        {slides.length > 1 && (
          <div className="absolute bottom-3 right-4 z-30 flex gap-1.5 select-none">
            {slides.map((_, idx) => (
              <button
                key={idx}
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setCurrentIndex(idx);
                }}
                className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${idx === currentIndex ? 'w-4 bg-amber-400' : 'w-1.5 bg-slate-500/50'}`}
              />
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
}
