import React, { useState, useEffect } from 'react';
import { MapPin, RotateCw, Search, Compass, Clock, AlertCircle, CalendarRange, Check, Bell, BellOff, ExternalLink } from 'lucide-react';
import { PrayerTimesConfig } from '../types';

interface PrayerTimeWidgetProps {
  lang: 'bn' | 'en';
  prayerTimesConfig?: PrayerTimesConfig;
}

interface Timings {
  Fajr: string;
  Sunrise: string;
  Dhuhr: string;
  Asr: string;
  Maghrib: string;
  Isha: string;
}

interface HijriDate {
  date: string;
  day: string;
  month: { en: string; ar: string };
  year: string;
}

// Offline Safe Default Timings for Dhaka, Bangladesh
const DEFAULT_TIMINGS: Timings = {
  Fajr: "04:15",
  Sunrise: "05:35",
  Dhuhr: "12:15",
  Asr: "16:45",
  Maghrib: "18:45",
  Isha: "20:00"
};

const PRAYER_NAMES: Record<keyof Timings, { bn: string; en: string }> = {
  Fajr: { bn: "ফজর", en: "Fajr" },
  Sunrise: { bn: "সূর্যোদয় (ইশরাক)", en: "Sunrise" },
  Dhuhr: { bn: "যোহর", en: "Dhuhr" },
  Asr: { bn: "আসর", en: "Asr" },
  Maghrib: { bn: "মাগরিব", en: "Maghrib shadow" },
  Isha: { bn: "এশা", en: "Isha" }
};

const BANGLA_NUMBERS: Record<string, string> = {
  '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
  '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯',
  'am': 'পূর্বাহ্ন', 'pm': 'অপরাহ্ন', ':': ':', ' ': ' '
};

function toBanglaNumber(str: string): string {
  return str.split('').map(char => BANGLA_NUMBERS[char] || char).join('');
}

// Convert 24hr string ("18:45") to 12hr formatted string with AM/PM
const formatTime12hr = (time24: string, lang: 'bn' | 'en'): string => {
  if (!time24) return '';
  const [hoursRaw, minutes] = time24.split(':');
  const hours = parseInt(hoursRaw, 10);
  const ampm = hours >= 12 ? 'PM' : 'AM';
  const displayHours = hours % 12 || 12;
  const timeStr = `${displayHours}:${minutes} ${ampm}`;
  return lang === 'bn' ? toBanglaNumber(timeStr.toLowerCase()) : timeStr;
};

export default function PrayerTimeWidget({ lang, prayerTimesConfig }: PrayerTimeWidgetProps) {
  // Config state
  const [locationMode, setLocationMode] = useState<'geo' | 'city'>(() => {
    return (localStorage.getItem('swarg_pt_mode') as 'geo' | 'city') || 'city';
  });
  const [cityInput, setCityInput] = useState(() => {
    return localStorage.getItem('swarg_pt_city') || 'Dhaka';
  });
  const [countryInput, setCountryInput] = useState(() => {
    return localStorage.getItem('swarg_pt_country') || 'Bangladesh';
  });
  const [asrSchool, setAsrSchool] = useState<0 | 1>(() => {
    // 0 = Shia/Shafi/Maliki/Hanbali, 1 = Hanafi
    return Number(localStorage.getItem('swarg_pt_school') || '1') as 0 | 1;
  });

  // Data states
  const [timings, setTimings] = useState<Timings>(DEFAULT_TIMINGS);
  const [hijri, setHijri] = useState<HijriDate | null>(null);
  const [locationName, setLocationName] = useState('Dhaka, Bangladesh');
  const [isLoading, setIsLoading] = useState(false);
  const [isOffline, setIsOffline] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Notification reminder states
  const [notificationsEnabled, setNotificationsEnabled] = useState<boolean>(() => {
    return localStorage.getItem('swarg_pt_notifications') === 'true';
  });
  const [permissionState, setPermissionState] = useState<string>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'unsupported';
  });

  // Countdown & Highlight State
  const [nowTime, setNowTime] = useState(new Date());
  const [nextPrayerKeys, setNextPrayerKeys] = useState<{ key: keyof Timings; countdown: string } | null>(null);

  // Trigger clock refresh every second for next prayer calculations
  useEffect(() => {
    const timer = setInterval(() => {
      setNowTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Monitor current time to trigger daily prayer reminders
  useEffect(() => {
    if (!notificationsEnabled || !timings) return;

    const currentHours = nowTime.getHours();
    const currentMinutes = nowTime.getMinutes();
    const currentHrsStr = String(currentHours).padStart(2, '0');
    const currentMinStr = String(currentMinutes).padStart(2, '0');
    const currentTimeStr = `${currentHrsStr}:${currentMinStr}`;

    const todayDateStr = nowTime.toDateString();

    (Object.keys(timings) as Array<keyof Timings>).forEach((key) => {
      const pTime = timings[key];
      if (pTime === currentTimeStr) {
        const notifyId = `${key}:${todayDateStr}`;
        const lastNotified = localStorage.getItem('swarg_last_notified');
        if (lastNotified !== notifyId) {
          if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === "granted") {
            const prayerName = lang === 'bn' ? PRAYER_NAMES[key].bn : PRAYER_NAMES[key].en;
            const notificationTitle = lang === 'bn' ? 'সালাতের সময় হয়েছে!' : 'Time for Prayer!';
            const notificationBody = lang === 'bn' 
              ? `আসুন সালাত আদায় করি। এখন ${prayerName} এর ওয়াক্ত শুরু হয়েছে।` 
              : `It is time for ${prayerName}. Let's perform prayer.`;

            try {
              new Notification(notificationTitle, {
                body: notificationBody,
              });
            } catch (err) {
              console.warn("Notification failed, maybe inside sandboxed iframe:", err);
            }
            localStorage.setItem('swarg_last_notified', notifyId);
          }
        }
      }
    });
  }, [nowTime, timings, notificationsEnabled, lang]);

  // Sync configuration to localStorage on state changes
  useEffect(() => {
    localStorage.setItem('swarg_pt_mode', locationMode);
    localStorage.setItem('swarg_pt_city', cityInput);
    localStorage.setItem('swarg_pt_country', countryInput);
    localStorage.setItem('swarg_pt_school', String(asrSchool));
  }, [locationMode, cityInput, countryInput, asrSchool]);

  // Main fetch function for timings with optional route/force parameter
  const fetchPrayerTimes = async (forcedMode?: 'geo' | 'city') => {
    const activeMode = forcedMode || locationMode;
    setIsLoading(true);
    setErrorMsg(null);
    setIsOffline(false);

    if (prayerTimesConfig?.mode === 'manual') {
      if (prayerTimesConfig.manualTimings) {
        setTimings(prayerTimesConfig.manualTimings);
      }
      setLocationName(lang === 'bn' ? 'অ্যাডমিন নির্ধারিত সময়' : 'Admin Custom Schedule');
      setIsLoading(false);
      return;
    }

    try {
      let url = '';
      if (activeMode === 'geo') {
        if (typeof window === 'undefined' || !navigator.geolocation) {
          throw new Error('GEO_UNSUPPORTED');
        }
        // Fetch using Geolocation
        await new Promise<void>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(
            async (position) => {
              const { latitude, longitude } = position.coords;
              url = `https://api.aladhan.com/v1/timings?latitude=${latitude}&longitude=${longitude}&school=${asrSchool}&method=1`;
              setLocationName(lang === 'bn' ? 'আপনার বর্তমান অবস্থান' : 'Your Detected Location');
              resolve();
            },
            (err) => {
              reject(err);
            },
            { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 }
          );
        });
      } else {
        // Fetch using City Name
        const cleanCity = encodeURIComponent(cityInput.trim());
        const cleanCountry = encodeURIComponent(countryInput.trim());
        url = `https://api.aladhan.com/v1/timingsByCity?city=${cleanCity}&country=${cleanCountry}&school=${asrSchool}&method=1`;
        setLocationName(`${cityInput}, ${countryInput}`);
      }

      if (url) {
        const response = await fetch(url);
        if (!response.ok) {
          throw new Error('Could not retrieve timings from local server endpoint.');
        }
        const result = await response.json();
        if (result.code === 200 && result.data) {
          const apiTimings = result.data.timings;
          setTimings({
            Fajr: apiTimings.Fajr,
            Sunrise: apiTimings.Sunrise,
            Dhuhr: apiTimings.Dhuhr,
            Asr: apiTimings.Asr,
            Maghrib: apiTimings.Maghrib,
            Isha: apiTimings.Isha
          });
          if (result.data.date?.hijri) {
            setHijri(result.data.date.hijri);
          }
        } else {
          throw new Error('API returned unsuccessful response code.');
        }
      }
    } catch (err: any) {
      console.warn("Prayer Timings API failed. Utilizing Dhaka fallback simulation:", err);
      setIsOffline(true);
      setTimings(DEFAULT_TIMINGS);
      setHijri(null);
      setLocationName(lang === 'bn' ? 'ঢাকা, বাংলাদেশ (ডিফল্ট)' : 'Dhaka, Bangladesh (Default)');
      
      let errorString = '';
      if (err?.message === 'GEO_UNSUPPORTED') {
        errorString = lang === 'bn'
          ? 'আপনার ব্রাউজার বা আইফ্রেম জিপিএস লোকেশন সাপোর্ট করে না। দয়া করে ম্যানুয়ালি শহরের নাম টাইপ করুন অথবা অ্যাপটি সরাসরি নতুন ট্যাবে ওপেন করুন!'
          : 'Geolocation is unsupported or blocked by the iframe. Please enter city manually or open the app in a new tab!';
      } else if (err?.code === 1) { // PERMISSION_DENIED
        errorString = lang === 'bn'
          ? 'জিপিএস লোকেশন পারমিশন দেওয়া হয়নি। দয়া করে ব্রাউজার থেকে লোকেশন অ্যাক্সেস সচল করুন বা সরাসরি নতুন ট্যাবে ওপেন করুন।'
          : 'GPS location permission denied. Please enable location access in browser or open in a new tab.';
      } else if (err?.code === 2) { // POSITION_UNAVAILABLE
        errorString = lang === 'bn'
          ? 'জিপিএস রিসিভারের মাধ্যমে লোকেশন পাওয়া যায়নি। আপনার ডিভাইস বা ব্রাউজারের লোকেশন সার্ভিস সচল আছে কি না নিশ্চিত করুন।'
          : 'Location position unavailable. Please ensure your device location service is turned on or search manually.';
      } else if (err?.code === 3) { // TIMEOUT
        errorString = lang === 'bn'
          ? 'জিপিএস অবস্থান বের করতে দীর্ঘ সময় লেগেছে (টাইমআউট)। দয়া করে রিফ্রেশ করতে পুনরায় চেষ্ঠা করুন অথবা ম্যানুয়ালি আপনার শহরের নাম সার্চ করুন।'
          : 'GPS search timed out. Read accuracy might be limited, please try again or enter city manually.';
      } else {
        errorString = lang === 'bn'
          ? 'লোকেশন বা ইন্টারনেট সমস্যার কারণে নামাজের সময়সূচী আপডেট করা যায়নি। স্ট্যান্ডার্ড সময় প্রদর্শিত হচ্ছে।'
          : 'Could not fetch timings online. Standard fallback schedules activated.';
      }
      setErrorMsg(errorString);
    } finally {
      setIsLoading(false);
    }
  };

  // Re-fetch when dependencies change
  useEffect(() => {
    fetchPrayerTimes();
  }, [locationMode, asrSchool, prayerTimesConfig]);

  // Compute countdown & next upcoming prayer highlights
  useEffect(() => {
    if (!timings) return;

    const findNextPrayer = () => {
      const hoursNow = nowTime.getHours();
      const minutesNow = nowTime.getMinutes();
      const secondsNow = nowTime.getSeconds();
      const absoluteNowSec = (hoursNow * 3600) + (minutesNow * 60) + secondsNow;

      // Map timings to seconds
      const prayerSecList = (Object.keys(timings) as Array<keyof Timings>).map((key) => {
        const value = timings[key] as string;
        const [h, m] = value.split(':').map(Number);
        return {
          key,
          seconds: (h * 3600) + (m * 60)
        };
      });

      // Sort by absolute daily seconds
      prayerSecList.sort((a, b) => a.seconds - b.seconds);

      // Find the next prayer today
      let next = prayerSecList.find(p => p.seconds > absoluteNowSec);
      let isTomorrow = false;
      let targetSeconds = 0;

      if (!next) {
        // Next prayer is Fajr tomorrow
        const fajr = prayerSecList.find(p => p.key === 'Fajr');
        if (fajr) {
          next = fajr;
          isTomorrow = true;
          targetSeconds = fajr.seconds + (24 * 3600);
        }
      } else {
        targetSeconds = next.seconds;
      }

      if (next) {
        const secDiff = targetSeconds - absoluteNowSec;
        const diffHrs = Math.floor(secDiff / 3600);
        const diffMins = Math.floor((secDiff % 3600) / 60);
        const diffSecs = secDiff % 60;

        let countdownStr = '';
        if (lang === 'bn') {
          if (diffHrs > 0) countdownStr += `${toBanglaNumber(diffHrs.toString())} ঘণ্টা `;
          if (diffMins > 0) countdownStr += `${toBanglaNumber(diffMins.toString())} মিনিট `;
          countdownStr += `${toBanglaNumber(diffSecs.toString())} সেকেন্ড`;
        } else {
          if (diffHrs > 0) countdownStr += `${diffHrs}h `;
          if (diffMins > 0) countdownStr += `${diffMins}m `;
          countdownStr += `${diffSecs}s`;
        }

        setNextPrayerKeys({
          key: next.key,
          countdown: countdownStr
        });
      }
    };

    findNextPrayer();
  }, [timings, nowTime, lang]);

  // Form handle for manual search
  const handleManualSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchPrayerTimes('city');
  };

  const attemptGeoFetch = () => {
    setLocationMode('geo');
    fetchPrayerTimes('geo');
  };

  const handleToggleNotifications = async () => {
    if (!('Notification' in window)) {
      alert(lang === 'bn' 
        ? 'দুঃখিত, এই ব্রাউজারটিতে নোটিফিকেশন এপিআই সমর্থিত নয়।' 
        : 'Sorry, the Notification API is not supported in this browser.');
      return;
    }

    if (Notification.permission === 'denied') {
      alert(lang === 'bn'
        ? 'নোটিফিকেশন পারমিশন ব্লক করা আছে। ব্রাউজার সেটিংসে গিয়ে পারমিশন অ্যালাউ করুন।'
        : 'Notification permission is blocked. Please enable it in browser settings.');
      return;
    }

    if (Notification.permission !== 'granted') {
      const permission = await Notification.requestPermission();
      setPermissionState(permission);
      if (permission === 'granted') {
        setNotificationsEnabled(true);
        localStorage.setItem('swarg_pt_notifications', 'true');
        try {
          new Notification(
            lang === 'bn' ? 'সালাত রিমাইন্ডার সচল হয়েছে!' : 'Prayer Reminders Enabled!',
            {
              body: lang === 'bn'
                ? 'এখন থেকে নামাজের ওয়াক্ত শুরু হলে আপনি নোটিফিকেশন পাবেন।'
                : 'You will receive notifications at the start of prayer times.',
            }
          );
        } catch (e) {
          console.warn("Iframe blocked notification creation on request:", e);
        }
      } else {
        setNotificationsEnabled(false);
        localStorage.setItem('swarg_pt_notifications', 'false');
      }
    } else {
      const newState = !notificationsEnabled;
      setNotificationsEnabled(newState);
      localStorage.setItem('swarg_pt_notifications', String(newState));
    }
  };

  const handleSendTestNotification = () => {
    if (!('Notification' in window) || Notification.permission !== 'granted') {
      alert(lang === 'bn'
        ? 'অনুগ্রহ করে প্রথমে নোটিফিকেশন পারমিশন সচল করুন।'
        : 'Please enable notification reminders first.');
      return;
    }
    try {
      new Notification(
        lang === 'bn' ? '🔔 টেস্ট সালাত রিমাইন্ডার' : '🔔 Test Prayer Reminder',
        {
          body: lang === 'bn'
            ? 'অভিনন্দন! আপনার নামাজের সময়সূচী নোটিফিকেশন সঠিকভাবে কাজ করছে।'
            : 'Congratulations! Your prayer notification channel is functioning perfectly.',
        }
      );
    } catch (e) {
      alert(lang === 'bn'
        ? 'নোটিফিকেশন তৈরি করতে ব্যর্থ হয়েছে। অ্যাপটি নতুন ট্যাবে ওপেন করে ট্রাই করুন!'
        : 'Failed to trigger notification. Try opening the app in a new tab!');
    }
  };

  // Maps of Month names translation
  const getHijriMonthTranslated = (monthEn: string): string => {
    const monthsMap: Record<string, string> = {
      'Al-Muharram': 'মহররম', 'Safar': 'সফর', 'Rabi\' al-awwal': 'রবিউল আউয়াল',
      'Rabi\' ath-thani': 'রবিউস সানি', 'Jumada al-ula': 'জমাদিউল আউয়াল',
      'Jumada al-akhirah': 'জমাদিউল আখির', 'Rajab': 'রজব', 'Sha\'ban': 'শাবান',
      'Ramadan': 'রমজান', 'Shawwal': 'শাওয়াল', 'Dhu al-Qa\'dah': 'জিলকদ',
      'Dhu al-Hijjah': 'জিলহজ্জ'
    };
    return lang === 'bn' ? (monthsMap[monthEn] || monthEn) : monthEn;
  };

  return (
    <div id="prayer-times-widget" className="bg-[#001713]/70 border border-emerald-500/10 rounded-2xl p-4 sm:p-5 shadow-xl relative overflow-hidden select-text transition-all duration-300">
      {/* Decorative top pulse */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-teal-500/10 via-amber-500/50 to-teal-500/10" />

      {/* Primary header widget row */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4 pb-4 border-b border-emerald-500/10">
        
        {/* Title and Islamic Date */}
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xl sm:text-2xl animate-spin duration-10000">🕌</span>
            <div>
              <h4 className="text-sm sm:text-base font-black text-amber-300 tracking-tight flex items-center gap-1.5 font-sans">
                {lang === 'bn' ? 'দৈনিক সালাত ও নামাজের সময়সূচী' : 'Daily Salah & Prayer Tracker'}
                {isOffline && (
                  <span className="inline-flex items-center gap-0.5 text-[9px] bg-amber-500/10 border border-amber-500/20 text-amber-500 px-1.5 py-0.5 rounded-full font-mono uppercase tracking-widest">
                    {lang === 'bn' ? 'অফলাইন' : 'Offline'}
                  </span>
                )}
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5 font-medium flex items-center gap-1.5">
                <MapPin size={11} className="text-teal-500" />
                <span>{locationName}</span>
              </p>
            </div>
          </div>
        </div>

        {/* Hijri Calendar Display Option */}
        {hijri && (
          <div className="bg-[#000d0b]/50 border border-emerald-500/15 py-1.5 px-3.5 rounded-xl flex items-center gap-2 shrink-0 self-start md:self-auto font-sans">
            <CalendarRange size={14} className="text-amber-500/80" />
            <div className="text-left">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block leading-none font-mono">
                {lang === 'bn' ? 'আজকের হিজরি তারিখ' : 'Islamic Hijri Date'}
              </span>
              <span className="text-xs font-bold text-slate-300 block mt-0.5">
                {lang === 'bn' 
                  ? `${toBanglaNumber(hijri.day)} ${getHijriMonthTranslated(hijri.month.en)} ${toBanglaNumber(hijri.year)} হিজরি`
                  : `${hijri.day} ${hijri.month.en} ${hijri.year} AH`}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Controls panel: Geolocation and search toggle */}
      {prayerTimesConfig?.mode === 'manual' ? (
        <div className="mb-5 text-center bg-amber-500/5 p-3 rounded-xl border border-amber-500/10 text-xs text-amber-400 font-sans">
          {lang === 'bn'
            ? '🔒 সালাতের সময়সূচীটি অ্যাডমিন প্যানেল থেকে ম্যানুয়ালি নির্ধারণ করা হয়েছে।'
            : '🔒 Salah schedule is explicitly configured and locked by the system administrator.'}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 mb-5 items-stretch bg-[#000c0a]/40 p-3 rounded-xl border border-emerald-500/5">
          
          {/* Toggle Mode and Auto GPS */}
          <div className="sm:col-span-5 flex items-center gap-2">
            <button
              type="button"
              onClick={attemptGeoFetch}
              className={`flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-3 py-2 border rounded-lg text-xs font-bold cursor-pointer transition-all duration-150 ${
                locationMode === 'geo'
                  ? 'border-teal-500 bg-teal-500/15 text-teal-300'
                  : 'border-slate-800 bg-[#000c0a]/60 text-slate-400 hover:text-slate-200'
              }`}
            >
              <Compass size={13} className={locationMode === 'geo' ? 'animate-spin-slow' : ''} />
              <span>{lang === 'bn' ? 'জিপিএস দিয়ে সন্ধান' : 'Detect GPS Address'}</span>
            </button>

            <button
              type="button"
              onClick={() => setLocationMode('city')}
              className={`flex-1 sm:flex-none py-2 px-3 border rounded-lg text-xs font-bold cursor-pointer transition-all duration-150 ${
                locationMode === 'city'
                  ? 'border-yellow-500/50 bg-amber-500/10 text-amber-300'
                  : 'border-slate-800 bg-[#000c0a]/60 text-slate-400 hover:text-slate-200'
              }`}
            >
              {lang === 'bn' ? 'ম্যানুয়াল ডিস্ট্রিক্ট' : 'Manual City'}
            </button>
          </div>

          {/* Manual Input Form */}
          <form onSubmit={handleManualSearch} className="sm:col-span-7 flex items-center gap-2">
            <input
              type="text"
              required
              disabled={locationMode !== 'city'}
              value={cityInput}
              onChange={(e) => setCityInput(e.target.value)}
              placeholder={lang === 'bn' ? 'শহরের নাম (যেমন: Dhaka)' : 'City (e.g. Dhaka, London)'}
              className="flex-1 bg-slate-950/60 border border-slate-800/80 focus:border-emerald-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 disabled:opacity-40 disabled:cursor-not-allowed outline-none"
            />
            <button
              type="submit"
              disabled={locationMode !== 'city' || isLoading}
              className="h-full px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 hover:text-slate-900 font-bold rounded-lg transition-colors cursor-pointer disabled:opacity-40 select-none text-xs flex items-center gap-1"
            >
              {isLoading ? (
                <RotateCw size={12} className="animate-spin" />
              ) : (
                <Search size={12} />
              )}
              <span>{lang === 'bn' ? 'সার্চ' : 'Search'}</span>
            </button>
          </form>
        </div>
      )}

      {/* Dynamic upcoming Prayer Countdown Alert Banner */}
      {nextPrayerKeys && (
        <div className="bg-amber-500/10 border border-amber-500/20 text-amber-300 rounded-xl p-3 mb-5 px-4 flex items-center justify-between gap-3 animate-pulse duration-4000">
          <div className="flex items-center gap-2.5 min-w-0">
            <Clock size={16} className="text-amber-400 shrink-0" />
            <div className="min-w-0 text-left">
              <span className="text-[10px] text-amber-500 font-bold uppercase tracking-wider block font-mono">
                {lang === 'bn' ? 'পরবর্তী ওয়াক্ত' : 'UPCOMING PRAYER SESSION'}
              </span>
              <span className="text-xs sm:text-sm font-black text-amber-200 truncate block mt-0.5 leading-tight">
                {lang === 'bn'
                  ? `${PRAYER_NAMES[nextPrayerKeys.key].bn} নামাযের ওয়াক্ত শুরু হচ্ছে ...`
                  : `Next prayer period will be ${PRAYER_NAMES[nextPrayerKeys.key].en}`}
              </span>
            </div>
          </div>
          <div className="shrink-0 text-right">
            <span className="text-[10px] text-slate-400 uppercase font-mono block leading-none">
              {lang === 'bn' ? 'সময় বাকি' : 'TIME REMAINING'}
            </span>
            <span className="text-xs sm:text-sm font-extrabold text-amber-300 font-mono mt-1 block tracking-tight">
              {nextPrayerKeys.countdown}
            </span>
          </div>
        </div>
      )}

      {/* Notification banner for issues */}
      {errorMsg && (
        <div className="bg-red-500/10 border border-red-500/20 text-red-400 text-[11px] p-2.5 rounded-xl mb-4 flex items-center gap-2 font-sans">
          <AlertCircle size={13} className="shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Notification API Opt-in Reminder Panel */}
      <div className="bg-[#000d0b]/40 border border-emerald-500/10 rounded-xl p-4 mb-5 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 font-sans text-left">
        <div className="flex items-start gap-3">
          <div className={`p-2 rounded-lg shrink-0 ${notificationsEnabled && permissionState === 'granted' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'bg-slate-900 text-slate-500 border border-slate-800'}`}>
            {notificationsEnabled && permissionState === 'granted' ? <Bell size={18} className="animate-wiggle" /> : <BellOff size={18} />}
          </div>
          <div>
            <h5 className="text-xs sm:text-sm font-black text-slate-200">
              {lang === 'bn' ? '🔔 সালাত রিমাইন্ডার ও নোটিফিকেশন' : '🔔 Salah Reminders'}
            </h5>
            <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
              {lang === 'bn'
                ? 'নামাজের ওয়াক্ত শুরু হওয়ার সাথে সাথে আপনার ব্রাউজারে পুশ নোটিফিকেশন অ্যালার্ট পাবেন।'
                : 'Receive a browser push notification alarm instantly at the start of each prayer time.'}
            </p>
            {typeof window !== 'undefined' && window.self !== window.top && (
              <p className="text-[10px] text-amber-400/80 mt-1 leading-normal italic flex items-center gap-1">
                <AlertCircle size={10} />
                <span>
                  {lang === 'bn'
                    ? 'অ্যাপটি আইফ্রেমের ভেতরে থাকায় নোটিফিকেশন পারমিশনের জন্য এটিকে নতুন ট্যাবে ওপেন করতে হতে পারে।'
                    : 'Since this app is in an iframe, you may need to open it in a new tab to authorize notification requests.'}
                </span>
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 self-end md:self-auto w-full md:w-auto justify-end">
          {/* Test Notification Button */}
          {notificationsEnabled && permissionState === 'granted' && (
            <button
              type="button"
              onClick={handleSendTestNotification}
              className="px-2.5 py-1.5 bg-[#001c18] border border-emerald-500/20 text-slate-300 hover:text-white rounded-lg text-[11px] font-bold cursor-pointer transition-colors"
            >
              ⚡ {lang === 'bn' ? 'টেস্ট রিমাইন্ডার' : 'Test Alarm'}
            </button>
          )}

          {/* Toggle Switch Button */}
          <button
            type="button"
            onClick={handleToggleNotifications}
            className={`px-3 py-1.5 border rounded-lg text-xs font-bold cursor-pointer transition-all duration-150 flex items-center gap-1 ${
              notificationsEnabled && permissionState === 'granted'
                ? 'border-amber-500/60 bg-amber-500/10 text-amber-400 hover:border-amber-500'
                : 'border-slate-800 bg-[#000c0a]/60 text-slate-400 hover:text-slate-200 hover:border-slate-700'
            }`}
          >
            {notificationsEnabled && permissionState === 'granted' ? (
              <>
                <Check size={12} className="text-amber-400" />
                <span>{lang === 'bn' ? 'সচল' : 'Reminders Active'}</span>
              </>
            ) : (
              <span>{lang === 'bn' ? 'চালু করুন' : 'Enable Reminders'}</span>
            )}
          </button>
        </div>
      </div>

      {/* Main times grid with responsive card listings */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3.5">
        {(Object.keys(timings) as Array<keyof Timings>).map((key) => {
          const rawTime = timings[key];
          const displayTime = formatTime12hr(rawTime, lang);
          const isUpcoming = nextPrayerKeys?.key === key;

          return (
            <div
              key={key}
              className={`relative rounded-xl p-3 border transition-all flex flex-col items-center text-center justify-center ${
                isUpcoming
                  ? 'border-amber-400/80 bg-amber-500/10 shadow-lg shadow-amber-500/5 -translate-y-1'
                  : 'border-emerald-500/10 bg-[#00100d]/40 hover:border-emerald-500/20 hover:bg-[#00100d]/80'
              }`}
            >
              {/* Highlight badge for next session */}
              {isUpcoming && (
                <span className="absolute -top-2 px-2 py-0.5 bg-amber-500 text-slate-950 font-black rounded-full text-[9px] uppercase tracking-wider font-sans scale-90">
                  {lang === 'bn' ? 'পরবর্তী' : 'NEXT'}
                </span>
              )}

              {/* Prayer Icon */}
              <span className={`text-base sm:text-lg mb-1 leading-none ${isUpcoming ? 'animate-bounce' : ''}`}>
                {key === 'Fajr' ? '🌅' : key === 'Sunrise' ? '☀️' : key === 'Dhuhr' ? '☀️' : key === 'Asr' ? '🌇' : key === 'Maghrib' ? '🌇' : '🌃'}
              </span>

              {/* Title name */}
              <span className={`text-[11px] sm:text-xs font-black tracking-tight ${isUpcoming ? 'text-amber-300' : 'text-slate-300'}`}>
                {lang === 'bn' ? PRAYER_NAMES[key].bn : PRAYER_NAMES[key].en}
              </span>

              {/* Time displays */}
              <span className={`text-xs sm:text-sm font-extrabold font-mono mt-1 ${isUpcoming ? 'text-white' : 'text-slate-400'}`}>
                {displayTime}
              </span>
            </div>
          );
        })}
      </div>

      {/* Footer Settings Block (Hanafi vs Shafi selection) */}
      <div className="mt-4 pt-3 border-t border-emerald-500/5 flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-500 text-[10px] sm:text-xs">
        <p className="text-left leading-relaxed max-w-md font-sans">
          {lang === 'bn'
            ? '💡 আসর নামাজের সময় গণনা পদ্ধতি বা ডিস্ট্রিক্ট এডজাস্টমেন্ট সিলেক্ট করতে পারেন। হানফী মাযহাবে দ্বিগুণ ছায়া সময় নির্ধারণ স্ট্যান্ডার্ড।'
            : '💡 Select your calculation school for the Asr calculation parameter. Standard/Hanafi models shift Asr timetables accordingly.'}
        </p>

        {/* School option filter pill button row */}
        <div className="flex items-center gap-1.5 self-end sm:self-auto shrink-0 bg-slate-950/40 p-0.5 rounded-lg border border-slate-900/80">
          <button
            type="button"
            onClick={() => {
              setAsrSchool(1);
              fetchPrayerTimes();
            }}
            className={`px-2.5 py-1 text-[9px] sm:text-[10px] font-black rounded cursor-pointer transition-colors ${
              asrSchool === 1
                ? 'bg-amber-500/10 border border-amber-500/25 text-amber-400'
                : 'text-slate-400 hover:text-slate-300'
            }`}
          >
            {lang === 'bn' ? 'হানাফী (Hanafi)' : 'Hanafi'}
          </button>
          <button
            type="button"
            onClick={() => {
              setAsrSchool(0);
              fetchPrayerTimes();
            }}
            className={`px-2.5 py-1 text-[9px] sm:text-[10px] font-black rounded cursor-pointer transition-colors ${
              asrSchool === 0
                ? 'bg-amber-500/10 border border-amber-500/25 text-amber-400'
                : 'text-slate-400 hover:text-slate-300'
            }`}
          >
            {lang === 'bn' ? 'শাফেয়ি/অন্যান্য (Standard)' : 'Standard'}
          </button>
        </div>
      </div>
    </div>
  );
}
