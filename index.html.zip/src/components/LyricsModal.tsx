import { X, Play, BookOpen, Share2 } from 'lucide-react';
import { IslamicItem, SectionNames } from '../types';
import { TRANSLATIONS } from '../data';

interface LyricsModalProps {
  item: IslamicItem | null;
  lang: 'bn' | 'en';
  sectionNames: SectionNames;
  onClose: () => void;
  onPlayVideo: (url: string, title: string) => void;
  onShareClick?: (item: IslamicItem) => void;
}

export default function LyricsModal({
  item,
  lang,
  sectionNames,
  onClose,
  onPlayVideo,
  onShareClick,
}: LyricsModalProps) {
  const t = TRANSLATIONS[lang];

  if (!item) return null;

  const lines = item.lyrics ? item.lyrics.split('\n') : [];
  const categoryLabel = sectionNames[item.category]
    ? lang === 'bn'
      ? sectionNames[item.category].bn
      : sectionNames[item.category].en
    : item.category;

  const handlePlayVideoFromCard = () => {
    if (item.videoUrl) {
      onPlayVideo(item.videoUrl, item.title);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-xl bg-gradient-to-b from-[#012821] to-[#011411] border border-amber-500/20 rounded-3xl shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header section */}
        <div className="flex justify-between items-center px-6 py-4 border-b border-amber-500/10 bg-[#011a16]/50">
          <div className="flex items-center gap-2">
            <BookOpen size={16} className="text-amber-400" />
            <span className="text-xs uppercase tracking-wider font-mono text-amber-500 font-bold">
              {categoryLabel}
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center bg-[#012c24] text-slate-300 hover:text-amber-400 focus:outline-none transition-all duration-150 cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        <div className="p-6 max-h-[70vh] overflow-y-auto scrollbar-thin">
          {/* Song Title */}
          <h2 className="text-xl sm:text-2xl font-black text-amber-300 text-center tracking-tight mb-6">
            {item.title}
          </h2>

          {/* Poetry Grid Frame */}
          <div className="bg-[#000d0b]/80 border border-emerald-500/15 rounded-2xl p-6 sm:p-8 mb-6 relative">
            <div className="absolute inset-0 border border-amber-500/5 rounded-2xl pointer-events-none scale-98"></div>
            {lines.length > 0 ? (
              <div className="flex flex-col gap-5 text-center">
                {lines.map((line, idx) => (
                  <p
                    key={idx}
                    className={`text-emerald-100 font-serif text-[17px] sm:text-2xl leading-relaxed select-all ${
                      line.trim() === '' ? 'h-4' : 'border-b border-dashed border-emerald-950 pb-2.5 last:border-0'
                    }`}
                  >
                    {line}
                  </p>
                ))}
              </div>
            ) : (
              <p className="text-slate-500 text-center italic py-6">
                {lang === 'bn' ? 'কোনো গানের কথা বা রিলিক্স দেওয়া নেই।' : 'No lyrics or text provided.'}
              </p>
            )}
          </div>

          {/* Video Attachment Card banner */}
          {item.videoUrl && item.mediaType !== 'lyrics' ? (
            <div className="bg-gradient-to-r from-cyan-950/40 to-[#011e19] border border-cyan-500/20 rounded-2xl p-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400 shadow-md">
                  <Play size={18} fill="currentColor" className="ml-0.5" />
                </div>
                <div className="min-w-0">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-400 font-mono">
                    {t.videoLink}
                  </h4>
                  <p className="text-xs text-slate-400 truncate max-w-[200px] sm:max-w-xs mt-0.5">
                    {item.videoUrl}
                  </p>
                </div>
              </div>

              <button
                onClick={handlePlayVideoFromCard}
                className="bg-gradient-to-r from-cyan-500 to-cyan-400 text-[#011412] hover:from-cyan-400 hover:to-cyan-300 font-bold text-xs px-4 py-2 rounded-xl transition-all shadow-md shadow-cyan-500/15 select-none active:scale-95 cursor-pointer"
              >
                {t.watch}
              </button>
            </div>
          ) : (
            <div className="bg-[#011a16]/30 border border-emerald-550/10 rounded-2xl p-4 text-center text-xs text-teal-600 italic select-none">
              {t.noVideo}
            </div>
          )}
        </div>

        {/* Modal footer Close Button */}
        <div className="px-6 py-4 bg-[#011613]/55 border-t border-emerald-500/10 flex justify-between items-center">
          <button
            onClick={() => onShareClick && onShareClick(item)}
            className="flex items-center gap-1.5 bg-emerald-500 hover:bg-emerald-600 border border-emerald-500/10 text-slate-950 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all shadow-md shadow-emerald-500/10 active:scale-95 cursor-pointer animate-pulse"
          >
            <Share2 size={14} />
            <span>{lang === 'bn' ? 'শেয়ার করুন' : 'Share'}</span>
          </button>
          <button
            onClick={onClose}
            className="bg-[#012c24] hover:bg-[#023c31] border border-emerald-500/15 text-slate-300 hover:text-white px-5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer"
          >
            {t.close}
          </button>
        </div>

      </div>
    </div>
  );
}
