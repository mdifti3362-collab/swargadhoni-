import { X, Heart, Award, Sparkles, Facebook } from 'lucide-react';
import { TRANSLATIONS } from '../data';
import { InfoTexts } from '../types';

interface UtsargaModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'bn' | 'en';
  info: InfoTexts;
}

export function UtsargaModal({ isOpen, onClose, lang, info }: UtsargaModalProps) {
  const t = TRANSLATIONS[lang];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-md bg-gradient-to-b from-[#012d25] to-[#011411] border border-amber-500/20 rounded-3xl p-6 sm:p-8 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        
        {/* Decorative elements */}
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-gradient-to-tr from-amber-500 to-amber-300 flex items-center justify-center text-slate-100 text-2xl shadow-xl shadow-amber-500/20">
          🙏
        </div>

        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center bg-[#011e19] text-slate-400 hover:text-amber-400 focus:outline-none transition-all duration-150 cursor-pointer"
        >
          <X size={15} />
        </button>

        <div className="text-center mt-6">
          <h3 className="text-xl sm:text-2xl font-black text-amber-300 mb-4 tracking-tight">
            {lang === 'bn' ? 'উৎসর্গ বাণী' : 'Dedication Letter'}
          </h3>
          
          <div className="h-[1px] w-24 bg-amber-500/10 mx-auto mb-6"></div>

          {/* Clean scrolling layout for poet's values */}
          <div className="max-h-[50vh] overflow-y-auto flex flex-col gap-4">
            {/* Utsarga Image */}
            {info.utsarga.photoUrl && (
              <div className="mx-auto w-28 h-28 rounded-2xl border-2 border-amber-500/30 overflow-hidden shadow-lg shadow-[#000d0b]/80 bg-[#000d0b] shrink-0">
                <img src={info.utsarga.photoUrl} alt="Dedication" className="w-full h-full object-cover" />
              </div>
            )}

            <div className="bg-[#000d0b]/80 border border-emerald-500/15 rounded-2xl p-5 text-left text-teal-100 leading-relaxed font-sans text-sm sm:text-base whitespace-pre-wrap">
              {lang === 'bn' ? info.utsarga.bn : info.utsarga.en}
            </div>
          </div>

          <div className="mt-6 flex justify-center">
            <Heart size={20} className="text-amber-400/80 animate-pulse" />
          </div>
        </div>
      </div>
    </div>
  );
}

interface LekhokModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'bn' | 'en';
  info: InfoTexts;
}

export function LekhokModal({ isOpen, onClose, lang, info }: LekhokModalProps) {
  const t = TRANSLATIONS[lang];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-md bg-gradient-to-b from-[#012d25] to-[#011411] border border-amber-500/20 rounded-3xl p-6 sm:p-8 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        
        {/* Decorative Avatar Icon */}
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-gradient-to-tr from-amber-500 to-amber-300 flex items-center justify-center text-slate-100 text-2xl shadow-xl shadow-amber-500/20">
          📝
        </div>

        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center bg-[#011e19] text-slate-400 hover:text-amber-400 focus:outline-none transition-all duration-150 cursor-pointer"
        >
          <X size={15} />
        </button>

        <div className="text-center mt-6">
          <h3 className="text-xl sm:text-2xl font-black text-amber-300 mb-4 tracking-tight">
            {lang === 'bn' ? 'সংকলকের তথ্য' : 'Author Information'}
          </h3>

          <div className="h-[1px] w-24 bg-amber-500/10 mx-auto mb-6"></div>

          {/* Scrolling profile bio details container */}
          <div className="flex flex-col gap-4 max-h-[50vh] overflow-y-auto">
            
            {/* Author Profile Picture */}
            {info.lekhok.photoUrl && (
              <div className="mx-auto w-24 h-24 sm:w-28 sm:h-28 rounded-full border-2 border-amber-500/30 overflow-hidden shadow-lg shadow-[#000d0b]/80 bg-[#000d0b] shrink-0">
                <img src={info.lekhok.photoUrl} alt="Author" className="w-full h-full object-cover" />
              </div>
            )}

            {/* Author Profile Text */}
            <div className="bg-[#000d0b]/80 border border-emerald-500/15 rounded-2xl p-5 text-left text-teal-100 leading-relaxed font-sans text-sm sm:text-base whitespace-pre-wrap">
              {lang === 'bn' ? info.lekhok.bn : info.lekhok.en}
            </div>

            {/* Developer Credits Info */}
            <div className="bg-[#011f1a]/50 border border-emerald-500/15 rounded-2xl p-4 text-left flex items-start gap-4">
              {info.developer.photoUrl && (
                <div className="w-12 h-12 rounded-full border border-amber-500/25 overflow-hidden bg-[#000d0b] shrink-0">
                  <img src={info.developer.photoUrl} alt="Developer" className="w-full h-full object-cover" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#34d399] mb-1 block">
                  {lang === 'bn' ? 'অ্যাপ কারিগর' : 'Application Developer'}
                </span>
                <p className="text-xs text-slate-400 whitespace-pre-wrap leading-relaxed">
                  {lang === 'bn' ? info.developer.bn : info.developer.en}
                </p>
                {/* Developer facebook ID URL direct option */}
                {info.developer.facebookUrl && info.developer.facebookUrl !== 'https://www.facebook.com/' && (
                  <a
                    href={info.developer.facebookUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2.5 inline-flex items-center gap-1.5 text-xs font-semibold text-blue-400 hover:text-blue-300 transition-colors cursor-pointer"
                  >
                    <Facebook size={12} />
                    <span>{lang === 'bn' ? 'ডেভেলপার ফেসবুক আইডি' : 'Developer Facebook'}</span>
                  </a>
                )}
              </div>
            </div>
            
            {/* Compiler/Uploader Facebook direct contact button */}
            {info.facebookUrl && info.facebookUrl !== 'https://facebook.com/' && (
              <a
                href={info.facebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 w-full flex items-center justify-center gap-2 bg-[#1877f2] hover:bg-[#156bec] text-white py-3 px-4 rounded-xl text-xs sm:text-sm font-semibold shadow-md active:scale-95 transition-all cursor-pointer"
              >
                <Facebook size={16} />
                <span>{t.facebookLink}</span>
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
