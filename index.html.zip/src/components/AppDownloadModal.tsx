import { X, Download, QrCode, Copy, Check } from 'lucide-react';
import { useState } from 'react';

interface AppDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'bn' | 'en';
  appDownload?: { downloadUrl?: string; badgeUrl?: string };
}

export default function AppDownloadModal({ isOpen, onClose, lang, appDownload }: AppDownloadModalProps) {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const downloadUrl = appDownload?.downloadUrl || '';
  const badgeUrl = appDownload?.badgeUrl || '';

  const handleCopy = () => {
    if (!downloadUrl) return;
    navigator.clipboard.writeText(downloadUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-md bg-gradient-to-b from-[#012d25] to-[#011411] border border-amber-500/25 rounded-3xl p-6 sm:p-8 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        
        {/* Decorative elements */}
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-gradient-to-tr from-amber-500 to-amber-300 flex items-center justify-center text-slate-100 text-2xl shadow-xl shadow-amber-500/30">
          📱
        </div>

        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center bg-[#011e19] text-slate-400 hover:text-amber-400 focus:outline-none transition-all duration-150 cursor-pointer"
        >
          <X size={15} />
        </button>

        <div className="text-center mt-6">
          <h3 className="text-xl sm:text-2xl font-black text-amber-300 mb-2 tracking-tight">
            {lang === 'bn' ? 'অফিসিয়াল অ্যাপ ডাউনলোড' : 'Official Mobile App Download'}
          </h3>
          
          <p className="text-xs text-slate-400 max-w-xs mx-auto mb-4">
            {lang === 'bn' 
              ? 'স্বর্গধ্বনি একাডেমি অফিশিয়াল অ্যাপ্লিকেশন ডাউনলোড করুন এবং যুক্ত থাকুন।' 
              : 'Download the Swargadhoni Academy official App and stay connected instantly.'}
          </p>
          
          <div className="h-[1px] w-24 bg-amber-500/10 mx-auto mb-6"></div>

          {/* QR Code section */}
          <div className="bg-[#000d0b]/80 border border-emerald-500/15 rounded-2xl p-5 flex flex-col items-center justify-center gap-4 mb-5">
            {badgeUrl ? (
              <div className="flex flex-col items-center gap-2 p-3 bg-white rounded-2xl shadow-md border border-slate-200 max-w-[170px]">
                <img 
                  src={badgeUrl} 
                  alt="QR Code Badge" 
                  className="w-32 h-32 object-contain"
                  referrerPolicy="no-referrer"
                />
                <span className="text-[10px] font-black text-slate-800 uppercase tracking-widest flex items-center gap-1 font-mono">
                  <QrCode size={11} className="text-amber-600" />
                  {lang === 'bn' ? 'স্ক্যান করুন' : 'Scan to Install'}
                </span>
              </div>
            ) : (
              <div className="min-h-[140px] flex flex-col items-center justify-center text-slate-500 text-center gap-1">
                <QrCode size={38} className="text-slate-600/50" />
                <p className="text-xs italic">
                  {lang === 'bn' ? 'কোনো কিউআর কোড পাওয়া যায়নি' : 'No QR Code image configured'}
                </p>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col gap-3">
            {downloadUrl ? (
              <>
                <a
                  href={downloadUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 bg-gradient-to-r from-amber-500 to-amber-300 hover:from-amber-400 hover:to-amber-200 text-[#011412] font-black rounded-xl text-sm sm:text-base shadow-lg shadow-amber-500/10 transition-all active:scale-98 cursor-pointer"
                >
                  <Download size={16} className="stroke-[3]" />
                  <span>{lang === 'bn' ? 'ডাউনলোড লিঙ্ক (সরাসরি)' : 'Open Download Link'}</span>
                </a>

                {/* URL feedback copy block */}
                <div className="flex items-center gap-2 bg-[#000d0b]/40 rounded-xl px-3.5 py-2.5 border border-emerald-500/10 justify-between">
                  <span className="text-[10px] sm:text-xs text-teal-400/80 font-mono truncate text-left max-w-[240px] select-all">
                    {downloadUrl}
                  </span>
                  
                  <button
                    onClick={handleCopy}
                    className="p-1 px-2 rounded-lg bg-[#011e19]/80 border border-emerald-500/20 text-slate-300 hover:text-amber-400 cursor-pointer transition-colors hover:bg-[#011e19] select-none flex items-center gap-1 text-[10px]"
                  >
                    {copied ? (
                      <>
                        <Check size={11} className="text-teal-400" />
                        <span>{lang === 'bn' ? 'কপি হয়েছে' : 'Copied'}</span>
                      </>
                    ) : (
                      <>
                        <Copy size={11} />
                        <span>{lang === 'bn' ? 'কপি করুন' : 'Copy'}</span>
                      </>
                    )}
                  </button>
                </div>
              </>
            ) : (
              <div className="p-4 bg-slate-950/40 rounded-2xl border border-slate-800 text-xs text-slate-500 italic">
                {lang === 'bn' 
                  ? 'ডাউনলোড লিঙ্ক এখনও প্রকাশ করা হয়নি। অনুগ্রহ করে পরে চেষ্টা করুন।' 
                  : 'Download Link has not been made available yet. Please check back later.'}
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
}
