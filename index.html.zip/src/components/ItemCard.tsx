import { Play, BookOpen, Share2, Calendar, Clock, AlignLeft } from 'lucide-react';
import { motion } from 'motion/react';
import { IslamicItem, SectionNames } from '../types';
import { TRANSLATIONS } from '../data';

interface ItemCardProps {
  item: IslamicItem;
  lang: 'bn' | 'en';
  sectionNames: SectionNames;
  onLyricsClick: (id: string) => void;
  onVideoClick: (url: string, title: string) => void;
  onShareClick?: (item: IslamicItem) => void;
  key?: string;
}

export default function ItemCard({
  item,
  lang,
  sectionNames,
  onLyricsClick,
  onVideoClick,
  onShareClick,
}: ItemCardProps) {
  const t = TRANSLATIONS[lang];

  // Helper category icon
  const getIcon = (cat: string) => {
    switch (cat) {
      case 'hamd':
        return '🕌';
      case 'nat':
        return '⭐';
      case 'gazal':
        return '🎤';
      case 'mankabat':
        return '📿';
      default:
        return '🎵';
    }
  };

  const getMediaBadge = () => {
    if (item.mediaType === 'both') {
      return (
        <span className="text-[10px] bg-amber-500/15 text-amber-300 font-bold border border-amber-500/20 px-2 py-0.5 rounded-full select-none shrink-0">
          {t.both}
        </span>
      );
    } else if (item.mediaType === 'video') {
      return (
        <span className="text-[10px] bg-cyan-500/15 text-cyan-300 font-bold border border-cyan-500/20 px-2 py-0.5 rounded-full select-none shrink-0">
          {t.videoOnly}
        </span>
      );
    } else {
      return (
        <span className="text-[10px] bg-emerald-500/15 text-emerald-400 font-bold border border-emerald-500/20 px-2 py-0.5 rounded-full select-none shrink-0">
          {t.lyricsOnly}
        </span>
      );
    }
  };

  const categoryLabel = sectionNames[item.category]
    ? lang === 'bn'
      ? sectionNames[item.category].bn
      : sectionNames[item.category].en
    : item.category;

  // Format date nicely
  const formattedDate = item.createdAt
    ? new Date(item.createdAt).toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      })
    : lang === 'bn' ? 'সাম্প্রতিক' : 'Recent';

  // Calculate lines and reading time for blog card style
  const lines = item.lyrics ? item.lyrics.split('\n').map((l) => l.trim()).filter(Boolean) : [];
  const lineCount = lines.length;
  const readTime = Math.max(1, Math.ceil(lineCount / 8)); // Estimating 8 lines per minute for slow reading

  return (
    <motion.div
      onClick={() => onLyricsClick(item.id)}
      className="group bg-gradient-to-b from-[#022c24]/25 to-[#011a15]/40 hover:from-[#033c31]/45 hover:to-[#01221b]/60 border border-emerald-500/10 hover:border-amber-500/35 rounded-2xl p-5 flex flex-col justify-between transition-all duration-300 transform hover:-translate-y-1 hover:shadow-xl hover:shadow-amber-500/[0.03] cursor-pointer relative overflow-hidden"
      initial={{ opacity: 0, y: 15 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-20px" }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
    >
      {/* Background glowing blog gradient */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/[0.01] group-hover:bg-amber-500/[0.03] rounded-full blur-2xl pointer-events-none transition-all duration-500" />

      {/* Blog Post Top Metadata Row */}
      <div className="flex items-center justify-between gap-2 border-b border-emerald-500/5 pb-3 mb-3.5 select-none font-sans">
        <div className="flex items-center gap-2">
          <span className="text-sm shrink-0">{getIcon(item.category)}</span>
          <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
            {categoryLabel}
          </span>
        </div>

        <div className="flex items-center gap-2.5 text-[10px] text-slate-500">
          <span className="flex items-center gap-1">
            <Calendar size={11} />
            {formattedDate}
          </span>
          {lineCount > 0 && (
            <span className="flex items-center gap-1">
              <Clock size={11} />
              {lang === 'bn' ? `${readTime} মিনিট পড়া` : `${readTime} min read`}
            </span>
          )}
        </div>
      </div>

      {/* Blog Title & Snippet Wrapper */}
      <div className="flex-1 flex flex-col justify-between mb-4">
        <div>
          <h4 className="text-base sm:text-lg font-extrabold text-slate-100 group-hover:text-amber-300 transition-colors duration-250 line-clamp-2 leading-snug tracking-tight mb-2">
            {item.title}
          </h4>

          {/* Poetry Quote preview (Snippet) */}
          {lines.length > 0 ? (
            <div className="text-slate-400 text-xs italic leading-relaxed pl-3 border-l-2 border-emerald-500/20 group-hover:border-amber-500/45 transition-colors duration-300 line-clamp-2 mt-2 font-serif bg-emerald-500/[0.02] py-1.5 pr-2 rounded-r-lg">
              {lines.slice(0, 2).map((line, idx) => (
                <p key={idx} className="truncate">
                  {line}
                </p>
              ))}
            </div>
          ) : (
            <div className="text-slate-500/80 text-[11px] italic mt-2.5 flex items-center gap-1 select-none font-sans">
              <AlignLeft size={12} />
              {lang === 'bn' ? 'কোনো পূর্বরূপ উপলব্ধ নেই' : 'No lyric preview available'}
            </div>
          )}
        </div>
      </div>

      {/* Blog Card Footer controls row */}
      <div className="flex items-center justify-between border-t border-emerald-500/5 pt-3.5 mt-auto">
        {/* Media Badges */}
        <div>{getMediaBadge()}</div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
          {item.videoUrl && item.mediaType !== 'lyrics' && (
            <button
              onClick={() => onVideoClick(item.videoUrl || '', item.title)}
              className="w-8.5 h-8.5 rounded-lg flex items-center justify-center bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/20 active:scale-90 text-cyan-400 hover:text-cyan-300 transition-all cursor-pointer"
              title={lang === 'bn' ? 'ভিডিও দেখুন' : 'Watch Video'}
            >
              <Play size={14} fill="currentColor" className="ml-0.5" />
            </button>
          )}

          <button
            onClick={() => onLyricsClick(item.id)}
            className="w-8.5 h-8.5 rounded-lg flex items-center justify-center bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 active:scale-90 text-amber-400 hover:text-amber-300 transition-all cursor-pointer"
            title={lang === 'bn' ? 'গানের কথা ও বিস্তারিত' : 'Lyrics & Details'}
          >
            <BookOpen size={14} />
          </button>

          <button
            onClick={() => onShareClick && onShareClick(item)}
            className="w-8.5 h-8.5 rounded-lg flex items-center justify-center bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 active:scale-90 text-emerald-400 hover:text-emerald-300 transition-all cursor-pointer"
            title={lang === 'bn' ? 'শেয়ার' : 'Share'}
          >
            <Share2 size={14} />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
