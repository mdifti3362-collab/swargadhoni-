import { X, Play } from 'lucide-react';
import { TRANSLATIONS } from '../data';

interface VideoModalProps {
  url: string;
  title: string;
  lang: 'bn' | 'en';
  onClose: () => void;
}

export default function VideoModal({ url, title, lang, onClose }: VideoModalProps) {
  const t = TRANSLATIONS[lang];

  // Secure YouTube ID parser & Formatter
  const getEmbedUrl = (rawUrl: string) => {
    let videoId = '';
    try {
      if (rawUrl.includes('embed/')) {
        videoId = rawUrl.split('embed/')[1].split('?')[0];
      } else if (rawUrl.includes('watch?v=')) {
        videoId = rawUrl.split('watch?v=')[1].split('&')[0];
      } else if (rawUrl.includes('youtu.be/')) {
        videoId = rawUrl.split('youtu.be/')[1].split('?')[0];
      } else if (rawUrl.includes('v=')) {
        videoId = rawUrl.split('v=')[1].split('&')[0];
      } else {
        videoId = rawUrl.trim();
      }
    } catch (e) {
      videoId = 'dQw4w9WgXcQ'; // Fallback
    }

    return `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0&modestbranding=1`;
  };

  const embedUrl = getEmbedUrl(url);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-xl">
      <div className="relative w-full max-w-3xl bg-[#011411] border border-amber-500/20 rounded-3xl overflow-hidden shadow-2xl animate-in (fade-in zoom-in-95) duration-200">
        
        {/* Header toolbar */}
        <div className="flex justify-between items-center px-6 py-4 border-b border-emerald-950 bg-[#011a16]/60">
          <div className="flex items-center gap-2">
            <Play size={15} fill="currentColor" className="text-amber-500" />
            <h3 className="text-sm sm:text-base font-bold text-slate-100 max-w-sm sm:max-w-md truncate">
              {title}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center bg-[#012c24] text-slate-400 hover:text-amber-400 focus:outline-none transition-all duration-150 cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        {/* Video Aspect Ratio 16:9 Wrapper Frame */}
        <div className="relative w-full bg-black aspect-video">
          <iframe
            src={embedUrl}
            title={title}
            className="absolute inset-0 w-full h-full border-0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
          />
        </div>

        {/* Footer info bar */}
        <div className="px-6 py-4 bg-[#000504] text-right text-xs text-teal-605 font-mono">
          <span>YouTube Media Embed Player</span>
        </div>

      </div>
    </div>
  );
}
