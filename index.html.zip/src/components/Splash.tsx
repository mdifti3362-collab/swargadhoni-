import { motion } from 'motion/react';
import { InfoTexts } from '../types';

interface SplashProps {
  onComplete: () => void;
  info?: InfoTexts;
  key?: string;
}

export default function Splash({ onComplete, info }: SplashProps) {
  const logoValue = (info?.appLogo || '🎵').trim();
  const isImageLogo = logoValue.startsWith('http://') ||
                      logoValue.startsWith('https://') ||
                      logoValue.startsWith('/') ||
                      logoValue.startsWith('data:image');

  const appTitle = info?.appTitleBn || 'স্বর্গধ্বনি';

  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6, ease: 'easeInOut' }}
      onAnimationComplete={() => {
        // Just in case, but we typically trigger this from App.tsx using a standard setTimeout.
      }}
      className="fixed inset-0 bg-gradient-to-br from-[#011c18] via-[#011411] to-[#000504] flex flex-col justify-center items-center z-50 text-white overflow-hidden p-6"
    >
      {/* Decorative Golden Pattern overlays */}
      <div className="absolute inset-0 opacity-5 pointer-events-none bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-amber-400 via-transparent to-transparent scale-150 animate-pulse"></div>

      <div className="text-center z-10 flex flex-col items-center">
        {/* Animated Icon Circle */}
        <motion.div
          initial={{ scale: 0.3, opacity: 0 }}
          animate={{ scale: [0.3, 1.1, 1], opacity: 1 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className="w-24 h-24 bg-gradient-to-tr from-amber-500 to-amber-300 rounded-[32px] flex items-center justify-center mb-6 shadow-xl shadow-amber-500/20 relative overflow-hidden"
        >
          {/* Pulse ring */}
          <span className="absolute -inset-2 border border-amber-400/30 rounded-[36px] animate-ping opacity-75"></span>
          {isImageLogo ? (
            <img 
              src={logoValue} 
              alt="Logo" 
              className="w-full h-full object-cover" 
              referrerPolicy="no-referrer"
            />
          ) : (
            <span className="text-4xl filter drop-shadow">{logoValue}</span>
          )}
        </motion.div>

        {/* Brand Name */}
        <motion.h1
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="text-5xl md:text-6xl font-extrabold tracking-widest bg-gradient-to-r from-amber-400 via-amber-200 to-amber-400 bg-clip-text text-transparent mb-4 select-none font-sans drop-shadow-md"
        >
          {appTitle}
        </motion.h1>

        {/* Elegant divider */}
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: 80 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="h-[2px] bg-gradient-to-r from-transparent via-amber-400 to-transparent mb-4"
        />

        {/* Subtitle / Compiler */}
        <motion.p
          initial={{ y: 15, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.5 }}
          className="text-amber-300/90 font-medium text-sm md:text-base tracking-wide max-w-sm leading-relaxed"
        >
          সৈয়্যদ মুহাম্মদ এহসান কাদের কাদেরী
        </motion.p>

        <motion.p
          initial={{ y: 15, opacity: 0 }}
          animate={{ y: 0, opacity: 0.6 }}
          transition={{ delay: 0.7, duration: 0.5 }}
          className="text-slate-400 text-xs mt-1"
        >
          হামদ, নাত, গজল ও মানকাবাত সংগ্রহ
        </motion.p>

        {/* Premium Spinner */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.4 }}
          className="mt-12 flex flex-col items-center gap-3"
        >
          <div className="w-10 h-10 border-2 border-amber-500/20 border-t-amber-400 rounded-full animate-spin"></div>
          <span className="text-xs text-amber-500/70 tracking-widest animate-pulse font-mono uppercase">
            Loading Blessings
          </span>
        </motion.div>
      </div>

      {/* Decorative fine-print footer */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.4 }}
        transition={{ delay: 1 }}
        className="absolute bottom-6 text-[10px] text-slate-500 uppercase tracking-widest font-mono"
      >
        স্বর্গধ্বনি • Sorgodoni App
      </motion.p>
    </motion.div>
  );
}
