import { useState, useEffect, useRef } from 'react';
import { MoreVertical, Globe, Wifi, WifiOff, Bell } from 'lucide-react';
import { TRANSLATIONS } from '../data';
import { InfoTexts } from '../types';

interface NavbarProps {
  lang: 'bn' | 'en';
  onToggleLang: () => void;
  info?: InfoTexts;
  notificationsCount: number;
  onOpenNotifications: () => void;
}

export default function Navbar({ lang, onToggleLang, info, notificationsCount, onOpenNotifications }: NavbarProps) {
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [isMenuOpen, setIsMenuOpen] = useState<boolean>(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const t = TRANSLATIONS[lang];

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Click outside to close three-dot menu
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const logoValue = (info?.appLogo || '🎵').trim();
  const isImageLogo = logoValue.startsWith('http://') ||
                      logoValue.startsWith('https://') ||
                      logoValue.startsWith('/') ||
                      logoValue.startsWith('data:image');

  const appTitle = lang === 'bn' 
    ? (info?.appTitleBn || t.title) 
    : (info?.appTitleEn || (info?.appTitleBn ? info.appTitleBn : t.title));

  return (
    <nav className="sticky top-[48px] z-40 w-full bg-[#011613]/95 backdrop-blur-md border-b border-amber-500/20 py-3 px-4 sm:px-6 flex justify-between items-center transition-all duration-300">
      {/* Brand logo & title */}
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-300 flex items-center justify-center shadow-lg shadow-amber-500/10 overflow-hidden">
          {isImageLogo ? (
            <img 
              src={logoValue} 
              alt="Logo" 
              className="w-full h-full object-cover" 
              referrerPolicy="no-referrer"
            />
          ) : (
            <span className="text-lg filter drop-shadow-sm">{logoValue}</span>
          )}
        </div>
        <div>
          <h1 className="text-xl sm:text-2xl font-black bg-gradient-to-r from-amber-400 via-amber-200 to-amber-400 bg-clip-text text-transparent font-sans tracking-tight">
            {appTitle}
          </h1>
        </div>
      </div>

      {/* Right nav actions */}
      <div className="flex items-center gap-2 sm:gap-4">
        {/* Real-time Online/Offline Network Status display */}
        <div
          className={`hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold tracking-wide border transition-all duration-500 ${
            isOnline
              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
              : 'bg-rose-500/10 text-rose-400 border-rose-500/20 animate-pulse'
          }`}
        >
          {isOnline ? (
            <>
              <Wifi size={13} className="animate-pulse" />
              <span>{t.online}</span>
            </>
          ) : (
            <>
              <WifiOff size={13} />
              <span>{t.offline}</span>
            </>
          )}
        </div>

        {/* Language switch toggle switch */}
        <div
          onClick={onToggleLang}
          className="relative flex items-center bg-emerald-950/40 hover:bg-emerald-950/60 border border-emerald-500/25 rounded-lg p-0.5 cursor-pointer select-none transition-all duration-300 w-[96px] h-[30px]"
          title={lang === 'bn' ? 'Switch to English' : 'বাংলায় পরিবর্তন করুন'}
        >
          {/* Sliding highlight indicator (block style) */}
          <div
            className={`absolute top-0.5 bottom-0.5 rounded-md bg-gradient-to-r from-amber-500/25 to-amber-400/15 border border-amber-500/45 shadow-inner shadow-amber-500/10 transition-all duration-300 ease-out ${
              lang === 'bn' ? 'left-0.5 w-[44px]' : 'left-[49.5px] w-[44px]'
            }`}
          />
          {/* Options (no flags) */}
          <div className="flex w-full h-full items-center justify-between text-[10px] font-extrabold tracking-wider z-10">
            <div className={`w-1/2 flex items-center justify-center transition-colors duration-300 ${lang === 'bn' ? 'text-amber-300 font-black' : 'text-slate-400'}`}>
              <span>বাংলা</span>
            </div>
            <div className={`w-1/2 flex items-center justify-center transition-colors duration-300 ${lang === 'en' ? 'text-amber-300 font-black' : 'text-slate-400'}`}>
              <span>ENG</span>
            </div>
          </div>
        </div>

        {/* Notification Bell Button */}
        <button
          onClick={onOpenNotifications}
          className="relative w-8 h-8 rounded-full flex items-center justify-center border border-amber-500/20 bg-amber-500/5 text-amber-300 hover:text-amber-200 hover:border-amber-500/45 hover:bg-amber-500/10 transition-all active:scale-95 duration-200 cursor-pointer shrink-0"
          title={lang === 'bn' ? 'সকল নোটিফিকেশন' : 'All Notifications'}
        >
          <Bell size={15} />
          {notificationsCount > 0 && (
            <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[9px] font-bold text-white ring-2 ring-[#011613] animate-pulse">
              {notificationsCount}
            </span>
          )}
        </button>

        {/* Three dots menu dropdown wrapper */}
        <div className="relative" ref={menuRef}>
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="w-8 h-8 rounded-full flex items-center justify-center border border-slate-700 hover:border-amber-500/30 bg-slate-900/60 text-slate-300 hover:text-amber-400 focus:outline-none transition-all duration-200 cursor-pointer"
          >
            <MoreVertical size={16} />
          </button>

          {isMenuOpen && (
            <div className="absolute right-0 mt-2 w-48 bg-[#022c24]/95 backdrop-blur-xl border border-amber-500/20 rounded-2xl shadow-2xl overflow-hidden py-1 z-50 animate-in fade-in slide-in-from-top-3 duration-200">
              {/* Online indicator for small screens */}
              <div className="px-4 py-2 text-xs flex items-center justify-between">
                <span className="text-slate-400">Status:</span>
                <span className={isOnline ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {isOnline ? t.online : t.offline}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
