import React, { useState, useEffect, useRef } from 'react';
import { Search, ChevronLeft, ChevronRight, Mic } from 'lucide-react';
import { TRANSLATIONS } from '../data';
import { SectionNames } from '../types';

interface SearchAndFilterProps {
  lang: 'bn' | 'en';
  searchQuery: string;
  onSearchChange: (query: string) => void;
  sections: string[];
  sectionNames: SectionNames;
  currentCategory: string;
  onSelectCategory: (cat: string) => void;
}

export default function SearchAndFilter({
  lang,
  searchQuery,
  onSearchChange,
  sections,
  sectionNames,
  currentCategory,
  onSelectCategory,
}: SearchAndFilterProps) {
  const t = TRANSLATIONS[lang];
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [showLeftFade, setShowLeftFade] = useState(false);
  const [showRightFade, setShowRightFade] = useState(false);

  // Speech Recognition States
  const [speechSupported, setSpeechSupported] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      setSpeechSupported(true);
    }
  }, []);

  const stopListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        console.error('Error stopping speech recognition:', e);
      }
    }
    setIsListening(false);
  };

  const toggleListening = () => {
    if (isListening) {
      stopListening();
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = lang === 'bn' ? 'bn-BD' : 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        if (event.results && event.results[0] && event.results[0][0]) {
          const transcript = event.results[0][0].transcript;
          if (transcript) {
            onSearchChange(transcript);
          }
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error event:', event.error);
        stopListening();
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.error('Failed to instantiate/start SpeechRecognition', err);
      setIsListening(false);
    }
  };

  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (e) {
          // ignore
        }
      }
    };
  }, []);

  // Check scroll positions to trigger fading gradients on edges
  const checkScroll = () => {
    const el = scrollContainerRef.current;
    if (el) {
      const canScrollLeft = el.scrollLeft > 5;
      const canScrollRight = el.scrollLeft + el.clientWidth < el.scrollWidth - 5;
      setShowLeftFade(canScrollLeft);
      setShowRightFade(canScrollRight);
    }
  };

  useEffect(() => {
    const el = scrollContainerRef.current;
    if (el) {
      checkScroll();
      el.addEventListener('scroll', checkScroll);
      window.addEventListener('resize', checkScroll);
      
      // Initial double check to make sure render-state is caught
      const timeoutId = setTimeout(checkScroll, 150);
      return () => {
        el.removeEventListener('scroll', checkScroll);
        window.removeEventListener('resize', checkScroll);
        clearTimeout(timeoutId);
      };
    }
  }, [sections, searchQuery]);

  // Handle scroll trigger button clicks
  const scroll = (direction: 'left' | 'right') => {
    const el = scrollContainerRef.current;
    if (el) {
      const scrollAmount = direction === 'left' ? -150 : 150;
      el.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <div id="search-and-filter-bar" className="w-full max-w-2xl mx-auto px-4 pt-6 pb-2">
      <style>{`
        .scrollbar-none::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-none {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>

      {/* Search Input Box */}
      <div className="relative w-full mb-6">
        <div className="absolute inset-y-0 left-4 pl-1 flex items-center pointer-events-none">
          <Search size={18} className="text-amber-500/50" />
        </div>
        <input
          type={searchQuery.trim() !== '' && 'ahsan@1992'.startsWith(searchQuery.trim().toLowerCase()) ? 'password' : 'text'}
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder={t.searchPlaceholder}
          className="w-full bg-[var(--card-bg)] hover:bg-[var(--header-hover)] focus:bg-[var(--header-bg)] border border-[var(--card-border)] focus:border-amber-500/60 rounded-full py-3.5 pl-12 pr-28 text-sm text-slate-100 placeholder-teal-600/70 outline-none transition-all duration-300 focus:shadow-lg focus:shadow-amber-500/5"
          aria-label={t.searchPlaceholder}
        />
        <div className="absolute inset-y-0 right-4 flex items-center gap-3">
          {/* Speech Voice Search Activation mic button */}
          {speechSupported && (
            <button
              type="button"
              onClick={toggleListening}
              className={`p-1.5 rounded-full transition-all duration-300 cursor-pointer flex items-center justify-center border ${
                isListening
                  ? 'bg-red-500/20 text-red-400 border-red-500/40 animate-pulse scale-110'
                  : 'text-slate-500 hover:text-slate-200 border-transparent hover:bg-slate-900/40'
              }`}
              title={
                lang === 'bn'
                  ? (isListening ? 'শোনা বন্ধ করুন' : 'কণ্ঠ দিয়ে খুঁজুন (ভয়েস সার্চ)')
                  : (isListening ? 'Stop listening' : 'Search with voice')
              }
              aria-label={
                lang === 'bn'
                  ? (isListening ? 'ভয়েস সার্চ বন্ধ করুন' : 'ভয়েস সার্চ চালু করুন')
                  : (isListening ? 'Stop voice search' : 'Start voice search')
              }
            >
              <Mic size={16} className={isListening ? 'animate-bounce' : ''} />
            </button>
          )}

          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="text-slate-500 hover:text-slate-300 text-xs font-mono font-bold cursor-pointer h-full px-1"
              aria-label="Clear search query"
            >
              CLEAR
            </button>
          )}
        </div>
      </div>

      {/* Category Filter Title or Accessibility Label */}
      <div className="sr-only">
        {lang === 'bn' ? 'ক্যাটাগরি ফিল্টার করুন' : 'Filter by category'}
      </div>

      {/* Parent horizontal pill scrollable list layout */}
      <div className="relative w-full flex items-center group">
        
        {/* Left Scroll Indicator Arrow */}
        {showLeftFade && (
          <button
            type="button"
            onClick={() => scroll('left')}
            className="absolute left-1 z-20 flex items-center justify-center w-8 h-8 rounded-full bg-[var(--header-bg)] border border-[var(--header-border)] text-amber-400 hover:text-amber-300 shadow-lg shadow-black/40 cursor-pointer active:scale-95 focus:outline-none focus:ring-1 focus:ring-amber-500 transition-all"
            aria-label="Scroll left categories"
          >
            <ChevronLeft size={16} className="stroke-[3]" />
          </button>
        )}

        {/* Left Fade Edge mask gradient */}
        {showLeftFade && (
          <div className="absolute left-0 top-0 bottom-3 w-16 bg-gradient-to-r from-[var(--bg-primary)] to-transparent pointer-events-none z-10" />
        )}

        {/* Horizontal Sliding Category Tabs/Pills */}
        <div
          ref={scrollContainerRef}
          role="tablist"
          aria-label={lang === 'bn' ? 'গীতি ক্যাটাগরি' : 'Lyric Categories'}
          className="w-full overflow-x-auto scrollbar-none flex items-center gap-2 pb-3 select-none scroll-smooth transition-all"
        >
          {/* 'All' Tab */}
          <button
            id={`tab-category-all`}
            role="tab"
            aria-selected={currentCategory === 'all'}
            onClick={() => onSelectCategory('all')}
            className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-semibold transition-all duration-300 cursor-pointer whitespace-nowrap active:scale-95 focus:outline-none focus:ring-2 focus:ring-amber-500/50 ${
              currentCategory === 'all'
                ? 'bg-gradient-to-r from-amber-500 to-amber-300 text-[#011412] font-black shadow-md shadow-amber-500/20 border-transparent scale-102'
                : 'bg-[var(--card-bg)] text-slate-300 border border-[var(--card-border)] hover:text-amber-200 hover:border-amber-500/30'
            }`}
          >
            <span>{lang === 'bn' ? '🔆 সব' : '🔆 All'}</span>
          </button>

          {/* Dynamic section tabs */}
          {sections.map((catKey) => {
            const names = sectionNames[catKey];
            if (!names) return null;
            const displayLabel = lang === 'bn' ? names.bn : names.en;

            // Helper icon based on core Islamic categories
            let iconElement: React.ReactNode = '🎵';
            if (names.icon) {
              const trimmedIcon = names.icon.trim();
              if (
                trimmedIcon.startsWith('http://') ||
                trimmedIcon.startsWith('https://') ||
                trimmedIcon.startsWith('/') ||
                trimmedIcon.startsWith('data:image')
              ) {
                iconElement = (
                  <img
                    src={trimmedIcon}
                    alt=""
                    className="w-4 h-4 object-cover rounded-md pr-0.5"
                    referrerPolicy="no-referrer"
                  />
                );
              } else {
                iconElement = <span className="text-sm select-none">{trimmedIcon}</span>;
              }
            } else {
              let iconEmoji = '🎵';
              if (catKey === 'hamd') iconEmoji = '🕌';
              else if (catKey === 'nat') iconEmoji = '⭐';
              else if (catKey === 'gazal') iconEmoji = '🎤';
              else if (catKey === 'mankabat') iconEmoji = '📿';
              iconElement = <span className="text-sm select-none">{iconEmoji}</span>;
            }

            const isActive = currentCategory === catKey;

            return (
              <button
                key={catKey}
                id={`tab-category-${catKey}`}
                role="tab"
                aria-selected={isActive}
                onClick={() => onSelectCategory(catKey)}
                className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-semibold transition-all duration-300 cursor-pointer whitespace-nowrap active:scale-95 flex items-center gap-1.5 focus:outline-none focus:ring-2 focus:ring-amber-500/50 ${
                  isActive
                    ? 'bg-gradient-to-r from-amber-500 to-amber-300 text-[#011412] font-black shadow-md shadow-amber-500/20 border-transparent scale-102'
                    : 'bg-[var(--card-bg)] text-slate-300 border border-[var(--card-border)] hover:text-amber-200 hover:border-amber-500/30'
                }`}
              >
                <span className="flex items-center gap-1">
                  {iconElement}
                  <span>{displayLabel}</span>
                </span>
              </button>
            );
          })}
        </div>

        {/* Right Fade Edge mask gradient */}
        {showRightFade && (
          <div className="absolute right-0 top-0 bottom-3 w-16 bg-gradient-to-l from-[var(--bg-primary)] to-transparent pointer-events-none z-10" />
        )}

        {/* Right Scroll Indicator Arrow */}
        {showRightFade && (
          <button
            type="button"
            onClick={() => scroll('right')}
            className="absolute right-1 z-20 flex items-center justify-center w-8 h-8 rounded-full bg-[var(--header-bg)] border border-[var(--header-border)] text-amber-400 hover:text-amber-300 shadow-lg shadow-black/40 cursor-pointer active:scale-95 focus:outline-none focus:ring-1 focus:ring-amber-500 transition-all"
            aria-label="Scroll right categories"
          >
            <ChevronRight size={16} className="stroke-[3]" />
          </button>
        )}

      </div>
    </div>
  );
}
