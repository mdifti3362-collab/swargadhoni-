import React, { useState, useRef, useEffect } from 'react';
import { X, Search, Calendar, Award, FileText, CheckCircle, XCircle, User, AlertCircle, Printer, BookOpen, Clock, Medal, GraduationCap, ShieldCheck, Download, LogOut, Trash2, History } from 'lucide-react';
import { Student } from '../types';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { translateToEnglish } from '../utils/translator';

// Helper function to resolve remote images to base64 to completely bypass canvas CORS issues
const getSafeBase64Image = async (url: string): Promise<string> => {
  if (!url) return '';
  if (url.startsWith('data:') || url.startsWith('blob:')) return url;
  try {
    const res = await fetch(url, { mode: 'cors' });
    const blob = await res.blob();
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = () => resolve(''); // Fallback gracefully to prevent failure
      reader.readAsDataURL(blob);
    });
  } catch (err) {
    console.warn("Failed to fetch image via CORS:", url, err);
    // If it fails with CORS, return '' so the download doesn't crash on tainted canvas
    return '';
  }
};

interface StudentPortalModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'bn' | 'en';
  students: Student[];
}

export default function StudentPortalModal({ isOpen, onClose, lang, students }: StudentPortalModalProps) {
  const [searchId, setSearchId] = useState(() => {
    return localStorage.getItem('swarg_student_search_id') || '';
  });
  const [searchedStudent, setSearchedStudent] = useState<Student | null>(null);
  const [searchAttempted, setSearchAttempted] = useState(() => {
    return localStorage.getItem('swarg_student_search_id') ? true : false;
  });
  const [activeTab, setActiveTab] = useState<'attendance' | 'results' | 'certificates'>(() => {
    return (localStorage.getItem('swarg_student_active_tab') as any) || 'attendance';
  });
  const [selectedCertificate, setSelectedCertificate] = useState<any | null>(null);
  const [resolvedCertificateOnScreen, setResolvedCertificateOnScreen] = useState<any | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadedImgUrl, setDownloadedImgUrl] = useState<string | null>(null);
  const printRef = useRef<HTMLDivElement>(null);
  const isInitialMount = useRef(true);

  // Stored profiles on this device
  const [savedProfiles, setSavedProfiles] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('swarg_saved_profiles');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Helper function to append and save student profiles securely to prevent ID loss
  const saveProfileItem = (student: Student) => {
    setSavedProfiles(prev => {
      const filtered = prev.filter(p => p.id !== student.id);
      const updated = [
        {
          id: student.id,
          name: student.name,
          nameBn: student.nameBn || '',
          nameEn: student.nameEn || '',
          photo: student.photo || '',
          mobile: student.mobile || ''
        },
        ...filtered
      ].slice(0, 5); // Limit to top 5 recent profiles
      localStorage.setItem('swarg_saved_profiles', JSON.stringify(updated));
      return updated;
    });
  };

  // Helper to remove profile from device persistence
  const handleRemoveProfile = (profileId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = savedProfiles.filter(p => p.id !== profileId);
    setSavedProfiles(updated);
    localStorage.setItem('swarg_saved_profiles', JSON.stringify(updated));
    if (searchedStudent && searchedStudent.id === profileId) {
      setSearchedStudent(null);
      localStorage.removeItem('swarg_student_search_id');
      localStorage.removeItem('swarg_student_selected_cert_id');
    }
  };

  const handleLoginProfile = (profile: any) => {
    setSearchId(profile.id);
    const found = students.find(s => s.id === profile.id);
    if (found) {
      setSearchedStudent(found);
      setSearchAttempted(true);
      setActiveTab('attendance');
      localStorage.setItem('swarg_student_search_id', found.id);
      saveProfileItem(found);
    }
  };

  // Keep searched student synchronized with latest parent props updates (e.g. Firebase changes)
  useEffect(() => {
    const savedId = localStorage.getItem('swarg_student_search_id');
    const savedCertId = localStorage.getItem('swarg_student_selected_cert_id');

    if (searchedStudent) {
      const latest = students.find(s => s.id === searchedStudent.id);
      if (latest) {
        setSearchedStudent(latest);
        if (selectedCertificate) {
          const updatedCert = (latest.certificates || []).find(c => c.id === selectedCertificate.id);
          if (updatedCert) {
            setSelectedCertificate(updatedCert);
          }
        }
      }
    } else if (savedId && students.length > 0) {
      const found = students.find(s => s.id.toUpperCase() === savedId.trim().toUpperCase() || (s.mobile && s.mobile.includes(savedId.trim().toUpperCase())));
      if (found) {
        setSearchedStudent(found);
        saveProfileItem(found);
        if (savedCertId) {
          const cert = (found.certificates || []).find(c => c.id === savedCertId);
          if (cert) {
            setSelectedCertificate(cert);
          }
        }
      }
    }
  }, [students, searchedStudent?.id, selectedCertificate?.id]);

  // Persist active tab changes
  useEffect(() => {
    localStorage.setItem('swarg_student_active_tab', activeTab);
  }, [activeTab]);

  // Persist selected certificate changes
  useEffect(() => {
    if (isInitialMount.current) {
      isInitialMount.current = false;
      return;
    }
    if (selectedCertificate) {
      localStorage.setItem('swarg_student_selected_cert_id', selectedCertificate.id);
    } else {
      localStorage.removeItem('swarg_student_selected_cert_id');
    }
  }, [selectedCertificate]);

  // Background resolver for certificate images to prevent canvas CORS errors
  useEffect(() => {
    if (!selectedCertificate) {
      setResolvedCertificateOnScreen(null);
      return;
    }
    
    setResolvedCertificateOnScreen(selectedCertificate);
    
    let isMounted = true;
    const resolveImages = async () => {
      const updated = { ...selectedCertificate };
      
      const promises = [];
      if (selectedCertificate.watermarkUrl) {
        promises.push(getSafeBase64Image(selectedCertificate.watermarkUrl).then(b64 => {
          if (b64) updated.watermarkUrl = b64;
        }));
      }
      if (selectedCertificate.signatureUrl) {
        promises.push(getSafeBase64Image(selectedCertificate.signatureUrl).then(b64 => {
          if (b64) updated.signatureUrl = b64;
        }));
      }
      if (selectedCertificate.sealUrl) {
        promises.push(getSafeBase64Image(selectedCertificate.sealUrl).then(b64 => {
          if (b64) updated.sealUrl = b64;
        }));
      }
      
      if (promises.length > 0) {
        await Promise.all(promises);
        if (isMounted) {
          setResolvedCertificateOnScreen(updated);
        }
      }
    };
    
    resolveImages();
    return () => {
      isMounted = false;
    };
  }, [selectedCertificate]);

  if (!isOpen) return null;

  const handleDownloadCertificateImage = async () => {
    if (!printRef.current || !selectedCertificate) return;
    try {
      setIsDownloading(true);
      const element = printRef.current;
      
      const options = {
        useCORS: true,
        allowTaint: false,
        backgroundColor: '#fffdf9',
        scale: 4, // Extremely high resolution crisp image
        logging: false,
        width: 520,
        height: 370,
        scrollX: 0,
        scrollY: 0
      };
      
      const canvas = await html2canvas(element, options);
      const imgData = canvas.toDataURL('image/png', 1.0);
      
      setDownloadedImgUrl(imgData);
      
      const link = document.createElement('a');
      const filename = `${searchedStudent?.nameEn || 'student'}_certificate_${selectedCertificate.id || 'doc'}.png`;
      link.download = filename;
      link.href = imgData;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Error downloading image certificate:', error);
      alert(lang === 'bn' ? 'সার্টিফিকেট ডাউনলোড করতে ব্যর্থ হয়েছে। দয়া করে আবার চেষ্টা করুন।' : 'Failed to download certificate. Please try again.');
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDownloadCertificatePDF = async () => {
    if (!printRef.current || !selectedCertificate) return;
    try {
      setIsDownloading(true);
      const element = printRef.current;
      
      const options = {
        useCORS: true,
        allowTaint: false,
        backgroundColor: '#fffdf9',
        scale: 4, // High definition capture for PDF embedding
        logging: false,
        width: 520,
        height: 370,
        scrollX: 0,
        scrollY: 0
      };
      
      const canvas = await html2canvas(element, options);
      const imgData = canvas.toDataURL('image/png', 1.0);
      
      // Landscape design orientation
      const pdf = new jsPDF({
        orientation: 'landscape',
        unit: 'px',
        format: [520, 370]
      });
      
      pdf.addImage(imgData, 'PNG', 0, 0, 520, 370);
      
      const filename = `${searchedStudent?.nameEn || 'student'}_certificate_${selectedCertificate.id || 'doc'}.pdf`;
      pdf.save(filename);
    } catch (error) {
      console.error('Error downloading PDF certificate:', error);
      alert(lang === 'bn' ? 'পিডিএফ ডাউনলোড করতে ব্যর্থ হয়েছে। দয়া করে আবার চেষ্টা করুন।' : 'Failed to download PDF certificate. Please try again.');
    } finally {
      setIsDownloading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchAttempted(true);
    const id = searchId.trim().toUpperCase();
    const found = students.find(s => s.id.toUpperCase() === id || (s.mobile && s.mobile.includes(id)));
    if (found) {
      setSearchedStudent(found);
      setActiveTab('attendance');
      localStorage.setItem('swarg_student_search_id', found.id);
      saveProfileItem(found);
    } else {
      setSearchedStudent(null);
      localStorage.removeItem('swarg_student_search_id');
      localStorage.removeItem('swarg_student_selected_cert_id');
    }
  };

  // Calculate attendance details
  const getAttendanceStats = (student: Student) => {
    const attendance = student.attendance || {};
    const dates = Object.keys(attendance);
    const presentCount = dates.filter(d => attendance[d] === 'present').length;
    const absentCount = dates.filter(d => attendance[d] === 'absent').length;
    const totalCount = dates.length;
    const percentage = totalCount > 0 ? Math.round((presentCount / totalCount) * 100) : 0;

    return { presentCount, absentCount, totalCount, percentage, list: dates.map(d => ({ date: d, status: attendance[d] })).sort((a,b) => b.date.localeCompare(a.date)) };
  };

  const handlePrintCertificate = () => {
    const win = window.open('', '_blank');
    const activeCert = resolvedCertificateOnScreen || selectedCertificate;
    if (win && activeCert) {
      win.document.write(`
        <html>
          <head>
            <title>Certificate - ${searchedStudent?.nameBn || searchedStudent?.name}</title>
            <style>
              @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&family=Noto+Serif+Bengali:wght@400;700&display=swap');
              body {
                margin: 0;
                padding: 10px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-family: 'Inter', 'Noto Serif Bengali', serif;
                background-color: #faf9f6;
              }
              .cert-container {
                width: 800px;
                height: 560px;
                padding: 40px;
                position: relative;
                border: 12px double #0d5c3a;
                background: #fffdf9;
                box-sizing: border-box;
                text-align: center;
                box-shadow: 0 4px 20px rgba(0,0,0,0.08);
                overflow: hidden;
              }
              .cert-inner-border {
                position: absolute;
                top: 8px;
                left: 8px;
                right: 8px;
                bottom: 8px;
                border: 2px solid #b8860b;
                pointer-events: none;
              }
              /* Golden Corner Brackets */
              .cert-corner {
                position: absolute;
                width: 25px;
                height: 25px;
                border-color: rgba(184, 134, 11, 0.85);
                border-style: solid;
                pointer-events: none;
                z-index: 5;
              }
              .corner-tl { top: 12px; left: 12px; border-width: 3px 0 0 3px; border-top-left-radius: 2px; }
              .corner-tr { top: 12px; right: 12px; border-width: 3px 3px 0 0; border-top-right-radius: 2px; }
              .corner-bl { bottom: 12px; left: 12px; border-width: 0 0 3px 3px; border-bottom-left-radius: 2px; }
              .corner-br { bottom: 12px; right: 12px; border-width: 0 3px 3px 0; border-bottom-right-radius: 2px; }

              .cert-bg-logo-img {
                position: absolute;
                bottom: 35px;
                left: 50%;
                transform: translateX(-50%);
                z-index: 1;
                pointer-events: none;
                user-select: none;
                opacity: 0.16;
                max-width: 250px;
                max-height: 120px;
                object-fit: contain;
              }
              .cert-header {
                font-size: 13px;
                text-transform: uppercase;
                letter-spacing: 2.5px;
                color: #0d5c3a;
                margin-top: 5px;
                font-weight: 700;
                font-family: 'Inter', sans-serif;
              }
              .institute-name {
                font-size: 28px;
                font-weight: 950;
                color: #0d5c3a;
                margin: 4px 0 2px 0;
                letter-spacing: 1px;
                font-family: 'Noto Serif Bengali', 'Inter', serif;
              }
              /* Center Divider Decor */
              .heading-separator {
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
                margin: 8px auto;
              }
              .heading-separator-line {
                width: 60px;
                border-bottom: 1.5px solid rgba(184, 134, 11, 0.4);
              }
              .heading-separator-text {
                color: #b8860b;
                font-size: 11px;
              }
              .cert-title {
                display: inline-block;
                padding: 10px 30px;
                border: 1px solid rgba(184, 134, 11, 0.35);
                background: linear-gradient(to right, rgba(184, 134, 11, 0.03), rgba(184, 134, 11, 0.08), rgba(184, 134, 11, 0.03));
                border-radius: 4px;
                margin: 10px auto;
                font-family: 'Noto Serif Bengali', 'Inter', sans-serif;
              }
              .cert-title-text {
                font-size: 20px;
                font-weight: 900;
                color: #8b6508;
                letter-spacing: 2.5px;
                text-transform: uppercase;
                line-height: 1;
              }
              .presented-to {
                font-size: 13px;
                font-style: italic;
                color: #666;
                margin: 12px 0;
              }
              .student-name {
                font-size: 30px;
                font-weight: 850;
                color: #0c4027;
                margin: 6px 0;
                font-family: 'Noto Serif Bengali', 'Inter', sans-serif;
              }
              .cert-id {
                font-size: 10px;
                color: #777;
                font-family: monospace;
                margin-top: -2px;
                letter-spacing: 0.5px;
              }
              .cert-text {
                font-size: 13.5px;
                color: #333;
                line-height: 1.7;
                margin: 15px auto;
                max-width: 620px;
                font-family: 'Noto Serif Bengali', 'Inter', sans-serif;
                font-weight: 500;
              }
              .cert-footer {
                display: flex;
                justify-content: space-between;
                align-items: flex-end;
                margin-top: 25px;
                padding: 0 45px;
                position: relative;
                z-index: 10;
              }
              .cert-footer-col {
                width: 45%;
                display: flex;
                flex-direction: column;
                justify-content: flex-end;
              }
              .col-left {
                align-items: flex-start;
                text-align: left;
              }
              .col-center {
                align-items: center;
                text-align: center;
              }
              .col-right {
                align-items: flex-end;
                text-align: right;
              }
              .footer-inner-block {
                text-align: center;
                width: 170px;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: flex-end;
              }
              .signature-line {
                border-top: 1px solid #ccc;
                margin-top: 30px;
                padding-top: 5px;
                font-size: 11px;
                color: #555;
                font-weight: 600;
                text-transform: uppercase;
                width: 100%;
                font-family: 'Noto Serif Bengali', 'Inter', sans-serif;
              }
              .gold-seal {
                width: 95px;
                height: 95px;
                display: flex;
                align-items: center;
                justify-content: center;
                transform: rotate(-8deg);
                text-align: center;
                box-sizing: border-box;
                font-family: 'Noto Serif Bengali', 'Inter', sans-serif;
              }
              .gold-seal-inner {
                width: 90px;
                height: 90px;
                background: radial-gradient(circle, #ffd700 0%, #b8860b 100%);
                border-radius: 50%;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                color: #fff;
                font-weight: bold;
                border: 4px double #fff;
                box-shadow: 0 4px 10px rgba(184, 134, 11, 0.35);
                padding: 6px;
                box-sizing: border-box;
              }
              .gold-seal-inner .seal-label {
                font-size: 7px;
                font-weight: normal;
                opacity: 0.9;
                text-transform: uppercase;
                letter-spacing: 0.5px;
              }
              .gold-seal-inner .seal-name {
                font-size: 9px;
                font-weight: 800;
                line-height: 1.1;
                margin-top: 1px;
              }
              @media print {
                body {
                  background-color: #fff;
                  -webkit-print-color-adjust: exact;
                  print-color-adjust: exact;
                }
                .cert-container {
                   box-shadow: none;
                   background: #fffdf9 !important;
                   border: 12px double #0d5c3a !important;
                }
              }
            </style>
          </head>
          <body onload="window.print()">
            <div class="cert-container">
              <div class="cert-inner-border"></div>
              
              <!-- Traditional Corner Ornaments -->
              <div class="cert-corner corner-tl"></div>
              <div class="cert-corner corner-tr"></div>
              <div class="cert-corner corner-bl"></div>
              <div class="cert-corner corner-br"></div>
              
              ${activeCert.watermarkUrl 
                ? `<img class="cert-bg-logo-img" src="${activeCert.watermarkUrl}" />` 
                : `<div class="cert-bg-logo-img" style="opacity: 0.04; font-size: 110px; display: flex; align-items: center; justify-content: center; bottom: 20px; line-height: 1;">🕌</div>`
              }
              
              <div class="cert-header">${lang === 'bn' ? 'ইসলামি সংগীত চর্চা কেন্দ্র' : 'ISLAMIC MUSIC TRAINING CENTER'}</div>
              <div class="institute-name">${lang === 'bn' ? 'স্বর্গধ্বনি একাডেমি' : 'SWARGADHUNI ACADEMY'}</div>
              
              <!-- Separator decoration -->
              <div class="heading-separator">
                <div class="heading-separator-line"></div>
                <div class="heading-separator-text">✦ 🕌 ✦</div>
                <div class="heading-separator-line"></div>
              </div>

              <!-- Banner Accreditation badge -->
              <div class="cert-title">
                <div class="cert-title-text">${activeCert.certificateName}</div>
              </div>
              
              <div class="presented-to">${lang === 'bn' ? 'এই অনন্য গৌরবময় সনদপত্রটি সসম্মানে প্রদান করা হলো' : 'This certificate of merit is proudly presented to'}</div>
              <div class="student-name">${searchedStudent?.nameBn || searchedStudent?.name || ''}</div>
              <div class="cert-id">Student ID: ${searchedStudent?.id}</div>
              
              <div class="cert-text">
                ${activeCert.details || (lang === 'bn' 
                  ? `সফলতার সাথে কোর্স সম্পাদন এবং আদর্শ ধর্মীয় শিক্ষা ও নিয়মানুবর্তিতা অনুসরণের স্বীকৃতিস্বরূপ এই বিশেষ যোগ্যতাপত্র মঞ্জুর করা হলো। আমরা তাঁর জীবনে উত্তরোত্তর আধ্যাত্মিক ও জাগতিক সাফল্য কামনা করি।` 
                  : `In recognition of outstanding performance, religious conduct, diligent pursuit of knowledge, and moral rectitude demonstrated during the course curriculum. We wish them continuous progress in all future endeavors.`)}
              </div>
              
              <div class="cert-footer">
                <!-- Column 1: Signature aligned left -->
                <div class="cert-footer-col col-left">
                  <div class="footer-inner-block">
                    ${activeCert.signatureUrl ? `<img src="${activeCert.signatureUrl}" style="height: 45px; width: auto; max-width: 150px; object-fit: contain; margin-bottom: -5px;" />` : `<div style="height: 45px;"></div>`}
                    ${activeCert.signatureTitle ? `<div style="font-size: 9px; font-weight: bold; color: #333; margin-top: 4px; line-height: 1.1; font-family: sans-serif; white-space: nowrap;">${activeCert.signatureTitle}</div>` : ''}
                    <div class="signature-line" style="${activeCert.signatureUrl || activeCert.signatureTitle ? 'margin-top: 2px;' : 'margin-top: 30px;'}">
                      ${lang === 'bn' ? 'কর্তৃপক্ষ স্বাক্ষর' : 'Authorized Signature'}
                    </div>
                  </div>
                </div>
                
                <!-- Column 2: Date aligned right -->
                <div class="cert-footer-col col-right">
                  <div class="footer-inner-block">
                    <div style="font-size: 13px; font-weight: 700; color: #111; margin-bottom: 2px; font-family: monospace;">${activeCert.issueDate}</div>
                    <div class="signature-line" style="margin-top: 30px;">
                      ${lang === 'bn' ? 'ইস্যু তারিখ' : 'Issue Date'}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </body>
        </html>
      `);
      win.document.close();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-2xl bg-gradient-to-b from-[#012d25] to-[#011411] border border-emerald-500/20 rounded-3xl shadow-2xl relative flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-5 border-b border-emerald-500/15 flex justify-between items-center">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400">
              <GraduationCap size={20} />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-slate-100 tracking-tight">
                {lang === 'bn' ? 'শিক্ষার্থী পোর্টাল' : 'Student Portal'}
              </h3>
              <p className="text-[11px] text-teal-400 font-sans mt-0.5">
                {lang === 'bn' ? 'হাজিরা রেকর্ড, পরীক্ষার ফলাফল ও সার্টিফিকেট যাচাই' : 'Retrieve stats, grades, and certification verification'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center bg-[#011e19] text-slate-400 hover:text-blue-400 transition-colors cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        {/* Portal Body */}
        <div className="p-6 overflow-y-auto flex-1 flex flex-col gap-5">
          
          {/* Search Form */}
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-teal-600/60 w-4 h-4" />
              <input
                type="text"
                required
                value={searchId}
                onChange={(e) => setSearchId(e.target.value)}
                placeholder={lang === 'bn' ? 'স্টুডেন্ট আইডি (যেমন: STD562214) বা মোবাইল নম্বর দিন...' : 'Enter Student ID (e.g. STD562214) or mobile...'}
                className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-blue-500/50 rounded-xl pl-10 pr-4 py-3 text-xs sm:text-sm text-slate-100 placeholder-teal-600/40 outline-none transition-all focus:shadow-md focus:shadow-blue-500/5"
              />
            </div>
            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-500 text-white px-5 rounded-xl font-bold text-xs sm:text-sm transition-all shadow-md active:scale-95 flex items-center gap-1.5 cursor-pointer"
            >
              <Search size={14} />
              <span>{lang === 'bn' ? 'খুঁজুন' : 'Search'}</span>
            </button>
          </form>

          {/* Saved Profiles Quick Access List */}
          {!searchedStudent && savedProfiles.length > 0 && (
            <div className="bg-[#000d0b]/40 border border-emerald-500/10 rounded-2xl p-4 animate-in fade-in slide-in-from-top-3 duration-300">
              <div className="flex items-center gap-2 mb-3">
                <History size={13} className="text-teal-400" />
                <span className="text-[11px] font-extrabold text-teal-400 uppercase tracking-wider font-sans">
                  {lang === 'bn' ? 'সংরক্ষিত প্রোফাইলসমূহ' : 'Saved Student Profiles'}
                </span>
                <span className="text-[9px] text-teal-500/50 font-sans ml-auto">
                  {lang === 'bn' ? 'দ্রুত প্রবেশ করুন' : 'Quick Access'}
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {savedProfiles.map(p => (
                  <div
                    key={p.id}
                    onClick={() => handleLoginProfile(p)}
                    className="bg-[#001713] hover:bg-[#002d24] border border-emerald-500/15 hover:border-emerald-500/35 rounded-xl p-2.5 flex items-center justify-between gap-2.5 transition-all cursor-pointer group hover:scale-[1.01]"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-lg border border-teal-500/10 overflow-hidden shrink-0 flex items-center justify-center bg-[#011411]">
                        {p.photo ? (
                          <img src={p.photo} alt="Student" className="w-full h-full object-cover" />
                        ) : (
                          <User size={15} className="text-teal-500/40" />
                        )}
                      </div>
                      <div className="text-left min-w-0">
                        <h5 className="text-[12px] font-black text-slate-200 group-hover:text-blue-400 transition-colors truncate">
                          {lang === 'bn' ? p.nameBn || p.name : p.nameEn || p.name}
                        </h5>
                        <p className="text-[9px] text-slate-400 font-mono flex items-center gap-2 mt-0.5">
                          <span>ID: {p.id}</span>
                          {p.mobile && <span>• 📞 {p.mobile}</span>}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={(e) => handleRemoveProfile(p.id, e)}
                      className="p-1 rounded-md text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-colors cursor-pointer"
                      title={lang === 'bn' ? 'ডিভাইস থেকে মুছুন' : 'Remove from device'}
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Result Block */}
          {!searchedStudent ? (
            searchAttempted ? (
              <div className="flex flex-col items-center justify-center text-center py-12 gap-3 animate-in fade-in zoom-in-95 duration-200">
                <div className="w-14 h-14 rounded-full bg-red-500/15 flex items-center justify-center text-red-400">
                  <AlertCircle size={26} />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-200">
                    {lang === 'bn' ? 'শিক্ষার্থী পাওয়া যায়নি!' : 'Student Not Found!'}
                  </h4>
                  <p className="text-xs text-slate-500 max-w-sm mt-1">
                    {lang === 'bn' 
                      ? 'আমরা এই আইডি বা মোবাইল নম্বরে কোনো শিক্ষার্থী খুঁজে পাইনি। অনুগ্রহ করে সঠিক তথ্য প্রদান করুন।' 
                      : 'We could not find any active enrollments matching this ID or mobile. Double check and try again.'}
                  </p>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center text-center py-16 gap-3 text-slate-500">
                <Medal size={42} className="text-teal-600/30 animate-bounce duration-3000" />
                <p className="text-xs sm:text-sm italic">
                  {lang === 'bn' 
                    ? 'আপনার স্টুডেন্ট আইডি নাম্বার দিয়ে সরাসরি অনুসন্ধান করুন।' 
                    : 'Search with your unique student enrollment credentials to access records.'}
                </p>
              </div>
            )
          ) : (
            <div className="flex flex-col gap-5 animate-in fade-in duration-300">
              
              {/* Student Profile Card Header */}
              <div className="bg-[#000d0b]/40 border border-emerald-500/10 rounded-2xl p-4 flex flex-col sm:flex-row gap-4 items-center sm:items-start text-center sm:text-left relative">
                
                {/* Log Out / Exit action */}
                <button
                  type="button"
                  onClick={() => {
                    setSearchedStudent(null);
                    localStorage.removeItem('swarg_student_search_id');
                    localStorage.removeItem('swarg_student_selected_cert_id');
                  }}
                  className="absolute top-3 right-3 p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white border border-red-500/20 transition-all flex items-center gap-1 cursor-pointer"
                  title={lang === 'bn' ? 'প্রোফাইল থেকে বের হোন' : 'Exit and log out from profile'}
                >
                  <LogOut size={13} />
                  <span className="text-[10px] font-bold hidden sm:inline">{lang === 'bn' ? 'প্রস্থান' : 'Exit'}</span>
                </button>

                {/* Avatar */}
                <div className="w-16 h-16 rounded-2xl border border-blue-500/20 overflow-hidden shrink-0 bg-[#001713] flex items-center justify-center">
                  {searchedStudent.photo ? (
                    <img src={searchedStudent.photo} alt={searchedStudent.name} className="w-full h-full object-cover" />
                  ) : (
                    <User size={28} className="text-blue-500/50" />
                  )}
                </div>
                
                <div className="flex-1 min-w-0 pr-0 sm:pr-12">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-1.5 sm:gap-2 mb-1 justify-center sm:justify-start">
                    <h4 className="text-sm font-black text-slate-200 flex items-center gap-2">
                      {searchedStudent.nameBn || searchedStudent.name}
                    </h4>
                    {searchedStudent.nameEn && (
                      <span className="text-xs text-slate-400 font-sans">({searchedStudent.nameEn})</span>
                    )}
                    <span className="text-[10px] font-mono text-blue-400 bg-blue-500/10 border border-blue-500/20 px-2 py-0.5 rounded-full inline-block mt-1 sm:mt-0 w-max mx-auto sm:mx-0">
                      ID: {searchedStudent.id}
                    </span>
                    
                    {/* Status Badge */}
                    <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded-full inline-block border ${
                      searchedStudent.status === 'old' || searchedStudent.status === 'completed'
                        ? 'bg-slate-500/10 text-slate-400 border-slate-500/20'
                        : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                    }`}>
                      {searchedStudent.status === 'old' || searchedStudent.status === 'completed'
                        ? (lang === 'bn' ? '🎓 পুরাতন শিক্ষার্থী' : '🎓 Old Student')
                        : (lang === 'bn' ? '🟢 সক্রিয় শিক্ষার্থী' : '🟢 Active Student')
                      }
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1.5 text-xs text-slate-400 font-sans mt-2">
                    {searchedStudent.fatherName && (
                      <div>👨‍👦 {lang === 'bn' ? 'পিতা: ' : 'Father: '}{searchedStudent.fatherName}</div>
                    )}
                    {searchedStudent.motherName && (
                      <div>👩‍👦 {lang === 'bn' ? 'মাতা: ' : 'Mother: '}{searchedStudent.motherName}</div>
                    )}
                    <div>📞 {lang === 'bn' ? 'মোবাইল: ' : 'Mobile: '}{searchedStudent.mobile}</div>
                    <div className="truncate">📍 {lang === 'bn' ? 'ঠিকানা: ' : 'Address: '}{searchedStudent.address}</div>
                    
                    {/* Batch, class days and duration info */}
                    {searchedStudent.batchTime && (
                      <div>⏰ {lang === 'bn' ? 'ব্যাচ টাইম: ' : 'Batch Time: '}<span className="text-slate-200 font-medium">{searchedStudent.batchTime}</span></div>
                    )}
                    {searchedStudent.classDaysPerWeek && (
                      <div>📅 {lang === 'bn' ? 'সাপ্তাহিক ক্লাস: ' : 'Weekly Classes: '}<span className="text-slate-200 font-medium">{searchedStudent.classDaysPerWeek}</span></div>
                    )}
                    {searchedStudent.courseDuration && (
                      <div className="sm:col-span-2">🎓 {lang === 'bn' ? 'কোর্সের মেয়াদ: ' : 'Course Duration: '}<span className="text-slate-200 font-medium">{searchedStudent.courseDuration}</span></div>
                    )}
                  </div>
                </div>
              </div>

              {/* TABS SELECTOR (Attendance | Results | Certificates) */}
              <div className="border-b border-emerald-500/15 flex gap-1 font-semibold text-xs">
                <button
                  onClick={() => { setActiveTab('attendance'); setSelectedCertificate(null); }}
                  className={`px-4 py-2.5 rounded-t-xl transition-all cursor-pointer flex items-center gap-1.5 border-t-2 ${
                    activeTab === 'attendance'
                      ? 'bg-[#000d0b]/40 text-blue-400 border-blue-500'
                      : 'text-slate-400 hover:text-slate-200 border-transparent hover:bg-emerald-500/5'
                  }`}
                >
                  <Calendar size={13} />
                  <span>{lang === 'bn' ? 'হা‌জিরা / উপস্থিতি' : 'Attendance'}</span>
                </button>
                <button
                  onClick={() => { setActiveTab('results'); setSelectedCertificate(null); }}
                  className={`px-4 py-2.5 rounded-t-xl transition-all cursor-pointer flex items-center gap-1.5 border-t-2 ${
                    activeTab === 'results'
                      ? 'bg-[#000d0b]/40 text-amber-400 border-amber-500'
                      : 'text-slate-400 hover:text-slate-200 border-transparent hover:bg-emerald-500/5'
                  }`}
                >
                  <FileText size={13} />
                  <span>{lang === 'bn' ? 'পরীক্ষার ফলাফল' : 'Exam Results'}</span>
                </button>
                <button
                  onClick={() => { setActiveTab('certificates'); setSelectedCertificate(null); }}
                  className={`px-4 py-2.5 rounded-t-xl transition-all cursor-pointer flex items-center gap-1.5 border-t-2 ${
                    activeTab === 'certificates'
                      ? 'bg-[#000d0b]/40 text-emerald-400 border-emerald-500'
                      : 'text-slate-400 hover:text-slate-200 border-transparent hover:bg-emerald-500/5'
                  }`}
                >
                  <Award size={13} />
                  <span>{lang === 'bn' ? 'সনদপত্র / সার্টিফিকেট' : 'Certificates'}</span>
                </button>
              </div>

              {/* TAB PANEL CONTENT */}
              <div className="bg-[#000d0b]/25 rounded-2xl p-4 border border-emerald-500/5 min-h-[220px]">
                
                {/* 1. Attendance Panel */}
                {activeTab === 'attendance' && (() => {
                  const stats = getAttendanceStats(searchedStudent);
                  return (
                    <div className="flex flex-col gap-4 animate-in fade-in duration-200">
                      
                      {/* Attendance Ring Cards */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                        <div className="bg-[#002d24]/30 border border-blue-500/10 p-3 rounded-xl text-center">
                          <div className="text-[10px] uppercase tracking-wider text-slate-400 font-mono font-bold">
                            {lang === 'bn' ? 'মোট হাজিরা দিন' : 'Total Tracked'}
                          </div>
                          <div className="text-xl font-extrabold text-slate-100 font-sans mt-0.5">{stats.totalCount}</div>
                        </div>
                        <div className="bg-[#002d24]/30 border border-emerald-500/10 p-3 rounded-xl text-center">
                          <div className="text-[10px] uppercase tracking-wider text-[#34d399] font-mono font-bold">
                            {lang === 'bn' ? 'উপস্থিত' : 'Present'}
                          </div>
                          <div className="text-xl font-extrabold text-emerald-400 font-sans mt-0.5">{stats.presentCount}</div>
                        </div>
                        <div className="bg-[#002d24]/30 border border-red-500/10 p-3 rounded-xl text-center">
                          <div className="text-[10px] uppercase tracking-wider text-red-400 font-mono font-bold">
                            {lang === 'bn' ? 'অনুপস্থিত' : 'Absent'}
                          </div>
                          <div className="text-xl font-extrabold text-red-400 font-sans mt-0.5">{stats.absentCount}</div>
                        </div>
                        <div className="bg-[#002d24]/30 border border-purple-500/10 p-3 rounded-xl text-center">
                          <div className="text-[10px] uppercase tracking-wider text-purple-400 font-mono font-bold">
                            {lang === 'bn' ? 'উপস্থিতির হার' : 'Percentage'}
                          </div>
                          <div className="text-xl font-extrabold text-purple-400 font-sans mt-0.5">{stats.percentage}%</div>
                        </div>
                      </div>

                      {/* Detail Days Log */}
                      <div>
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                          📅 {lang === 'bn' ? 'হালনাগাদ হাজিরা লগ তালিকা' : 'Detailed Log Roll'}
                        </span>
                        
                        {stats.list.length === 0 ? (
                          <div className="py-8 text-center text-xs text-slate-500">
                            {lang === 'bn' ? 'কোনো হাজিরার তথ্য রেকর্ড পাওয়া যায়নি।' : 'No attendance log records registered.'}
                          </div>
                        ) : (
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-2 max-h-[140px] overflow-y-auto pr-1">
                            {stats.list.map((day, idx) => (
                              <div 
                                key={idx} 
                                className={`flex items-center justify-between p-2 rounded-lg border text-xs font-mono ${
                                  day.status === 'present' 
                                    ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-400' 
                                    : 'bg-red-500/5 border-red-500/20 text-red-400'
                                }`}
                              >
                                <span className="flex items-center gap-1">
                                  {day.status === 'present' ? <CheckCircle size={10} /> : <XCircle size={10} />}
                                  {day.date}
                                </span>
                                <span className="text-[9px] font-bold uppercase font-sans">
                                  {day.status === 'present' ? (lang === 'bn' ? 'উপস্থিত' : 'Present') : (lang === 'bn' ? 'অনুপস্থিত' : 'Absent')}
                                </span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })()}

                {/* 2. Results Panel */}
                {activeTab === 'results' && (() => {
                  const results = searchedStudent.results || [];
                  return (
                    <div className="flex flex-col gap-3.5 animate-in fade-in duration-200">
                      <div className="flex items-center justify-between border-b border-emerald-500/5 pb-2">
                        <span className="text-[10px] font-bold text-[#f59e0b] uppercase tracking-widest font-mono flex items-center gap-1">
                          <BookOpen size={12} />
                          {lang === 'bn' ? 'প্রকাশিত পরীক্ষার গ্রেড সীট' : 'Published Grade Records'}
                        </span>
                        <span className="text-[10px] font-bold text-slate-500">
                          {results.length} EXAMS FOUND
                        </span>
                      </div>

                      {results.length === 0 ? (
                        <div className="py-12 text-center text-xs text-slate-500 flex flex-col items-center justify-center gap-2">
                          <Clock size={24} className="text-amber-500/40" />
                          {lang === 'bn' ? 'রেজাল্ট তালিকা এখনো কোনো রেকর্ড আপডেট করা হয়নি।' : 'No verified grade cards uploaded by administration.'}
                        </div>
                      ) : (
                        <div className="flex flex-col gap-2 max-h-[220px] overflow-y-auto pr-1">
                          {results.map((res: any, idx) => (
                            <div key={res.id || idx} className="p-3 bg-[#011411]/80 border border-amber-500/10 rounded-xl flex items-center justify-between hover:border-amber-500/30 transition-all">
                              <div className="min-w-0">
                                <h5 className="text-xs font-black text-slate-100">{res.examName}</h5>
                                <div className="text-[10px] text-slate-500 font-sans mt-0.5 flex items-center gap-2 font-mono">
                                  <span>📅 {res.date}</span>
                                </div>
                              </div>
                              <div className="flex items-center gap-3">
                                <div className="text-right">
                                  <div className="text-xs text-amber-400 font-extrabold font-mono">{res.marks} Mark</div>
                                  <div className="text-[10px] text-slate-400 font-sans">Score Achieved</div>
                                </div>
                                <div className="w-10 h-10 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/15 flex items-center justify-center text-xs font-black font-mono">
                                  {res.grade}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })()}

                {/* 3. Certificates Panel */}
                {activeTab === 'certificates' && (() => {
                  const certificates = searchedStudent.certificates || [];
                  return (
                    <div className="flex flex-col gap-3.5 animate-in fade-in duration-200">
                      
                      {!selectedCertificate ? (
                        <>
                          <div className="flex items-center justify-between border-b border-emerald-500/5 pb-2">
                            <span className="text-[10px] font-bold text-[#10b981] uppercase tracking-widest font-mono flex items-center gap-1">
                              <Medal size={12} />
                              {lang === 'bn' ? 'প্রদত্ত প্রশংসাপত্র ও কোর্স সনদ' : 'Special Credentials & Certifications'}
                            </span>
                            <span className="text-[10px] font-bold text-slate-500">
                              {certificates.length} ISSUED
                            </span>
                          </div>

                          {certificates.length === 0 ? (
                            <div className="py-12 text-center text-xs text-slate-500 flex flex-col items-center justify-center gap-2 animate-pulse">
                              <ShieldCheck size={28} className="text-emerald-500/30" />
                              {lang === 'bn' ? 'অনুমোদিত কোনো সনদপত্র এই মুহূর্তে পাওয়া যায়নি।' : 'No professional certificates or accolades generated yet.'}
                            </div>
                          ) : (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[220px] overflow-y-auto pr-1">
                              {certificates.map((cert: any, idx) => (
                                <div 
                                  key={cert.id || idx} 
                                  className="p-3.5 bg-[#011411]/80 border border-emerald-500/10 hover:border-emerald-500/40 rounded-xl flex flex-col gap-2.5 transition-all relative group"
                                >
                                  <div className="min-w-0">
                                    <h5 className="text-xs font-extrabold text-[#34d399] tracking-tight truncate">📜 {cert.certificateName}</h5>
                                    <span className="text-[9px] font-mono text-slate-500 block mt-0.5">Issue: {cert.issueDate}</span>
                                    {cert.details && (
                                      <p className="text-[10px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                                        {cert.details}
                                      </p>
                                    )}
                                  </div>
                                  
                                  <button
                                    onClick={() => setSelectedCertificate(cert)}
                                    className="w-full bg-[#001713] hover:bg-[#10b981] text-emerald-400 hover:text-[#011411] font-bold text-[10px] px-2 py-1.5 rounded-lg transition-colors flex items-center justify-center gap-1 mt-auto cursor-pointer border border-emerald-500/20"
                                  >
                                    <ShieldCheck size={11} />
                                    <span>{lang === 'bn' ? 'সার্টিফিকেট সনদ দেখুন' : 'Verify Certificate'}</span>
                                  </button>
                                </div>
                              ))}
                            </div>
                          )}
                        </>
                      ) : (
                        /* Premium Interactive Live Digital Certificate Mockup View */
                        <div className="flex flex-col gap-4 animate-in zoom-in-95 duration-200 font-sans">
                          {/* Close Certificate view link */}
                          <div className="flex flex-col sm:flex-row gap-2 sm:items-center justify-between bg-[#001f1a]/85 border border-emerald-500/20 px-3.5 py-2.5 rounded-xl">
                            <span className="text-[10px] font-mono text-teal-400 uppercase font-black">
                              🔒 VERIFIED CREATION ID
                            </span>
                            <div className="flex flex-wrap gap-1.5">
                              <button
                                onClick={handleDownloadCertificateImage}
                                disabled={isDownloading}
                                className="px-3 py-1 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-slate-950 font-black rounded-lg text-[10px] flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer uppercase animate-pulse"
                              >
                                {isDownloading ? (
                                  <span className="inline-block animate-spin mr-0.5">🌀</span>
                                ) : (
                                  <Download size={10} />
                                )}
                                <span>{lang === 'bn' ? 'ছবি ডাউনলোড করুন' : 'Download Image'}</span>
                              </button>
                              <button
                                onClick={handleDownloadCertificatePDF}
                                disabled={isDownloading}
                                className="px-3 py-1 bg-blue-500 hover:bg-blue-600 disabled:opacity-50 text-white font-black rounded-lg text-[10px] flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer uppercase"
                              >
                                {isDownloading ? (
                                  <span className="inline-block animate-spin mr-0.5">🌀</span>
                                ) : (
                                  <FileText size={10} />
                                )}
                                <span>{lang === 'bn' ? 'পিডিএফ ডাউনলোড' : 'Download PDF'}</span>
                              </button>
                              <button
                                onClick={handlePrintCertificate}
                                className="px-3 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-lg text-[10px] flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer uppercase"
                              >
                                <Printer size={10} />
                                <span>{lang === 'bn' ? 'সনদ প্রিন্ট করুন' : 'Print Certificate'}</span>
                              </button>
                              <button
                                onClick={() => setSelectedCertificate(null)}
                                className="px-3 py-1 bg-[#000d0b] border border-red-500/30 hover:bg-red-950/20 text-red-400 font-extrabold rounded-lg text-[10px] transition-colors cursor-pointer uppercase"
                              >
                                {lang === 'bn' ? 'ফেরত যান' : 'Go Back'}
                              </button>
                            </div>
                          </div>

                          {/* Print container with CSS structure */}
                          <div className="overflow-x-auto bg-[#faf9f6] p-4.5 rounded-xl flex justify-center border border-emerald-500/10 font-sans">
                            {(() => {
                              const activeCert = resolvedCertificateOnScreen || selectedCertificate;
                              return (
                                <div ref={printRef} className="w-[520px] h-[370px] min-w-[520px] p-6 relative border-[8px] border-double border-[#0d5c3a] bg-[#fffdf9] text-center flex flex-col justify-between font-serif select-none select-text text-slate-900 shadow-md overflow-hidden">
                                  
                                  {/* Inner thin gold border */}
                                  <div className="absolute top-1 left-1 right-1 bottom-1 border border-[#b8860b] pointer-events-none rounded-sm"></div>
                                  
                                  {/* Elegant Gold Corner Ornaments */}
                                  <div className="absolute top-1.5 left-1.5 w-4.5 h-4.5 border-t-2 border-l-2 border-[#b8860b]/80 rounded-tl-sm pointer-events-none"></div>
                                  <div className="absolute top-1.5 right-1.5 w-4.5 h-4.5 border-t-2 border-r-2 border-[#b8860b]/80 rounded-tr-sm pointer-events-none"></div>
                                  <div className="absolute bottom-1.5 left-1.5 w-4.5 h-4.5 border-b-2 border-l-2 border-[#b8860b]/80 rounded-bl-sm pointer-events-none"></div>
                                  <div className="absolute bottom-1.5 right-1.5 w-4.5 h-4.5 border-b-2 border-r-2 border-[#b8860b]/80 rounded-br-sm pointer-events-none"></div>
                                  
                                  {/* Watermark image/logo placed at the bottom background */}
                                  {activeCert.watermarkUrl ? (
                                    <img 
                                      className="absolute bottom-4 left-1/2 -translate-x-1/2 select-none pointer-events-none opacity-[0.16] max-w-[130px] max-h-[85px] object-contain z-0 filter saturate-[1.2]" 
                                      src={activeCert.watermarkUrl} 
                                      crossOrigin="anonymous"
                                      alt="watermark"
                                    />
                                  ) : (
                                    <div className="text-[90px] font-sans text-emerald-800/4 absolute bottom-[14px] left-1/2 -translate-x-1/2 select-none pointer-events-none z-0">🕌</div>
                                  )}
                                  
                                  <div className="z-10">
                                    <span className="text-[8px] font-bold tracking-widest text-[#0d5c3a] uppercase block font-sans">
                                      {lang === 'bn' ? 'ইসলামি সংগীত চর্চা কেন্দ্র' : 'ISLAMIC MUSIC TRAINING CENTER'}
                                    </span>
                                    <span className="text-sm font-black text-[#0d5c3a] uppercase block mt-0.5 tracking-wider font-sans drop-shadow-sm">
                                      {lang === 'bn' ? 'স্বর্গধ্বনি একাডেমি' : 'SWARGADHUNI ACADEMY'}
                                    </span>
                                    
                                    {/* Traditional center heading separator */}
                                    <div className="mx-auto flex items-center justify-center gap-1.5 my-1.5">
                                      <div className="w-10 border-b border-[#b8860b]/40"></div>
                                      <span className="text-[#b8860b] text-[8px] scale-95 select-none font-sans">✦ 🕌 ✦</span>
                                      <div className="w-10 border-b border-[#b8860b]/40"></div>
                                    </div>
                                    
                                    {/* High contrast luxury title banner badge */}
                                    <div className="relative inline-block px-4 py-1.5 border border-[#b8860b]/30 bg-gradient-to-r from-[#b8860b]/3 via-[#b8860b]/8 to-[#b8860b]/3 rounded shadow-inner my-1">
                                      <span className="text-xs font-black text-[#8b6508] block uppercase tracking-widest font-sans leading-none font-sans">
                                        {lang === 'bn' ? activeCert.certificateName : (activeCert.certificateNameEn || translateToEnglish(activeCert.certificateName))}
                                      </span>
                                    </div>
                                    
                                    <span className="text-[9px] italic text-slate-500 block mt-1.5">
                                      {lang === 'bn' ? 'এই অনন্য গৌরবময় সনদপত্রটি সসম্মানে প্রদান করা হলো' : 'This certificate of merit is proudly presented to'}
                                    </span>
                                    
                                    <span className="text-base font-black text-[#0c4027] block tracking-wide my-1.5 font-sans drop-shadow-sm select-text selection:bg-amber-100">
                                      {lang === 'bn' ? (searchedStudent.nameBn || searchedStudent.name) : (searchedStudent.nameEn || translateToEnglish(searchedStudent.nameBn || searchedStudent.name))}
                                    </span>
                                    
                                    <span className="text-[8px] font-mono text-slate-500 block leading-none">Student ID: {searchedStudent.id}</span>
                                    
                                    <p className="text-[9px] text-slate-700 w-11/12 mx-auto leading-relaxed mt-2 font-sans font-medium">
                                      {lang === 'bn' 
                                        ? (activeCert.details || `সফলতার সাথে কোর্স সম্পাদন এবং হচ্ছে আদর্শ ধর্মীয় শিক্ষা ও নিয়মানুবর্তিতা অনুসরণের স্বীকৃতিস্বরূপ এই বিশেষ যোগ্যতাপত্র মঞ্জুর করা হলো।`) 
                                        : (activeCert.detailsEn || translateToEnglish(activeCert.details || 'In recognition of outstanding performance, religious conduct, diligent pursuit of knowledge, and moral rectitude demonstrated during the course curriculum.'))}
                                    </p>
                                  </div>
     
                                  {/* Perfectly aligned footer block with 2 balanced columns (Official Seal removed) */}
                                  <div className="flex justify-between items-end mt-1.5 px-6 font-sans z-10 w-full">
                                    {/* Column 1: Signature aligned left */}
                                    <div className="w-1/2 flex flex-col items-start justify-end">
                                      <div className="text-center w-28 flex flex-col items-center justify-end">
                                        {activeCert.signatureUrl ? (
                                          <img 
                                            src={activeCert.signatureUrl} 
                                            crossOrigin="anonymous"
                                            style={{ height: '38px', maxWidth: '110px', objectFit: 'contain', marginBottom: '-1px' }} 
                                            alt="Signature"
                                          />
                                        ) : (
                                          <div style={{ height: '38px' }}></div>
                                        )}
                                        {activeCert.signatureTitle ? (
                                          <div className="text-[7px] font-black text-slate-700 leading-tight mb-0.5 truncate max-w-[90px]">{lang === 'bn' ? activeCert.signatureTitle : (activeCert.signatureTitleEn || translateToEnglish(activeCert.signatureTitle))}</div>
                                        ) : null}
                                        <div className="border-t border-slate-300 pt-0.5 text-[7px] font-bold text-slate-500 uppercase w-full">
                                          {lang === 'bn' ? 'কর্তৃপক্ষ স্বাক্ষর' : 'Signature'}
                                        </div>
                                      </div>
                                    </div>
    
                                    {/* Column 2: Date aligned right */}
                                    <div className="w-1/2 flex flex-col items-end justify-end">
                                      <div className="text-center w-28 flex flex-col items-center justify-end">
                                        <span className="text-[8px] font-bold text-slate-800 block mb-0.5 font-mono">{activeCert.issueDate}</span>
                                        <div className="border-t border-slate-300 pt-0.5 text-[7px] font-bold text-slate-500 uppercase w-full">
                                          {lang === 'bn' ? 'ইস্যু তারিখ' : 'Date'}
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              );
                            })()}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })()}

              </div >

            </div >
          )}

        </div >

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-900/30 border-t border-emerald-500/15 text-right font-bold text-xs">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl transition-all cursor-pointer"
          >
            {lang === 'bn' ? 'বন্ধ করুন' : 'Close'}
          </button>
        </div>

        {/* Backup base64 image modal for mobile download / fallback option */}
        {downloadedImgUrl && (
          <div className="fixed inset-0 z-[110] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
            <div className="w-full max-w-lg bg-slate-900 border border-emerald-500/25 p-5 rounded-2xl shadow-2xl flex flex-col items-center text-center font-sans">
              <div className="w-12 h-12 rounded-full bg-emerald-500/15 text-emerald-400 flex items-center justify-center mb-3 animate-bounce">
                <CheckCircle size={24} />
              </div>
              <h4 className="text-sm font-bold text-slate-100">
                {lang === 'bn' ? 'সনদপত্র প্রস্তুত হয়েছে!' : 'Certificate Generated!'}
              </h4>
              <p className="text-xs text-slate-400 mt-2 max-w-sm">
                {lang === 'bn' 
                  ? 'স্মার্টফোনে সরাসরি ডাউনলোড চালু না হলে, নিচের ছবিতে ৩ সেকেন্ড চেপে ধরে রেখে "ছবি সেভ করুন" বা "Save Image" অপশন নির্বাচন করুন।' 
                  : 'If automatic download fails on your browser, press and hold the certificate image below for 3 seconds, then select "Save Image" or "Download Image".'}
              </p>

              {/* Display the image */}
              <div className="my-4 border border-emerald-500/15 rounded-lg overflow-hidden max-w-full bg-[#fffdf9] p-1.5 shadow-lg shadow-black/40">
                <img 
                  src={downloadedImgUrl} 
                  alt="Downloaded Certificate" 
                  className="max-h-[45vh] w-auto max-w-full object-contain pointer-events-auto rounded"
                />
              </div>

              <div className="flex gap-2.5 w-full mt-2">
                <button
                  type="button"
                  onClick={() => {
                    const link = document.createElement('a');
                    const filename = `${searchedStudent?.nameEn || 'student'}_certificate_${selectedCertificate?.id || 'doc'}.png`;
                    link.download = filename;
                    link.href = downloadedImgUrl;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                  }}
                  className="flex-1 py-2.5 bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-slate-950 font-extrabold rounded-xl text-xs sm:text-sm transition-all cursor-pointer shadow-md shadow-emerald-500/10"
                >
                  {lang === 'bn' ? 'আবার ডাউনলোড চেষ্টা করুন' : 'Retry Download'}
                </button>
                <button
                  type="button"
                  onClick={() => setDownloadedImgUrl(null)}
                  className="px-5 py-2.5 bg-slate-805 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 hover:text-white font-bold rounded-xl text-xs sm:text-sm transition-all cursor-pointer"
                >
                  {lang === 'bn' ? 'বন্ধ করুন' : 'Close'}
                </button>
              </div>
            </div>
          </div>
        )}

      </div >
    </div >
  );
}
