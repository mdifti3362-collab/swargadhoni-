import React, { useState, ReactNode } from 'react';
import { motion } from 'motion/react';
import { X, FileText, PlusCircle, Edit, Trash, Plus, Settings, Layers, Palette, Upload, Image as ImageIcon, Facebook, User, Award, Check, Calendar, Search, Printer, AlertCircle, Camera, QrCode, Download, Megaphone, Clock, GraduationCap, Users, BookOpen, LineChart, Info, Bell } from 'lucide-react';
import { TRANSLATIONS, PHYSICAL_THEMES } from '../data';
import { IslamicItem, SectionNames, InfoTexts, Student, PrayerTimesConfig, StatusBarConfig, StatusBarSlide, AppNotification } from '../types';

const AUTHOR_PRESETS = [
  'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1564507004663-b6dfb3c824d5?w=400&auto=format&fit=crop&q=80'
];

const DEV_PRESETS = [
  'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1618401471353-b98aedd07871?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80'
];

const UTSARGA_PRESETS = [
  'https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1564507004663-b6dfb3c824d5?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1584551246679-0daf3d275d0f?w=400&auto=format&fit=crop&q=80'
];

// Helper to downscale and compress images to extremely small base64 string
const compressImageToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 150;
        const MAX_HEIGHT = 150;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
        resolve(dataUrl);
      };
      img.onerror = (err) => reject(err);
    };
    reader.onerror = (err) => reject(err);
  });
};

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'bn' | 'en';
  items: IslamicItem[];
  sections: string[];
  sectionNames: SectionNames;
  info: InfoTexts;
  currentTheme: string;
  onUpdateInfo: (info: InfoTexts) => void;
  onAddItem: (item: IslamicItem) => void;
  onEditItem: (updatedItem: IslamicItem) => void;
  onDeleteItem: (id: string) => void;
  onAddSection: (id: string, bn: string, en: string) => void;
  onUpdateSectionNames?: (updatedNames: SectionNames) => void;
  onDeleteSection: (id: string) => void;
  onChangeTheme: (themeId: string) => void;
  students: Student[];
  onAddStudent: (newStudent: Student) => void;
  onDeleteStudent: (id: string) => void;
  onUpdateStudentAttendance: (studentId: string, dateStr: string, status: 'present' | 'absent') => void;
  onUpdateStudent: (updatedStudent: Student) => void;
  onSyncAllStudents?: () => Promise<void>;
  appDownload?: { downloadUrl?: string; badgeUrl?: string; };
  onUpdateAppDownload?: (config: { downloadUrl?: string; badgeUrl?: string; }) => void;
  notice?: { textBn: string; textEn: string; enabled: boolean; speed?: number };
  onUpdateNotice?: (config: { textBn: string; textEn: string; enabled: boolean; speed?: number }) => void;
  prayerTimesConfig?: PrayerTimesConfig;
  onUpdatePrayerTimesConfig?: (config: PrayerTimesConfig) => void;
  statusBarConfig?: StatusBarConfig;
  onUpdateStatusBarConfig?: (config: StatusBarConfig) => void;
  isAdmissionEnabled?: boolean;
  onUpdateAdmissionEnabled?: (enabled: boolean) => void;
  onSendBroadcastNotification?: (notification: AppNotification) => void;
  notificationsList?: AppNotification[];
  onDeleteNotification?: (id: string) => void;
}

type AdminTab = 'info' | 'add' | 'list' | 'section' | 'theme' | 'students' | 'appDownload' | 'notice' | 'prayerTimes' | 'statusBar';

export default function AdminPanel({
  isOpen,
  onClose,
  lang,
  items,
  sections,
  sectionNames,
  info,
  currentTheme,
  onUpdateInfo,
  onAddItem,
  onEditItem,
  onDeleteItem,
  onAddSection,
  onUpdateSectionNames,
  onDeleteSection,
  onChangeTheme,
  students,
  onAddStudent,
  onDeleteStudent,
  onUpdateStudentAttendance,
  onUpdateStudent,
  onSyncAllStudents,
  appDownload,
  onUpdateAppDownload,
  notice,
  onUpdateNotice,
  prayerTimesConfig,
  onUpdatePrayerTimesConfig,
  statusBarConfig,
  onUpdateStatusBarConfig,
  isAdmissionEnabled = true,
  onUpdateAdmissionEnabled,
  onSendBroadcastNotification,
  notificationsList = [],
  onDeleteNotification,
}: AdminPanelProps) {
  const t = TRANSLATIONS[lang];
  const [activeTab, setActiveTab] = useState<AdminTab>('info');

  const handleAddResultSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resultManagingStudent) return;
    if (!newExamName.trim() || !newExamMarks.trim() || !newExamGrade.trim()) {
      alert(lang === 'bn' ? 'অনুগ্রহ করে সব তথ্য পূরণ করুন!' : 'Please fill in all fields!');
      return;
    }

    const newResultItem = {
      id: 'RES' + Date.now(),
      examName: newExamName.trim(),
      marks: newExamMarks.trim(),
      grade: newExamGrade.trim(),
      date: newExamDate || new Date().toISOString().split('T')[0]
    };

    const updatedStudent: Student = {
      ...resultManagingStudent,
      results: [...(resultManagingStudent.results || []), newResultItem]
    };

    onUpdateStudent(updatedStudent);
    setResultManagingStudent(updatedStudent);
    setNewExamName('');
    setNewExamMarks('');
    setNewExamGrade('');
  };

  const handleDeleteResult = (resultId: string) => {
    if (!resultManagingStudent) return;
    const updatedStudent: Student = {
      ...resultManagingStudent,
      results: (resultManagingStudent.results || []).filter(r => r.id !== resultId)
    };
    onUpdateStudent(updatedStudent);
    setResultManagingStudent(updatedStudent);
  };

  const handleSendBroadcastSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitleBn.trim() || !broadcastBodyBn.trim()) {
      alert(lang === 'bn' ? 'অনুগ্রহ করে ন্যূনতম বাংলা শিরোনাম ও বিবরণ পূরণ করুন!' : 'Please fill out at least the Bangla Title and Body fields!');
      return;
    }
    
    setIsSendingBroadcast(true);
    
    const notification: AppNotification = {
      id: 'notif_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      titleBn: broadcastTitleBn.trim(),
      titleEn: (broadcastTitleEn.trim() || broadcastTitleBn.trim()),
      bodyBn: broadcastBodyBn.trim(),
      bodyEn: (broadcastBodyEn.trim() || broadcastBodyBn.trim()),
      createdAt: Date.now()
    };
    
    if (onSendBroadcastNotification) {
      onSendBroadcastNotification(notification);
    }
    
    // Reset fields
    setBroadcastTitleBn('');
    setBroadcastTitleEn('');
    setBroadcastBodyBn('');
    setBroadcastBodyEn('');
    setIsSendingBroadcast(false);
  };

  const handleAddCertSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!certManagingStudent) return;
    if (!newCertTitle.trim()) {
      alert(lang === 'bn' ? 'সনদপত্রের শিরোনাম আবশ্যক!' : 'Certificate title is required!');
      return;
    }

    const newCertItem = {
      id: 'CRT' + Date.now(),
      certificateName: newCertTitle.trim(),
      certificateNameEn: newCertTitleEn.trim() || undefined,
      issueDate: newCertDate || new Date().toISOString().split('T')[0],
      details: newCertDetails.trim(),
      detailsEn: newCertDetailsEn.trim() || undefined,
      status: 'Issued',
      watermarkUrl: newCertWatermarkUrl || undefined,
      signatureUrl: newCertSignatureUrl || undefined,
      signatureTitle: newCertSignatureTitle.trim() || undefined,
      signatureTitleEn: newCertSignatureTitleEn.trim() || undefined,
    };

    const updatedStudent: Student = {
      ...certManagingStudent,
      certificates: [...(certManagingStudent.certificates || []), newCertItem]
    };

    onUpdateStudent(updatedStudent);
    setCertManagingStudent(updatedStudent);
    setNewCertTitle('');
    setNewCertTitleEn('');
    setNewCertDetails('');
    setNewCertDetailsEn('');
    setNewCertWatermarkUrl('');
    setNewCertSignatureUrl('');
    setNewCertSignatureTitle('');
    setNewCertSignatureTitleEn('');
  };

  const handleDeleteCert = (certId: string) => {
    if (!certManagingStudent) return;
    const updatedStudent: Student = {
      ...certManagingStudent,
      certificates: (certManagingStudent.certificates || []).filter(c => c.id !== certId)
    };
    onUpdateStudent(updatedStudent);
    setCertManagingStudent(updatedStudent);
  };

  const printStudentSlip = (student: Student) => {
    const qrData = `Verified Student Admission\nID: ${student.id}\nName (BN): ${student.nameBn || student.name}\nName (EN): ${student.nameEn || student.name}\nFather: ${student.fatherName || 'N/A'}\nMother: ${student.motherName || 'N/A'}\nMobile: ${student.mobile}\nAddress: ${student.address}`;
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(qrData)}`;

    const win = window.open('', '_blank');
    if (!win) return;

    win.document.write(`
      <html>
        <head>
          <title>${lang === 'bn' ? 'ভর্তি রসিদ' : 'Admission Slip'} - ${student.id}</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap');
            body {
              font-family: 'Inter', sans-serif;
              padding: 20px;
              color: #111827;
              max-width: 450px;
              margin: 0 auto;
              border: 1px dashed #cbd5e1;
              background-color: #ffffff;
            }
            .header {
              text-align: center;
              border-bottom: 2px solid #e5e7eb;
              padding-bottom: 12px;
              margin-bottom: 16px;
            }
            .title {
              font-size: 18px;
              font-weight: 700;
              color: #059669;
              margin: 4px 0;
            }
            .subtitle {
              font-size: 11px;
              color: #4b5563;
              letter-spacing: 0.05em;
              text-transform: uppercase;
            }
            .photo-container {
              display: flex;
              justify-content: center;
              margin: 14px 0;
            }
            .photo-box {
              width: 100px;
              height: 100px;
              border-radius: 8px;
              border: 1px solid #e5e7eb;
              object-fit: cover;
              box-shadow: 0 1px 2px rgba(0,0,0,0.05);
            }
            .photo-placeholder {
              width: 100px;
              height: 100px;
              border-radius: 8px;
              border: 1px dashed #cbd5e1;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 11px;
              color: #9ca3af;
              background: #f9fafb;
            }
            .details-table {
              width: 100%;
              border-collapse: collapse;
              margin-bottom: 20px;
              font-size: 12px;
            }
            .details-table td {
              padding: 6px 4px;
              border-bottom: 1px solid #f3f4f6;
            }
            .details-table td.label {
              font-weight: 700;
              color: #374151;
              width: 40%;
            }
            .qr-container {
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: center;
              margin-top: 14px;
              padding-top: 14px;
              border-top: 1px dashed #e5e7eb;
              text-align: center;
            }
            .qr-img {
              width: 130px;
              height: 130px;
              border: 1px solid #e5e7eb;
              padding: 4px;
              border-radius: 6px;
              background: white;
            }
            .qr-caption {
              font-size: 10px;
              color: #6b7280;
              margin-top: 6px;
              font-weight: 500;
            }
            .footer {
              text-align: center;
              font-size: 10px;
              color: #9ca3af;
              margin-top: 20px;
              border-top: 1px solid #e5e7eb;
              padding-top: 10px;
            }
            @media print {
              body {
                border: none;
                padding: 10px;
              }
            }
          </style>
        </head>
        <body onload="window.print()">
          <div class="header">
            <div class="subtitle">${(info as any).headline || 'ISLAMIC EDUCATIONAL CENTER'}</div>
            <div class="title">${lang === 'bn' ? 'ভর্তি রশিদ (স্লিপ)' : 'Admission Verification Slip'}</div>
            <div style="font-size: 10px; color: #6b7280;">ID: ${student.id} | Date: ${new Date(student.createdAt || Date.now()).toLocaleDateString()}</div>
          </div>

          <div class="photo-container">
            ${student.photo 
              ? `<img class="photo-box" src="${student.photo}" alt="Student" />` 
              : `<div class="photo-placeholder">${lang === 'bn' ? 'ছবি নেই' : 'No Photo'}</div>`
            }
          </div>

          <table class="details-table">
            <tr>
              <td class="label">${lang === 'bn' ? 'নাম (বাংলা)' : 'Name (Bengali)'}</td>
              <td>: ${student.nameBn || student.name}</td>
            </tr>
            <tr>
              <td class="label">${lang === 'bn' ? 'নাম (ইংরেজি)' : 'Name (English)'}</td>
              <td style="text-transform: uppercase;">: ${student.nameEn || student.name}</td>
            </tr>
            <tr>
              <td class="label">${lang === 'bn' ? 'পিতার নাম' : 'Father\'s Name'}</td>
              <td>: ${student.fatherName || 'N/A'}</td>
            </tr>
            <tr>
              <td class="label">${lang === 'bn' ? 'মাতার নাম' : 'Mother\'s Name'}</td>
              <td>: ${student.motherName || 'N/A'}</td>
            </tr>
            <tr>
              <td class="label">${lang === 'bn' ? 'মোবাইল নম্বর' : 'Mobile Number'}</td>
              <td>: ${student.mobile}</td>
            </tr>
            <tr>
              <td class="label">${lang === 'bn' ? 'ঠিকানা' : 'Address'}</td>
              <td>: ${student.address}</td>
            </tr>
          </table>

          <div class="qr-container">
            <img class="qr-img" src="${qrUrl}" alt="Verification QR Code" />
            <div class="qr-caption">
              ${lang === 'bn' ? 'QR কোড স্ক্যান করে তথ্য যাচাই করুন' : 'Scan QR code to verify student details'}
            </div>
          </div>

          <div class="footer">
            <p>${lang === 'bn' ? 'আমাদের সাথে থাকার জন্য ধন্যবাদ' : 'Thank you for being with us'}</p>
          </div>
        </body>
      </html>
    `);
    win.document.close();
  };

  // Student Attendance States
  const [selectedDate, setSelectedDate] = useState(() => {
    const d = new Date();
    const offset = d.getTimezoneOffset();
    const localDate = new Date(d.getTime() - (offset * 60 * 1000));
    return localDate.toISOString().split('T')[0];
  });
  const [studentFilter, setStudentFilter] = useState('');
  const [isAddingStudent, setIsAddingStudent] = useState(false);
  const [adminStudentTab, setAdminStudentTab] = useState<'active' | 'old'>('active');
  const [newStdName, setNewStdName] = useState('');
  const [newStdNameBn, setNewStdNameBn] = useState('');
  const [newStdNameEn, setNewStdNameEn] = useState('');
  const [newStdFather, setNewStdFather] = useState('');
  const [newStdMother, setNewStdMother] = useState('');
  const [newStdPhoto, setNewStdPhoto] = useState('');
  const [isNewStdPhotoUploading, setIsNewStdPhotoUploading] = useState(false);
  const [newStdMobile, setNewStdMobile] = useState('');
  const [newStdAddress, setNewStdAddress] = useState('');
  const [newStdBatchTime, setNewStdBatchTime] = useState('');
  const [newStdClassDays, setNewStdClassDays] = useState('');
  const [newStdCourseDuration, setNewStdCourseDuration] = useState('');

  // Results management states
  const [resultManagingStudent, setResultManagingStudent] = useState<Student | null>(null);
  const [newExamName, setNewExamName] = useState('');
  const [newExamMarks, setNewExamMarks] = useState('');
  const [newExamGrade, setNewExamGrade] = useState('');
  const [newExamDate, setNewExamDate] = useState(() => new Date().toISOString().split('T')[0]);

  // Certificates management states
  const [certManagingStudent, setCertManagingStudent] = useState<Student | null>(null);
  const [newCertTitle, setNewCertTitle] = useState('');
  const [newCertTitleEn, setNewCertTitleEn] = useState('');
  const [newCertDate, setNewCertDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [newCertDetails, setNewCertDetails] = useState('');
  const [newCertDetailsEn, setNewCertDetailsEn] = useState('');
  const [newCertWatermarkUrl, setNewCertWatermarkUrl] = useState('');
  const [newCertSignatureUrl, setNewCertSignatureUrl] = useState('');
  const [newCertSignatureTitle, setNewCertSignatureTitle] = useState('');
  const [newCertSignatureTitleEn, setNewCertSignatureTitleEn] = useState('');
  const [isWatermarkUploading, setIsWatermarkUploading] = useState(false);
  const [isSignatureUploading, setIsSignatureUploading] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  // Live Broadcast Notification states
  const [broadcastTitleBn, setBroadcastTitleBn] = useState('');
  const [broadcastTitleEn, setBroadcastTitleEn] = useState('');
  const [broadcastBodyBn, setBroadcastBodyBn] = useState('');
  const [broadcastBodyEn, setBroadcastBodyEn] = useState('');
  const [isSendingBroadcast, setIsSendingBroadcast] = useState(false);

  // Student editing states
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [editStdNameBn, setEditStdNameBn] = useState('');
  const [editStdNameEn, setEditStdNameEn] = useState('');
  const [editStdFather, setEditStdFather] = useState('');
  const [editStdMother, setEditStdMother] = useState('');
  const [editStdPhoto, setEditStdPhoto] = useState('');
  const [isEditStdPhotoUploading, setIsEditStdPhotoUploading] = useState(false);
  const [editStdMobile, setEditStdMobile] = useState('');
  const [editStdAddress, setEditStdAddress] = useState('');
  const [editStdBatchTime, setEditStdBatchTime] = useState('');
  const [editStdClassDays, setEditStdClassDays] = useState('');
  const [editStdCourseDuration, setEditStdCourseDuration] = useState('');
  const [editStdStatus, setEditStdStatus] = useState<'active' | 'completed' | 'old'>('active');

  // Custom Confirmation Dialog States
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  // Custom Alert Dialog States
  const [alertConfig, setAlertConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
  }>({
    isOpen: false,
    title: '',
    message: '',
  });


  // Info Tab Local State
  const [utsargaBn, setUtsargaBn] = useState(info.utsarga.bn);
  const [utsargaEn, setUtsargaEn] = useState(info.utsarga.en);
  const [utsargaPhoto, setUtsargaPhoto] = useState(info.utsarga.photoUrl || '');
  const [lekhokBn, setLekhokBn] = useState(info.lekhok.bn);
  const [lekhokEn, setLekhokEn] = useState(info.lekhok.en);
  const [lekhokPhoto, setLekhokPhoto] = useState(info.lekhok.photoUrl || '');
  const [devBn, setDevBn] = useState(info.developer.bn);
  const [devEn, setDevEn] = useState(info.developer.en);
  const [devPhoto, setDevPhoto] = useState(info.developer.photoUrl || '');
  const [devFb, setDevFb] = useState(info.developer.facebookUrl || '');
  const [fbUrl, setFbUrl] = useState(info.facebookUrl);
  const [appTitleBn, setAppTitleBn] = useState(info.appTitleBn || 'স্বর্গধ্বনি');
  const [appTitleEn, setAppTitleEn] = useState(info.appTitleEn || 'Swargadhoni');
  const [appLogo, setAppLogo] = useState(info.appLogo || '🎵');
  const [contactPhone, setContactPhone] = useState(info.contactPhone || '');
  const [contactWhatsapp, setContactWhatsapp] = useState(info.contactWhatsapp || '');
  const [contactFacebook, setContactFacebook] = useState(info.contactFacebook || '');
  const [showContactBar, setShowContactBar] = useState(info.showContactBar !== false);

  const [dragActiveLekhok, setDragActiveLekhok] = useState(false);
  const [dragActiveDev, setDragActiveDev] = useState(false);
  const [dragActiveUtsarga, setDragActiveUtsarga] = useState(false);

  // Add Item Tab Local State
  const [itemCat, setItemCat] = useState(sections[0] || 'hamd');
  const [itemMedia, setItemMedia] = useState<'video' | 'lyrics' | 'both'>('both');
  const [itemTitle, setItemTitle] = useState('');
  const [itemVideoUrl, setItemVideoUrl] = useState('');
  const [itemLyrics, setItemLyrics] = useState('');

  // Section Control Local State
  const [newSecBn, setNewSecBn] = useState('');
  const [newSecEn, setNewSecEn] = useState('');
  const [newSecIcon, setNewSecIcon] = useState('');
  const [editingSecIcons, setEditingSecIcons] = useState<{[id: string]: string}>({});

  // App Download Configuration State
  const [downloadUrlInput, setDownloadUrlInput] = useState(appDownload?.downloadUrl || '');
  const [badgeUrlInput, setBadgeUrlInput] = useState(appDownload?.badgeUrl || '');
  const [isBadgeUploading, setIsBadgeUploading] = useState(false);
  const [dragActiveBadge, setDragActiveBadge] = useState(false);

  // Notice Configuration State
  const [noticeTextBn, setNoticeTextBn] = useState(notice?.textBn || '');
  const [noticeTextEn, setNoticeTextEn] = useState(notice?.textEn || '');
  const [noticeEnabled, setNoticeEnabled] = useState(notice?.enabled !== false);
  const [noticeSpeed, setNoticeSpeed] = useState(notice?.speed || 30);

  // Prayer Times Widget Configuration State
  const [ptShowWidget, setPtShowWidget] = useState(prayerTimesConfig?.showWidget !== false);
  const [ptMode, setPtMode] = useState<'auto' | 'manual'>(prayerTimesConfig?.mode || 'auto');
  const [ptFajr, setPtFajr] = useState(prayerTimesConfig?.manualTimings?.Fajr || '04:15');
  const [ptSunrise, setPtSunrise] = useState(prayerTimesConfig?.manualTimings?.Sunrise || '05:35');
  const [ptDhuhr, setPtDhuhr] = useState(prayerTimesConfig?.manualTimings?.Dhuhr || '12:15');
  const [ptAsr, setPtAsr] = useState(prayerTimesConfig?.manualTimings?.Asr || '16:45');
  const [ptMaghrib, setPtMaghrib] = useState(prayerTimesConfig?.manualTimings?.Maghrib || '18:45');
  const [ptIsha, setPtIsha] = useState(prayerTimesConfig?.manualTimings?.Isha || '20:00');

  // Status Bar admin state hooks
  const [sbEnabled, setSbEnabled] = useState(statusBarConfig?.enabled !== false);
  const [sbSlides, setSbSlides] = useState<StatusBarSlide[]>(statusBarConfig?.slides || []);
  const [newSlideUrl, setNewSlideUrl] = useState('');
  const [newSlideBn, setNewSlideBn] = useState('');
  const [newSlideEn, setNewSlideEn] = useState('');
  const [editingSlideId, setEditingSlideId] = useState<string | null>(null);
  const [isSlideUploading, setIsSlideUploading] = useState(false);
  const [dragActiveSlide, setDragActiveSlide] = useState(false);

  React.useEffect(() => {
    if (info) {
      setUtsargaBn(info.utsarga.bn || '');
      setUtsargaEn(info.utsarga.en || '');
      setUtsargaPhoto(info.utsarga.photoUrl || '');
      setLekhokBn(info.lekhok.bn || '');
      setLekhokEn(info.lekhok.en || '');
      setLekhokPhoto(info.lekhok.photoUrl || '');
      setDevBn(info.developer.bn || '');
      setDevEn(info.developer.en || '');
      setDevPhoto(info.developer.photoUrl || '');
      setDevFb(info.developer.facebookUrl || '');
      setFbUrl(info.facebookUrl || '');
      setAppTitleBn(info.appTitleBn || 'স্বর্গধ্বনি');
      setAppTitleEn(info.appTitleEn || 'Swargadhoni');
      setAppLogo(info.appLogo || '🎵');
      setContactPhone(info.contactPhone || '');
      setContactWhatsapp(info.contactWhatsapp || '');
      setContactFacebook(info.contactFacebook || '');
      setShowContactBar(info.showContactBar !== false);
    }
  }, [info]);

  React.useEffect(() => {
    if (appDownload) {
      setDownloadUrlInput(appDownload.downloadUrl || '');
      setBadgeUrlInput(appDownload.badgeUrl || '');
    }
  }, [appDownload]);

  React.useEffect(() => {
    if (notice) {
      setNoticeTextBn(notice.textBn || '');
      setNoticeTextEn(notice.textEn || '');
      setNoticeEnabled(notice.enabled !== false);
      setNoticeSpeed(notice.speed || 30);
    }
  }, [notice]);

  React.useEffect(() => {
    if (prayerTimesConfig) {
      setPtShowWidget(prayerTimesConfig.showWidget !== false);
      setPtMode(prayerTimesConfig.mode || 'auto');
      if (prayerTimesConfig.manualTimings) {
        setPtFajr(prayerTimesConfig.manualTimings.Fajr || '04:15');
        setPtSunrise(prayerTimesConfig.manualTimings.Sunrise || '05:35');
        setPtDhuhr(prayerTimesConfig.manualTimings.Dhuhr || '12:15');
        setPtAsr(prayerTimesConfig.manualTimings.Asr || '16:45');
        setPtMaghrib(prayerTimesConfig.manualTimings.Maghrib || '18:45');
        setPtIsha(prayerTimesConfig.manualTimings.Isha || '20:00');
      }
    }
  }, [prayerTimesConfig]);

  React.useEffect(() => {
    if (statusBarConfig) {
      setSbEnabled(statusBarConfig.enabled !== false);
      setSbSlides(statusBarConfig.slides || []);
    }
  }, [statusBarConfig]);

  const handleSavePrayerTimesConfig = (e: React.FormEvent) => {
    e.preventDefault();
    if (onUpdatePrayerTimesConfig) {
      onUpdatePrayerTimesConfig({
        showWidget: ptShowWidget,
        mode: ptMode,
        manualTimings: {
          Fajr: ptFajr.trim(),
          Sunrise: ptSunrise.trim(),
          Dhuhr: ptDhuhr.trim(),
          Asr: ptAsr.trim(),
          Maghrib: ptMaghrib.trim(),
          Isha: ptIsha.trim()
        }
      });
      alert(lang === 'bn' ? 'সালাতের সময়সূচী কনফিগারেশন সফলভাবে আপডেট করা হয়েছে!' : 'Prayer times configuration successfully updated!');
    }
  };

  const handleSaveStatusBarStatus = (enabledValue: boolean) => {
    setSbEnabled(enabledValue);
    if (onUpdateStatusBarConfig) {
      onUpdateStatusBarConfig({
        enabled: enabledValue,
        slides: sbSlides
      });
    }
  };

  const handleAddOrEditSlide = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSlideUrl.trim()) {
      alert(lang === 'bn' ? '⚠️ অনুগ্রহ করে একটি সঠিক ইমেজ ইউআরএল প্রদান করুন অথবা ফটো আপলোড করুন!' : '⚠️ Please provide a valid image URL or upload a photo!');
      return;
    }

    let updatedSlides = [];
    if (editingSlideId) {
      // Edit existing slide
      updatedSlides = sbSlides.map(slide => 
        slide.id === editingSlideId 
          ? { ...slide, imageUrl: newSlideUrl.trim(), captionBn: newSlideBn.trim(), captionEn: newSlideEn.trim() }
          : slide
      );
      alert(lang === 'bn' ? 'স্লাইড সফলভাবে আপডেট করা হয়েছে!' : 'Slide successfully updated!');
    } else {
      // Create new slide
      const newSlide: StatusBarSlide = {
        id: 'slide_' + Date.now(),
        imageUrl: newSlideUrl.trim(),
        captionBn: newSlideBn.trim(),
        captionEn: newSlideEn.trim()
      };
      updatedSlides = [...sbSlides, newSlide];
      alert(lang === 'bn' ? 'নতুন স্লাইড সফলভাবে যোগ করা হয়েছে!' : 'New slide successfully added!');
    }

    setSbSlides(updatedSlides);
    if (onUpdateStatusBarConfig) {
      onUpdateStatusBarConfig({
        enabled: sbEnabled,
        slides: updatedSlides
      });
    }

    // Reset Form Input
    setNewSlideUrl('');
    setNewSlideBn('');
    setNewSlideEn('');
    setEditingSlideId(null);
  };

  const handleDeleteSlide = (slideId: string) => {
    if (window.confirm(lang === 'bn' ? 'আপনি কি নিশ্চিতভাবে এই স্লাইডটি ডিলিট করতে চান?' : 'Are you sure you want to delete this slide?')) {
      const updatedSlides = sbSlides.filter(slide => slide.id !== slideId);
      setSbSlides(updatedSlides);
      if (onUpdateStatusBarConfig) {
        onUpdateStatusBarConfig({
          enabled: sbEnabled,
          slides: updatedSlides
        });
      }
      alert(lang === 'bn' ? 'স্লাইডটি ডিলিট করা হয়েছে!' : 'Slide deleted successfully!');
      
      if (editingSlideId === slideId) {
        setEditingSlideId(null);
        setNewSlideUrl('');
        setNewSlideBn('');
        setNewSlideEn('');
      }
    }
  };

  const handleEditSlideSelect = (slide: StatusBarSlide) => {
    setEditingSlideId(slide.id);
    setNewSlideUrl(slide.imageUrl);
    setNewSlideBn(slide.captionBn || '');
    setNewSlideEn(slide.captionEn || '');
  };

  const handleCancelSlideEdit = () => {
    setEditingSlideId(null);
    setNewSlideUrl('');
    setNewSlideBn('');
    setNewSlideEn('');
  };

  const handleSlideFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert(lang === 'bn' ? '⚠️ ফাইলের সাইজ অবশ্যই ২ মেগাবাইটের কম হতে হবে!' : '⚠️ File size must be less than 2MB!');
        return;
      }
      setIsSlideUploading(true);
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setNewSlideUrl(reader.result);
        }
        setIsSlideUploading(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSlideDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActiveSlide(false);
    
    const file = e.dataTransfer.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert(lang === 'bn' ? '⚠️ ফাইলের সাইজ অবশ্যই ২ মেগাবাইটের কম হতে হবে!' : '⚠️ File size must be less than 2MB!');
        return;
      }
      setIsSlideUploading(true);
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setNewSlideUrl(reader.result);
        }
        setIsSlideUploading(false);
      };
      reader.readAsDataURL(file);
    }
  };

  if (!isOpen) return null;

  // Drag and drop events
  const handleDrag = (e: React.DragEvent, stateSetter: React.Dispatch<React.SetStateAction<boolean>>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      stateSetter(true);
    } else if (e.type === "dragleave") {
      stateSetter(false);
    }
  };

  const handleDrop = async (e: React.DragEvent, target: 'lekhok' | 'dev' | 'utsarga', stateSetter: React.Dispatch<React.SetStateAction<boolean>>) => {
    e.preventDefault();
    e.stopPropagation();
    stateSetter(false);
    
    const file = e.dataTransfer.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert(lang === 'bn' ? '⚠️ ফাইলের সাইজ অবশ্যই ২ মেগাবাইটের কম হতে হবে!' : '⚠️ File size must be less than 2MB!');
        return;
      }
      try {
        const compressedBase64 = await compressImageToBase64(file);
        if (target === 'lekhok') setLekhokPhoto(compressedBase64);
        else if (target === 'utsarga') setUtsargaPhoto(compressedBase64);
        else setDevPhoto(compressedBase64);
      } catch (err) {
        console.error("Image compression failed, using fallback reader", err);
        const reader = new FileReader();
        reader.onloadend = () => {
          if (typeof reader.result === 'string') {
            if (target === 'lekhok') setLekhokPhoto(reader.result);
            else if (target === 'utsarga') setUtsargaPhoto(reader.result);
            else setDevPhoto(reader.result);
          }
        };
        reader.readAsDataURL(file);
      }
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>, target: 'lekhok' | 'dev' | 'utsarga') => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert(lang === 'bn' ? '⚠️ ফাইলের সাইজ অবশ্যই ২ মেগাবাইটের কম হতে হবে!' : '⚠️ File size must be less than 2MB!');
        return;
      }
      try {
        const compressedBase64 = await compressImageToBase64(file);
        if (target === 'lekhok') setLekhokPhoto(compressedBase64);
        else if (target === 'utsarga') setUtsargaPhoto(compressedBase64);
        else setDevPhoto(compressedBase64);
      } catch (err) {
        console.error("Image compression failed, using fallback reader", err);
        const reader = new FileReader();
        reader.onloadend = () => {
          if (typeof reader.result === 'string') {
            if (target === 'lekhok') setLekhokPhoto(reader.result);
            else if (target === 'utsarga') setUtsargaPhoto(reader.result);
            else setDevPhoto(reader.result);
          }
        };
        reader.readAsDataURL(file);
      }
    }
  };

  // Handlers
  const handleSaveInfo = () => {
    onUpdateInfo({
      utsarga: { bn: utsargaBn, en: utsargaEn, photoUrl: utsargaPhoto },
      lekhok: { bn: lekhokBn, en: lekhokEn, photoUrl: lekhokPhoto },
      developer: { bn: devBn, en: devEn, photoUrl: devPhoto, facebookUrl: devFb },
      facebookUrl: fbUrl,
      appTitleBn: appTitleBn.trim(),
      appTitleEn: appTitleEn.trim(),
      appLogo: appLogo.trim(),
      contactPhone: contactPhone.trim(),
      contactWhatsapp: contactWhatsapp.trim(),
      contactFacebook: contactFacebook.trim(),
      showContactBar: showContactBar,
    });
    alert(t.savedSuccess);
  };

  const handleExportStudents = () => {
    if (students.length === 0) {
      alert(lang === 'bn' ? 'কোনো শিক্ষার্থী নেই রপ্তানি করার জন্য!' : 'No student records to export!');
      return;
    }

    // Prepare CSV content with Unicode BOM to support Bengali character encoding in Excel
    let csvContent = "\ufeff";
    csvContent += "Student ID,Name (Bengali),Name (English),Father's Name,Mother's Name,Mobile,Address,Class Time/Batch,Days per Week,Course Duration,Status,Registration Date\n";

    students.forEach((s) => {
      const regDate = s.createdAt ? new Date(s.createdAt).toLocaleDateString() : '';
      const row = [
        s.id,
        `"${(s.nameBn || s.name || '').replace(/"/g, '""')}"`,
        `"${(s.nameEn || '').replace(/"/g, '""')}"`,
        `"${(s.fatherName || '').replace(/"/g, '""')}"`,
        `"${(s.motherName || '').replace(/"/g, '""')}"`,
        `"${(s.mobile || '').replace(/"/g, '""')}"`,
        `"${(s.address || '').replace(/"/g, '""')}"`,
        `"${(s.batchTime || '').replace(/"/g, '""')}"`,
        `"${(s.classDaysPerWeek || '').replace(/"/g, '""')}"`,
        `"${(s.courseDuration || '').replace(/"/g, '""')}"`,
        s.status || 'active',
        regDate
      ].join(",");
      csvContent += row + "\n";
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Swargadhoni_Students_Backup_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleAddItemSubmit = () => {
    if (!itemTitle.trim()) {
      alert(lang === 'bn' ? 'অনুগ্রহ করে শিরোনামটি লিখুন।' : 'Please enter a title.');
      return;
    }

    const videoUrlClean = itemVideoUrl.trim();
    const lyricsClean = itemLyrics.trim();

    if (!videoUrlClean && !lyricsClean) {
      alert(lang === 'bn' 
        ? 'অনুগ্রহ করে কমপক্ষে ভিডিও লিংক অথবা রিলিক্স (গানের কথা) যেকোনো একটি লিখুন।' 
        : 'Please provide either a Video Link or Lyrics text.');
      return;
    }

    // Determine correct mediaType based on what was entered
    let determinedMedia: 'video' | 'lyrics' | 'both' = 'both';
    if (videoUrlClean && lyricsClean) {
      determinedMedia = 'both';
    } else if (videoUrlClean) {
      determinedMedia = 'video';
    } else {
      determinedMedia = 'lyrics';
    }

    const newItem: IslamicItem = {
      id: Date.now().toString(),
      title: itemTitle.trim(),
      category: itemCat,
      mediaType: determinedMedia,
      videoUrl: videoUrlClean || undefined,
      lyrics: lyricsClean || undefined,
    };

    onAddItem(newItem);
    alert(t.addedSuccess);

    // Reset fields
    setItemTitle('');
    setItemVideoUrl('');
    setItemLyrics('');
  };

  const handleInlineEdit = (item: IslamicItem) => {
    const newTitle = prompt(lang === 'bn' ? 'নতুন শিরোনাম লিখুন:' : 'Enter new title:', item.title);
    if (newTitle === null) return; // Cancelled

    const askVideo = prompt(lang === 'bn' ? 'ইউটিউব ভিডিও লিংক লিখুন (না থাকলে ফাঁকা রাখুন):' : 'Enter YouTube Video URL (or leave blank):', item.videoUrl || '');
    if (askVideo === null) return; // Cancelled

    const askLyrics = prompt(lang === 'bn' ? 'রিলিক্স বা গীতি লিখুন (না থাকলে ফাঁকা রাখুন):' : 'Enter lyrics (or leave blank):', item.lyrics || '');
    if (askLyrics === null) return; // Cancelled

    const videoUrlClean = askVideo.trim();
    const lyricsClean = askLyrics.trim();

    if (!videoUrlClean && !lyricsClean) {
      alert(lang === 'bn' 
        ? 'অনুগ্রহ করে কমপক্ষে ভিডিও লিংক অথবা রিলিক্স যেকোনো একটি রাখুন।' 
        : 'Please keep at least either Video URL or Lyrics.');
      return;
    }

    let determinedMedia: 'video' | 'lyrics' | 'both' = 'both';
    if (videoUrlClean && lyricsClean) {
      determinedMedia = 'both';
    } else if (videoUrlClean) {
      determinedMedia = 'video';
    } else {
      determinedMedia = 'lyrics';
    }

    onEditItem({
      ...item,
      title: newTitle.trim() || item.title,
      mediaType: determinedMedia,
      videoUrl: videoUrlClean || undefined,
      lyrics: lyricsClean || undefined,
    });
  };

  const handleIconUpload = async (e: React.ChangeEvent<HTMLInputElement>, id?: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const base64Img = await compressImageToBase64(file);
      if (id) {
        setEditingSecIcons((prev) => ({
          ...prev,
          [id]: base64Img
        }));
      } else {
        setNewSecIcon(base64Img);
      }
    } catch (err) {
      console.error('Error uploading icon:', err);
      alert(lang === 'bn' ? 'ছবি প্রসেস করতে ত্রুটি হয়েছে!' : 'Error processing image!');
    }
  };

  const handleSaveSectionIcon = (id: string) => {
    if (!onUpdateSectionNames) return;
    const value = (editingSecIcons[id] !== undefined ? editingSecIcons[id] : (sectionNames[id]?.icon || '')).trim();
    
    const updatedNames = {
      ...sectionNames,
      [id]: {
        ...sectionNames[id],
        icon: value || undefined
      }
    };
    onUpdateSectionNames(updatedNames);
    
    alert(lang === 'bn' ? '✅ সফলভাবে ক্যাটাগরি আইকন সংরক্ষণ করা হয়েছে!' : '✅ Category icon successfully saved!');
  };

  const handleDeleteSectionIcon = (id: string) => {
    if (!onUpdateSectionNames) return;
    
    const updatedNames = {
      ...sectionNames,
      [id]: {
        ...sectionNames[id]
      }
    };
    delete updatedNames[id].icon;
    
    onUpdateSectionNames(updatedNames);
    
    setEditingSecIcons((prev) => ({
      ...prev,
      [id]: ''
    }));
    
    alert(lang === 'bn' ? '🗑️ আইকন সফলভাবে মুছে ফেলা হয়েছে!' : '🗑️ Icon successfully removed!');
  };

  const handleCreateSection = () => {
    if (!newSecBn.trim() || !newSecEn.trim()) {
      alert(t.fillFields);
      return;
    }

    const customId = `custom_${Date.now()}`;
    onAddSection(customId, newSecBn.trim(), newSecEn.trim());
    
    if (newSecIcon.trim() && onUpdateSectionNames) {
      setTimeout(() => {
        onUpdateSectionNames({
          ...sectionNames,
          [customId]: {
            bn: newSecBn.trim(),
            en: newSecEn.trim(),
            icon: newSecIcon.trim()
          }
        });
      }, 100);
    }
    
    alert(t.sectionAdded);

    setNewSecBn('');
    setNewSecEn('');
    setNewSecIcon('');
  };

  const handleDeleteSectionCheck = (id: string) => {
    if (['hamd', 'nat', 'gazal', 'mankabat'].includes(id)) {
      setAlertConfig({
        isOpen: true,
        title: lang === 'bn' ? '⚠️ দুঃখিত' : '⚠️ Sorry',
        message: lang === 'bn' ? 'আপনি মূল সেকশন মুছতে পারবেন না!' : 'You cannot delete core sections!',
      });
      return;
    }

    setConfirmConfig({
      isOpen: true,
      title: lang === 'bn' ? '⚠️ সেকশন মুছুন' : '⚠️ Delete Section',
      message: t.deleteSectionConfirm || 'Are you sure you want to delete this section?',
      onConfirm: () => {
        onDeleteSection(id);
      },
    });
  };

  const getEpsonResultSheet = () => {
    let output = '';
    output += '============================================\n';
    output += '        SWARGADHONI ACADEMY REPORTS         \n';
    output += '         STUDENTS ATTENDANCE SHEET          \n';
    output += `DATE GEN : ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}\n`;
    output += '============================================\n\n';
    output += 'ID      STUDENT NAME          PRES  ABS  RATE\n';
    output += '--------------------------------------------\n';

    if (students.length === 0) {
      output += '       --- NO ADMITTED STUDENTS ---     \n';
    } else {
      students.forEach((std) => {
        const idCol = (std.id || '').substring(0, 7).padEnd(7);
        const nameCol = (std.name || '').substring(0, 18).toUpperCase().padEnd(18);
        
        let presentCount = 0;
        let absentCount = 0;
        if (std.attendance) {
          Object.values(std.attendance).forEach((val) => {
            if (val === 'present') presentCount++;
            else if (val === 'absent') absentCount++;
          });
        }
        const total = presentCount + absentCount;
        const rate = total > 0 ? Math.round((presentCount / total) * 100) : 100;

        const presStr = presentCount.toString().padStart(4);
        const absStr = absentCount.toString().padStart(4);
        const rateStr = `${rate}%`.padStart(5);

        output += `${idCol} ${nameCol} ${presStr} ${absStr} ${rateStr}\n`;
      });
    }

    output += '--------------------------------------------\n';
    output += `TOTAL ENROLLED STUDENTS : ${students.length}\n`;
    const overallPres = students.reduce((acc, current) => {
      let pc = 0;
      if (current.attendance) {
        Object.values(current.attendance).forEach(v => { if (v === 'present') pc++; });
      }
      return acc + pc;
    }, 0);
    const overallAbs = students.reduce((acc, current) => {
      let ac = 0;
      if (current.attendance) {
        Object.values(current.attendance).forEach(v => { if (v === 'absent') ac++; });
      }
      return acc + ac;
    }, 0);
    const overallTot = overallPres + overallAbs;
    const overallRate = overallTot > 0 ? Math.round((overallPres / overallTot) * 100) : 100;
    
    output += `OVERALL ATTENDANCE RATE : ${overallRate}%\n`;
    output += '============================================\n';
    output += '     * NO PHYSICAL SIGNATURE REQUIRED *     \n';
    output += '           POWERED BY AHSAN DIGITAL         \n';
    output += '============================================\n';
    return output;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="relative w-full max-w-6xl bg-[#00100d]/85 backdrop-blur-2xl border border-emerald-500/20 rounded-[2rem] shadow-[0_0_50px_rgba(16,185,129,0.1)] flex flex-col h-[90vh] md:h-[85vh] overflow-hidden my-4 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header containing title and Close button */}
        <div className="flex justify-between items-center px-6 py-4.5 border-b border-emerald-500/10 bg-[#01261f]/40 backdrop-blur-md">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-xl bg-gradient-to-br from-emerald-500/20 to-teal-500/10 border border-emerald-500/20">
              <Settings size={18} className="text-emerald-400 animate-spin-slow" />
            </div>
            <div>
              <span className="text-base sm:text-lg font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-300 font-sans tracking-tight animate-pulse-slow">
                {t.adminControl}
              </span>
              <p className="text-[10px] text-emerald-400/60 font-medium tracking-wider uppercase font-mono mt-0.5">
                {lang === 'bn' ? 'নিয়ন্ত্রণ কক্ষ ও ডেটাবেজ হাব' : 'Control Center & Live Database Hub'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={async () => {
                if (isSyncing) return;
                setIsSyncing(true);
                try {
                  if (onSyncAllStudents) {
                    await onSyncAllStudents();
                    setAlertConfig({
                      isOpen: true,
                      title: lang === 'bn' ? '✅ ডাটাবেজ চূড়ান্ত সেভ সফল' : '✅ Database Save Successful',
                      message: lang === 'bn' 
                        ? 'সকল শিক্ষার্থীর তথ্য ফায়ারবেস ক্লাউড ডাটাবেজ এবং অফলাইন ব্যাকআপে সফলভাবে সুরক্ষিত করা হয়েছে!' 
                        : 'Successfully synchronized and saved all student records into Firebase Realtime Database!',
                    });
                  }
                } catch (err) {
                  setAlertConfig({
                    isOpen: true,
                    title: lang === 'bn' ? '❌ সংরক্ষণ ব্যর্থ' : '❌ Save Failed',
                    message: lang === 'bn' 
                      ? 'ক্লাউড ডাটাবেজে তথ্য চূড়ান্ত সংরক্ষণ করা সম্ভব হয়নি।' 
                      : 'Unable to sync records to Firebase Cloud. Please check your network connection.',
                  });
                } finally {
                  setIsSyncing(false);
                }
              }}
              disabled={isSyncing}
              className={`flex items-center gap-1.5 px-3 py-1.5 sm:px-4 sm:py-2 text-xs font-bold rounded-xl border transition-all active:scale-95 shadow-md ${
                isSyncing
                  ? 'bg-emerald-950/40 text-emerald-500 border-emerald-950 cursor-not-allowed'
                  : 'bg-emerald-500 hover:bg-emerald-600 text-[#00100d] border-emerald-400/30 font-sans cursor-pointer'
              }`}
              title={lang === 'bn' ? 'ফায়ারবেস ডাটাবেজে চূড়ান্ত সেভ করুন' : 'Final Save to Firebase Database'}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${isSyncing ? 'bg-amber-400 animate-ping' : 'bg-emerald-950'}`} />
              <span>
                {isSyncing 
                  ? (lang === 'bn' ? 'সেভ হচ্ছে...' : 'Saving...') 
                  : (lang === 'bn' ? '💾 চূড়ান্ত সেভ' : '💾 Final Save')
                }
              </span>
            </button>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full flex items-center justify-center bg-slate-900/60 border border-emerald-500/10 text-slate-400 hover:text-rose-400 focus:outline-none hover:border-rose-500/20 transition-all duration-300 shadow-md cursor-pointer hover:rotate-90"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Outer content area with responsive sidebar on desktop, horizontal bar on mobile */}
        <div className="flex flex-col md:flex-row flex-1 overflow-hidden">
          
          {/* Navigation Tab Panel */}
          <div className="w-full md:w-64 bg-[#001411]/50 md:border-r border-b md:border-b-0 border-emerald-500/10 p-3 flex flex-row md:flex-col gap-1.5 overflow-x-auto md:overflow-y-auto scrollbar-none shrink-0">
            {(['info', 'add', 'list', 'section', 'theme', 'students', 'appDownload', 'notice', 'prayerTimes', 'statusBar'] as AdminTab[]).map((tab) => {
              let label = '';
              let icon: ReactNode = null;
              if (tab === 'info') {
                label = t.tabInfo;
                icon = <FileText size={14} />;
              } else if (tab === 'add') {
                label = t.tabAdd;
                icon = <PlusCircle size={14} />;
              } else if (tab === 'list') {
                label = t.tabList;
                icon = <Layers size={14} />;
              } else if (tab === 'section') {
                label = t.tabSection;
                icon = <Settings size={14} />;
              } else if (tab === 'theme') {
                label = t.tabTheme || 'Theme';
                icon = <Palette size={14} />;
              } else if (tab === 'appDownload') {
                label = lang === 'bn' ? '📱 অ্যাপ ডাউনলোড' : '📱 App Download';
                icon = <Download size={14} />;
              } else if (tab === 'notice') {
                label = lang === 'bn' ? '📢 স্ক্রল নোটিশ' : '📢 Scroll Notice';
                icon = <Megaphone size={14} />;
              } else if (tab === 'prayerTimes') {
                label = lang === 'bn' ? '🕌 সালাতের সময়সূচী' : '🕌 Prayer Times';
                icon = <Clock size={14} />;
              } else if (tab === 'statusBar') {
                label = lang === 'bn' ? '🖼️ স্লাইড স্ট্যাটাস বার' : '🖼️ Status Bar';
                icon = <ImageIcon size={14} />;
              } else {
                label = lang === 'bn' ? '🎓 শিক্ষার্থী ও হাজিরা' : '🎓 Students & Stats';
                icon = <Award size={14} />;
              }

              const isActive = activeTab === tab;
              return (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`flex items-center gap-3 px-4 py-3 md:py-2.5 rounded-xl text-xs font-bold whitespace-nowrap md:whitespace-normal text-left transition-all duration-300 relative group cursor-pointer ${
                    isActive
                      ? 'bg-gradient-to-r from-emerald-500/15 via-teal-500/5 to-transparent text-emerald-300 border border-emerald-500/20 shadow-[0_4px_20px_rgba(16,185,129,0.06)] font-bold'
                      : 'border border-transparent text-slate-400 hover:text-slate-200 hover:bg-emerald-500/5 hover:border-emerald-500/5 font-medium'
                  }`}
                >
                  <div className={`p-1.5 rounded-lg transition-colors ${
                    isActive ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-900/40 text-slate-400 group-hover:text-emerald-400'
                  }`}>
                    {icon}
                  </div>
                  <span className="font-sans tracking-wide uppercase text-[10px] md:text-[11px]">
                    {label}
                  </span>
                  
                  {isActive && (
                    <div className="absolute right-2 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-emerald-400 hidden md:block animate-pulse" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Dynamic Panel Scroll Body */}
          <div className="flex-1 overflow-y-auto p-5 sm:p-6 bg-slate-950/10 backdrop-blur-md scrollbar-thin">
          
          {/* TAB 1: INFO CONTROL */}
          {activeTab === 'info' && (
            <div className="flex flex-col gap-5">
              
              {/* BRANDING TITLE & LOGO CONFIGURATION CARD */}
              <div className="bg-[#011c18]/45 border border-emerald-500/20 rounded-2xl p-5 sm:p-6 mb-2">
                <div className="flex items-center gap-2 mb-4 pb-3 border-b border-emerald-500/10">
                  <div className="p-1 px-1.5 bg-emerald-500/10 text-emerald-400 rounded-lg">
                    <Settings size={14} />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-amber-400 font-sans tracking-wide">
                      {lang === 'bn' ? '👑 মোবাইল/ওয়েব অ্যাপ টাইটেল এবং ব্র্যান্ড লোগো' : '👑 App Title & Brand Logo Configuration'}
                    </h4>
                    <p className="text-[10px] text-slate-500 font-medium">
                      {lang === 'bn' ? 'এখানে আপনার ওয়েবসাইটের মূল টাইটেল ও লোগো পরিবর্তন করুন' : 'Dynamically change your web application branding header text and logo'}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Title Bangla */}
                  <div>
                    <label className="block text-[11px] font-black uppercase tracking-widest text-emerald-400/80 mb-1.5 font-mono">
                      {lang === 'bn' ? 'অ্যাপের নাম (বাংলা)' : 'App Name (Bangla)'}
                    </label>
                    <input
                      type="text"
                      value={appTitleBn}
                      onChange={(e) => setAppTitleBn(e.target.value)}
                      className="w-full bg-[#000d0b]/90 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-2.5 text-xs text-slate-100 outline-none transition-all"
                      placeholder="যেমন: স্বর্গধ্বনি"
                    />
                  </div>

                  {/* Title English */}
                  <div>
                    <label className="block text-[11px] font-black uppercase tracking-widest text-emerald-400/80 mb-1.5 font-mono">
                      {lang === 'bn' ? 'অ্যাপের নাম (ইংরেজি)' : 'App Name (English)'}
                    </label>
                    <input
                      type="text"
                      value={appTitleEn}
                      onChange={(e) => setAppTitleEn(e.target.value)}
                      className="w-full bg-[#000d0b]/90 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-2.5 text-xs text-[#cacaca] outline-none transition-all placeholder:text-slate-600"
                      placeholder="e.g. Swargadhoni"
                    />
                  </div>
                </div>

                {/* Brand Logo Settings UI */}
                <div className="mt-5 border-t border-emerald-500/5 pt-4.5">
                  <label className="block text-[11px] font-black uppercase tracking-widest text-emerald-400/80 mb-2 font-mono">
                    {lang === 'bn' ? '🎨 লোগো বা আইকন নির্ধারণ (ইমোজি বা ছবি)' : '🎨 Brand Logo / Icon (Emoji or Image)'}
                  </label>

                  <div className="flex flex-col sm:flex-row gap-4 items-center">
                    {/* Brand logo current preview indicator */}
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500/20 to-teal-500/20 border border-emerald-500/30 flex items-center justify-center shadow-md select-none shrink-0 overflow-hidden relative group">
                      {appLogo.trim().startsWith('http://') ||
                      appLogo.trim().startsWith('https://') ||
                      appLogo.trim().startsWith('/') ||
                      appLogo.trim().startsWith('data:image') ? (
                        <img
                          src={appLogo.trim()}
                          alt="App logo preview"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span className="text-3xl filter drop-shadow-md">{appLogo || '🎵'}</span>
                      )}
                    </div>

                    <div className="flex-1 w-full flex flex-col gap-2">
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder={lang === 'bn' ? 'ইমোজি (যেমন: 🎵, 🕌) অথবা ছবির লিঙ্ক (https://...)' : 'Emoji (e.g. 🎵, 🕌) or image URL'}
                          value={appLogo}
                          onChange={(e) => setAppLogo(e.target.value)}
                          className="flex-1 bg-slate-950/80 border border-emerald-500/15 focus:border-emerald-500/30 rounded-xl px-4 py-2.5 text-xs text-slate-100 outline-none transition-all"
                        />

                        {/* Upload local image */}
                        <label className="flex items-center justify-center gap-1.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-850 hover:text-emerald-400 border border-emerald-500/10 text-slate-300 text-xs font-bold transition-all cursor-pointer active:scale-95 shadow-md">
                          <Upload size={13} />
                          <span>{lang === 'bn' ? 'আপলোড' : 'Upload'}</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                try {
                                  const base64 = await compressImageToBase64(file);
                                  setAppLogo(base64);
                                } catch (err) {
                                  console.error(err);
                                  alert(lang === 'bn' ? 'লোগো আপলোডে সমস্যা!' : 'Error processing image logo!');
                                }
                              }
                            }}
                            className="hidden"
                          />
                        </label>
                      </div>

                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[10px] text-slate-500 font-medium font-sans">
                          {lang === 'bn' ? '💡 টিপস: আপনি আপনার ডিভাইসের গ্যালারি থেকে যেকোনো ছবি আপলোড করে লোগো বানাতে পারেন।' : '💡 Advice: Upload any personal branding picture using the Upload option.'}
                        </span>

                        <button
                          type="button"
                          onClick={() => setAppLogo('🎵')}
                          className="text-[10px] font-bold text-rose-400 hover:text-rose-300 underline cursor-pointer font-sans"
                        >
                          {lang === 'bn' ? 'রিসেট করুন' : 'Reset Default'}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Dedications text field */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                  {t.utsargaLabel} (Bangla)
                </label>
                <textarea
                  value={utsargaBn}
                  onChange={(e) => setUtsargaBn(e.target.value)}
                  rows={3}
                  className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-3 text-sm text-slate-100 outline-none placeholder-teal-600/50 resize-none transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                  {t.utsargaLabel} (English)
                </label>
                <textarea
                  value={utsargaEn}
                  onChange={(e) => setUtsargaEn(e.target.value)}
                  rows={3}
                  className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-3 text-sm text-slate-100 outline-none placeholder-teal-600/50 resize-none transition-all"
                />
              </div>

              {/* Dedication Photo Controls */}
              <div className="bg-[#000d0b]/40 border border-emerald-500/15 rounded-2xl p-4 sm:p-5 flex flex-col gap-4">
                <span className="block text-xs font-bold uppercase tracking-wider text-amber-400 font-mono">
                  {lang === 'bn' ? '🙏 উৎসর্গের ছবি (লিংক অথবা আপলোড করুন)' : '🙏 Dedication Photo (URL or Upload)'}
                </span>

                <div className="flex flex-col sm:flex-row gap-4 items-center">
                  {/* Preview circular/rounded element */}
                  <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-2xl border border-amber-500/30 overflow-hidden bg-[#011411] shrink-0 flex items-center justify-center">
                    {utsargaPhoto ? (
                      <img src={utsargaPhoto} alt="Dedication Preview" className="w-full h-full object-cover" />
                    ) : (
                      <Camera className="text-slate-500 w-8 h-8" />
                    )}
                    {utsargaPhoto && (
                      <button
                        onClick={() => setUtsargaPhoto('')}
                        type="button"
                        className="absolute inset-0 bg-black/60 opacity-0 hover:opacity-100 flex items-center justify-center text-red-400 text-xs transition-opacity duration-150 cursor-pointer"
                        title="Clear Photo"
                      >
                        <Trash size={14} />
                      </button>
                    )}
                  </div>

                  {/* Drag and drop zone */}
                  <div
                    onDragEnter={(e) => handleDrag(e, setDragActiveUtsarga)}
                    onDragOver={(e) => handleDrag(e, setDragActiveUtsarga)}
                    onDragLeave={(e) => handleDrag(e, setDragActiveUtsarga)}
                    onDrop={(e) => handleDrop(e, 'utsarga', setDragActiveUtsarga)}
                    className={`flex-1 w-full border-2 border-dashed rounded-xl p-4 flex flex-col items-center justify-center gap-1.5 transition-all text-center cursor-pointer ${
                      dragActiveUtsarga
                        ? 'border-amber-400 bg-amber-500/10 text-amber-300'
                        : 'border-emerald-500/10 bg-[#000d0b]/80 hover:border-emerald-500/35 text-slate-400 hover:text-slate-300'
                    }`}
                    onClick={() => document.getElementById('utsarga-file-input')?.click()}
                  >
                    <Upload size={18} className="text-emerald-500 animate-bounce duration-1000" />
                    <span className="text-xs font-medium">
                      {t.uploadOrClick}
                    </span>
                    <span className="text-[10px] text-slate-500 uppercase tracking-widest font-mono">
                      PNG / JPG (MAX 2MB)
                    </span>
                    <input
                      id="utsarga-file-input"
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileChange(e, 'utsarga')}
                      className="hidden"
                    />
                  </div>
                </div>

                {/* Photo URL Direct paste option */}
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={utsargaPhoto}
                    onChange={(e) => setUtsargaPhoto(e.target.value)}
                    placeholder={lang === 'bn' ? 'অথবা কাস্টম ছবির লিংক দিন...' : 'or paste custom picture URL...'}
                    className="flex-1 w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-2.5 text-xs text-slate-100 outline-none placeholder-teal-600/50 transition-all"
                  />
                </div>

                {/* Utsarga Preset library gallery */}
                <div className="mt-1">
                  <span className="block text-[11px] font-bold text-slate-400 font-mono mb-2">
                    {t.gallerySelect}
                  </span>
                  <div className="flex items-center gap-3 overflow-x-auto pb-1 scrollbar-none">
                    {UTSARGA_PRESETS.map((preset, index) => (
                      <button
                        key={index}
                        type="button"
                        onClick={() => setUtsargaPhoto(preset)}
                        className={`w-12 h-12 rounded-lg overflow-hidden border-2 shrink-0 transition-transform active:scale-90 cursor-pointer ${
                          utsargaPhoto === preset
                            ? 'border-amber-400 scale-105 shadow-md shadow-amber-500/25'
                            : 'border-emerald-500/10 hover:border-emerald-500/30'
                        }`}
                      >
                        <img src={preset} alt={`Preset ${index + 1}`} className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Author text edit */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                  {t.lekhokLabel} (Bangla)
                </label>
                <textarea
                  value={lekhokBn}
                  onChange={(e) => setLekhokBn(e.target.value)}
                  rows={3}
                  className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-3 text-sm text-slate-100 outline-none placeholder-teal-600/50 resize-none transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                  {t.lekhokLabel} (English)
                </label>
                <textarea
                  value={lekhokEn}
                  onChange={(e) => setLekhokEn(e.target.value)}
                  rows={3}
                  className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-3 text-sm text-slate-100 outline-none placeholder-teal-600/50 resize-none transition-all"
                />
              </div>

              {/* Author Photo Controls */}
              <div className="bg-[#000d0b]/40 border border-emerald-500/15 rounded-2xl p-4 sm:p-5 flex flex-col gap-4">
                <span className="block text-xs font-bold uppercase tracking-wider text-amber-400 font-mono">
                  {t.authorPhotoLabel}
                </span>

                <div className="flex flex-col sm:flex-row gap-4 items-center">
                  {/* Preview circular element */}
                  <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-full border border-amber-500/30 overflow-hidden bg-[#011411] shrink-0 flex items-center justify-center">
                    {lekhokPhoto ? (
                      <img src={lekhokPhoto} alt="Author Preview" className="w-full h-full object-cover" />
                    ) : (
                      <User className="text-slate-500 w-8 h-8" />
                    )}
                    {lekhokPhoto && (
                      <button
                        onClick={() => setLekhokPhoto('')}
                        className="absolute inset-0 bg-black/60 opacity-0 hover:opacity-100 flex items-center justify-center text-red-400 text-xs transition-opacity duration-150 cursor-pointer"
                        title="Clear Photo"
                      >
                        <Trash size={14} />
                      </button>
                    )}
                  </div>

                  {/* Drag and drop zone */}
                  <div
                    onDragEnter={(e) => handleDrag(e, setDragActiveLekhok)}
                    onDragOver={(e) => handleDrag(e, setDragActiveLekhok)}
                    onDragLeave={(e) => handleDrag(e, setDragActiveLekhok)}
                    onDrop={(e) => handleDrop(e, 'lekhok', setDragActiveLekhok)}
                    className={`flex-1 w-full border-2 border-dashed rounded-xl p-4 flex flex-col items-center justify-center gap-1.5 transition-all text-center cursor-pointer ${
                      dragActiveLekhok
                        ? 'border-amber-400 bg-amber-500/10 text-amber-300'
                        : 'border-emerald-500/10 bg-[#000d0b]/80 hover:border-emerald-500/35 text-slate-400 hover:text-slate-300'
                    }`}
                    onClick={() => document.getElementById('lekhok-file-input')?.click()}
                  >
                    <Upload size={18} className="text-emerald-500 animate-bounce duration-1000" />
                    <span className="text-xs font-medium">
                      {t.uploadOrClick}
                    </span>
                    <span className="text-[10px] text-slate-500 uppercase tracking-widest font-mono">
                      PNG / JPG (MAX 2MB)
                    </span>
                    <input
                      id="lekhok-file-input"
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileChange(e, 'lekhok')}
                      className="hidden"
                    />
                  </div>
                </div>

                {/* Photo URL Direct paste option */}
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={lekhokPhoto}
                    onChange={(e) => setLekhokPhoto(e.target.value)}
                    placeholder="or paste custom picture URL..."
                    className="flex-1 w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-2.5 text-xs text-slate-100 outline-none placeholder-teal-600/50 transition-all"
                  />
                </div>

                {/* Author Preset library gallery */}
                <div className="mt-1">
                  <span className="block text-[11px] font-bold text-slate-400 font-mono mb-2">
                    {t.gallerySelect}
                  </span>
                  <div className="flex items-center gap-3 overflow-x-auto pb-1 scrollbar-none">
                    {AUTHOR_PRESETS.map((preset, index) => (
                      <button
                        key={index}
                        onClick={() => setLekhokPhoto(preset)}
                        className={`w-12 h-12 rounded-lg overflow-hidden border-2 shrink-0 transition-transform active:scale-90 cursor-pointer ${
                          lekhokPhoto === preset
                            ? 'border-amber-400 scale-105 shadow-md shadow-amber-500/25'
                            : 'border-emerald-500/10 hover:border-emerald-500/30'
                        }`}
                      >
                        <img src={preset} alt={`Preset ${index + 1}`} className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Developer info */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                  {t.developerLabel} (Bangla)
                </label>
                <textarea
                  value={devBn}
                  onChange={(e) => setDevBn(e.target.value)}
                  rows={2}
                  className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-3 text-sm text-slate-100 outline-none placeholder-teal-600/50 resize-none transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                  {t.developerLabel} (English)
                </label>
                <textarea
                  value={devEn}
                  onChange={(e) => setDevEn(e.target.value)}
                  rows={2}
                  className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-3 text-sm text-slate-100 outline-none placeholder-teal-600/50 resize-none transition-all"
                />
              </div>

              {/* Developer Photo Controls */}
              <div className="bg-[#000d0b]/40 border border-emerald-500/15 rounded-2xl p-4 sm:p-5 flex flex-col gap-4">
                <span className="block text-xs font-bold uppercase tracking-wider text-amber-400 font-mono">
                  {t.developerPhotoLabel}
                </span>

                <div className="flex flex-col sm:flex-row gap-4 items-center">
                  {/* Preview circular element */}
                  <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-full border border-amber-500/30 overflow-hidden bg-[#011411] shrink-0 flex items-center justify-center">
                    {devPhoto ? (
                      <img src={devPhoto} alt="Developer Preview" className="w-full h-full object-cover" />
                    ) : (
                      <User className="text-slate-500 w-8 h-8" />
                    )}
                    {devPhoto && (
                      <button
                        onClick={() => setDevPhoto('')}
                        className="absolute inset-0 bg-black/60 opacity-0 hover:opacity-100 flex items-center justify-center text-red-400 text-xs transition-opacity duration-150 cursor-pointer"
                        title="Clear Photo"
                      >
                        <Trash size={14} />
                      </button>
                    )}
                  </div>

                  {/* Drag and drop zone */}
                  <div
                    onDragEnter={(e) => handleDrag(e, setDragActiveDev)}
                    onDragOver={(e) => handleDrag(e, setDragActiveDev)}
                    onDragLeave={(e) => handleDrag(e, setDragActiveDev)}
                    onDrop={(e) => handleDrop(e, 'dev', setDragActiveDev)}
                    className={`flex-1 w-full border-2 border-dashed rounded-xl p-4 flex flex-col items-center justify-center gap-1.5 transition-all text-center cursor-pointer ${
                      dragActiveDev
                        ? 'border-amber-400 bg-amber-500/10 text-amber-300'
                        : 'border-emerald-500/10 bg-[#000d0b]/80 hover:border-emerald-500/35 text-slate-400 hover:text-slate-300'
                    }`}
                    onClick={() => document.getElementById('dev-file-input')?.click()}
                  >
                    <Upload size={18} className="text-emerald-500 animate-bounce duration-1000" />
                    <span className="text-xs font-medium">
                      {t.uploadOrClick}
                    </span>
                    <span className="text-[10px] text-slate-500 uppercase tracking-widest font-mono">
                      PNG / JPG (MAX 2MB)
                    </span>
                    <input
                      id="dev-file-input"
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileChange(e, 'dev')}
                      className="hidden"
                    />
                  </div>
                </div>

                {/* Photo URL Direct paste option */}
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={devPhoto}
                    onChange={(e) => setDevPhoto(e.target.value)}
                    placeholder="or paste custom picture URL..."
                    className="flex-1 w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-2.5 text-xs text-slate-100 outline-none placeholder-teal-600/50 transition-all"
                  />
                </div>

                {/* Developer Preset library gallery */}
                <div className="mt-1">
                  <span className="block text-[11px] font-bold text-slate-400 font-mono mb-2">
                    {t.gallerySelect}
                  </span>
                  <div className="flex items-center gap-3 overflow-x-auto pb-1 scrollbar-none">
                    {DEV_PRESETS.map((preset, index) => (
                      <button
                        key={index}
                        onClick={() => setDevPhoto(preset)}
                        className={`w-12 h-12 rounded-lg overflow-hidden border-2 shrink-0 transition-transform active:scale-90 cursor-pointer ${
                          devPhoto === preset
                            ? 'border-amber-400 scale-105 shadow-md shadow-amber-500/25'
                            : 'border-emerald-500/10 hover:border-emerald-500/30'
                        }`}
                      >
                        <img src={preset} alt={`Preset ${index + 1}`} className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Developer Facebook Link */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                  {t.devFacebookLabel || '📘 Developer Facebook ID URL'}
                </label>
                <input
                  type="text"
                  value={devFb}
                  onChange={(e) => setDevFb(e.target.value)}
                  className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-3 text-sm text-slate-100 outline-none placeholder-teal-600/50 transition-all"
                  placeholder="https://facebook.com/your-dev-facebook-id"
                />
              </div>

              {/* Facebook edit */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                  {t.facebookLabel}
                </label>
                <input
                  type="text"
                  value={fbUrl}
                  onChange={(e) => setFbUrl(e.target.value)}
                  className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-3 text-sm text-slate-100 outline-none placeholder-teal-600/50 transition-all"
                  placeholder="https://facebook.com/your-id"
                />
              </div>

              {/* Contact Bar Custom Admin controls */}
              <div className="bg-[#001411]/70 border border-amber-500/15 rounded-2xl p-4 sm:p-5 flex flex-col gap-4 mt-2">
                <div className="flex items-center justify-between border-b border-emerald-500/10 pb-2.5">
                  <span className="block text-xs font-extrabold uppercase tracking-wider text-amber-400 font-sans flex items-center gap-2">
                    📞 {lang === 'bn' ? 'যোগাযোগ বার সেটিংস' : 'Contact Bar Settings'}
                  </span>
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={showContactBar}
                      onChange={(e) => setShowContactBar(e.target.checked)}
                      className="accent-amber-500 rounded cursor-pointer"
                    />
                    <span className="text-[11px] font-bold text-slate-300">
                      {lang === 'bn' ? 'অন করুন' : 'Enable'}
                    </span>
                  </label>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">
                      {lang === 'bn' ? 'একাডেমির যোগাযোগ নম্বর' : 'Academy Phone Number'}
                    </label>
                    <input
                      type="text"
                      value={contactPhone}
                      onChange={(e) => setContactPhone(e.target.value)}
                      placeholder="+8801825316492"
                      className="w-full bg-[#011e19] border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">
                      {lang === 'bn' ? 'হোয়াটসঅ্যাপ সংযোগ লিংক' : 'WhatsApp Profile/Chat URL'}
                    </label>
                    <input
                      type="text"
                      value={contactWhatsapp}
                      onChange={(e) => setContactWhatsapp(e.target.value)}
                      placeholder="https://wa.me/8801825316492"
                      className="w-full bg-[#011e19] border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">
                      {lang === 'bn' ? 'ফেসবুক পেজ/আইডি লিংক' : 'Facebook Page/ID Link'}
                    </label>
                    <input
                      type="text"
                      value={contactFacebook}
                      onChange={(e) => setContactFacebook(e.target.value)}
                      placeholder="https://facebook.com/swargadhoni"
                      className="w-full bg-[#011e19] border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none transition-all"
                    />
                  </div>
                </div>
              </div>

              {/* Save Information button */}
              <button
                onClick={handleSaveInfo}
                className="mt-4 bg-gradient-to-r from-amber-500 to-amber-300 hover:from-amber-400 hover:to-amber-200 text-slate-950 font-bold py-3.5 px-6 rounded-xl text-sm sm:text-base cursor-pointer shadow-lg shadow-amber-500/10 active:scale-98 transition-all"
              >
                {t.saveBtn}
              </button>
            </div>
          )}

          {/* TAB 2: ADD ITEM CONTROL */}
          {activeTab === 'add' && (
            <div className="flex flex-col gap-4">
              
              {/* Category selector */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                  {t.categoryLabel}
                </label>
                <select
                  value={itemCat}
                  onChange={(e) => setItemCat(e.target.value)}
                  className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-3 text-sm text-slate-300 outline-none transition-all"
                >
                  {sections.map((sec) => (
                    <option key={sec} value={sec}>
                      {lang === 'bn' ? sectionNames[sec]?.bn : sectionNames[sec]?.en}
                    </option>
                  ))}
                </select>
              </div>

              {/* Media type specification */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                  {t.mediaTypeLabel}
                </label>
                <select
                  value={itemMedia}
                  onChange={(e) => setItemMedia(e.target.value as any)}
                  className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-3 text-sm text-slate-300 outline-none transition-all"
                >
                  <option value="both">{t.both}</option>
                  <option value="video">{lang === 'bn' ? '🎬 শুধুমাত্র ভিডিও লিংক' : '🎬 Video link only'}</option>
                  <option value="lyrics">{lang === 'bn' ? '📝 শুধুমাত্র রিলিক্স বা গীতি' : '📝 Lyrics only'}</option>
                </select>
              </div>

              {/* Title parameter */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                  {t.titleLabel}
                </label>
                <input
                  type="text"
                  value={itemTitle}
                  onChange={(e) => setItemTitle(e.target.value)}
                  placeholder={lang === 'bn' ? 'গানের চমৎকার একটি শিরোনাম লিখুন' : 'Enter standard song label/heading'}
                  className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-3 text-sm text-slate-100 outline-none transition-all"
                />
              </div>

              {/* YouTube Link edit */}
              {itemMedia !== 'lyrics' && (
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                    {t.videoUrlLabel}
                  </label>
                  <input
                    type="text"
                    value={itemVideoUrl}
                    onChange={(e) => setItemVideoUrl(e.target.value)}
                    placeholder="e.g. https://www.youtube.com/watch?v=dQw4w9WgXcQ"
                    className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-3 text-sm text-slate-100 outline-none transition-all"
                  />
                </div>
              )}

              {/* Lyrics input */}
              {itemMedia !== 'video' && (
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                    {t.lyricsLabel}
                  </label>
                  <textarea
                    value={itemLyrics}
                    onChange={(e) => setItemLyrics(e.target.value)}
                    rows={6}
                    placeholder={lang === 'bn' ? 'প্রতিটি নতুন লাইন সতর্কভাবে এনটার দিয়ে লিখুন...' : 'Separate lyrics cleanly with Enter key lines...'}
                    className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-3 text-sm text-slate-100 outline-none placeholder-teal-600/50 resize-y transition-all"
                  />
                </div>
              )}

              {/* Add item button selection */}
              <button
                onClick={handleAddItemSubmit}
                className="mt-4 bg-gradient-to-r from-amber-500 to-amber-300 hover:from-amber-400 hover:to-amber-200 text-slate-950 font-bold py-3.5 px-6 rounded-xl text-sm sm:text-base cursor-pointer shadow-lg shadow-amber-500/10 active:scale-98 transition-all"
              >
                {t.addBtn}
              </button>
            </div>
          )}

          {/* TAB 3: SONGS GRID MANAGER */}
          {activeTab === 'list' && (
            <div className="flex flex-col gap-3.5">
              {items.length === 0 ? (
                <p className="text-slate-500 text-center italic py-12">
                  {lang === 'bn' ? 'কোনো গান বা কবিতা যোগ করা হয়নি।' : 'No songs are currently stored.'}
                </p>
              ) : (
                items.map((item) => {
                  const catLabel = sectionNames[item.category]
                    ? lang === 'bn'
                      ? sectionNames[item.category].bn
                      : sectionNames[item.category].en
                    : item.category;

                  return (
                    <div
                      key={item.id}
                      className="bg-slate-950/60 border border-slate-850 hover:border-amber-500/10 p-4 rounded-2xl flex items-center justify-between gap-4 transition-all"
                    >
                      <div className="min-w-0">
                        <h4 className="text-sm font-bold text-slate-200 line-clamp-1">{item.title}</h4>
                        <div className="flex items-center gap-2 mt-1 sm:mt-1.5 flex-wrap">
                          <span className="text-[10px] bg-slate-800 text-slate-400 border border-slate-700 px-2 py-0.5 rounded-lg">
                            {catLabel}
                          </span>
                          <span className="text-[10px] bg-amber-500/10 text-amber-300 border border-amber-500/20 px-2 py-0.5 rounded-lg font-mono">
                            {item.mediaType.toUpperCase()}
                          </span>
                        </div>
                      </div>

                      {/* Edit or Delete interactions toolbar */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => handleInlineEdit(item)}
                          className="w-8 h-8 rounded-lg flex items-center justify-center bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 border border-amber-500/20 transition-all cursor-pointer"
                          title="সম্পাদনা"
                        >
                          <Edit size={13} />
                        </button>
                        <button
                          onClick={() => {
                            setConfirmConfig({
                              isOpen: true,
                              title: lang === 'bn' ? '⚠️ লিরিক্স / ভিডিও মুছুন' : '⚠️ Delete Item',
                              message: t.deleteConfirm || 'Are you sure you want to delete this item?',
                              onConfirm: () => {
                                onDeleteItem(item.id);
                              }
                            });
                          }}
                          className="w-8 h-8 rounded-lg flex items-center justify-center bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 border border-rose-500/20 transition-all cursor-pointer"
                          title="মুছে ফেলুন"
                        >
                          <Trash size={13} />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* TAB 4: SECTION CATEGORIES MANAGER */}
          {activeTab === 'section' && (
            <div className="flex flex-col gap-6">
              
              {/* Existing categories viewer */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-3 font-mono">
                  {t.currentSections}
                </h3>

                <div className="flex flex-col gap-3.5">
                  {sections.map((id) => {
                    const names = sectionNames[id];
                    if (!names) return null;
                    const isCore = ['hamd', 'nat', 'gazal', 'mankabat'].includes(id);

                    // Image or Emoji preview
                    let currentIconPreview: React.ReactNode = null;
                    if (names.icon) {
                      const trimmed = names.icon.trim();
                      if (
                        trimmed.startsWith('http://') ||
                        trimmed.startsWith('https://') ||
                        trimmed.startsWith('/') ||
                        trimmed.startsWith('data:image')
                      ) {
                        currentIconPreview = (
                          <img
                            src={trimmed}
                            alt=""
                            className="w-10 h-10 object-cover rounded-xl border border-emerald-500/20 shadow-md"
                            referrerPolicy="no-referrer"
                          />
                        );
                      } else {
                        currentIconPreview = (
                          <div className="w-10 h-10 flex items-center justify-center bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-lg select-none">
                            {trimmed}
                          </div>
                        );
                      }
                    } else {
                      let iconEmoji = '🎵';
                      if (id === 'hamd') iconEmoji = '🕌';
                      else if (id === 'nat') iconEmoji = '⭐';
                      else if (id === 'gazal') iconEmoji = '🎤';
                      else if (id === 'mankabat') iconEmoji = '📿';
                      currentIconPreview = (
                        <div className="w-10 h-10 flex items-center justify-center bg-slate-900 border border-slate-800 rounded-xl text-lg select-none text-slate-500 relative group">
                          {iconEmoji}
                          <span className="absolute -bottom-1 -right-1 bg-slate-850 px-1 py-0.5 rounded text-[7px] font-bold text-emerald-400 border border-emerald-500/10 tracking-widest scale-85 uppercase">DEF</span>
                        </div>
                      );
                    }

                    return (
                      <div
                        key={id}
                        className="bg-[#021f1a]/25 backdrop-blur-md border border-emerald-500/10 p-5 rounded-2xl flex flex-col gap-4 hover:border-emerald-500/25 transition-all duration-300 shadow-lg"
                      >
                        {/* Upper Info Row */}
                        <div className="flex items-center justify-between gap-4">
                          <div className="flex items-center gap-3">
                            {currentIconPreview}
                            <div>
                              <p className="text-sm font-extrabold text-slate-100 tracking-wide">
                                {names.bn} <span className="text-xs font-semibold text-emerald-400/50">| {names.en}</span>
                              </p>
                              <p className="text-[10px] text-slate-500 font-mono mt-0.5 uppercase tracking-wider">
                                {t.sectionIdLabel} {id}
                              </p>
                            </div>
                          </div>

                          {!isCore ? (
                            <button
                              onClick={() => handleDeleteSectionCheck(id)}
                              className="w-8 h-8 rounded-xl flex items-center justify-center bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-rose-400 transition-all cursor-pointer hover:scale-105 active:scale-95 shadow-md"
                              title={lang === 'bn' ? 'ক্যাটাগরি মুছে ফেলুন' : 'Delete Category'}
                            >
                              <Trash size={13} />
                            </button>
                          ) : (
                            <span className="text-[9px] font-black font-mono tracking-wider bg-slate-900/60 text-slate-500 border border-slate-800/80 px-2.5 py-1 rounded-lg uppercase select-none">
                              Core
                            </span>
                          )}
                        </div>

                        {/* Icon Configuration Row */}
                        <div className="border-t border-emerald-500/5 pt-3.5">
                          <label className="block text-[10px] text-emerald-400/60 font-black font-mono tracking-widest uppercase mb-1.5">
                            {lang === 'bn' ? '🎨 এই ক্যাটাগরির আইকন বা ছবি নির্ধারণ' : '🎨 Set Category Icon or Picture'}
                          </label>
                          <div className="flex flex-col sm:flex-row gap-2">
                            {/* Input emoji/url */}
                            <div className="flex-1 relative">
                              <input
                                type="text"
                                placeholder={lang === 'bn' ? 'ইমোজি (যেমন: 🕌) অথবা ছবির লিঙ্ক (https://...)' : 'Emoji (e.g. 🕌) or Image URL'}
                                value={editingSecIcons[id] !== undefined ? editingSecIcons[id] : (names.icon || '')}
                                onChange={(e) => setEditingSecIcons({ ...editingSecIcons, [id]: e.target.value })}
                                className="w-full bg-slate-950/80 border border-emerald-500/10 focus:border-emerald-500/30 rounded-xl px-4 py-2.5 text-xs text-slate-100 outline-none transition-all placeholder:text-slate-600 font-sans"
                              />
                            </div>

                            {/* Upload local image */}
                            <label className="flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-850 hover:text-emerald-400 border border-emerald-500/10 text-slate-300 text-xs font-bold transition-all cursor-pointer active:scale-95 shadow-md font-sans">
                              <Upload size={13} />
                              <span>{lang === 'bn' ? 'আপলোড' : 'Upload'}</span>
                              <input
                                type="file"
                                accept="image/*"
                                onChange={(e) => handleIconUpload(e, id)}
                                className="hidden"
                              />
                            </label>

                            {/* Action control buttons */}
                            <div className="flex gap-1.5">
                              <button
                                onClick={() => handleSaveSectionIcon(id)}
                                className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500/20 to-teal-500/20 hover:from-emerald-500/30 hover:to-teal-500/30 border border-emerald-500/30 text-emerald-300 text-xs font-black transition-all cursor-pointer active:scale-95 shadow-md btn-save font-sans"
                              >
                                {lang === 'bn' ? 'সংরক্ষণ' : 'Save'}
                              </button>
                              
                              {names.icon && (
                                <button
                                  onClick={() => handleDeleteSectionIcon(id)}
                                  className="px-3.5 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/25 border border-rose-500/20 text-rose-300 text-xs font-bold transition-all cursor-pointer active:scale-95 shadow-md btn-remove font-sans"
                                  title={lang === 'bn' ? 'আইকন রিমুভ করুন' : 'Remove Custom Icon'}
                                >
                                  {lang === 'bn' ? 'রিমুভ' : 'Remove'}
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Add Custom Section Controls */}
              <div className="bg-slate-950/40 border border-slate-850 p-5 rounded-2xl">
                <h3 className="text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-3.5 font-mono">
                  {lang === 'bn' ? '➕ নতুন সেকশন বা ক্যাটাগরি যোগ করুন' : '➕ Add Custom Song Category'}
                </h3>

                <div className="flex flex-col gap-4">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">বাংলা নাম</label>
                    <input
                      type="text"
                      value={newSecBn}
                      onChange={(e) => setNewSecBn(e.target.value)}
                      placeholder="যেমন: মনোহর গীত"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500/40 rounded-xl px-4 py-2.5 text-sm text-slate-100 outline-none transition-all placeholder:text-slate-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">English Name</label>
                    <input
                      type="text"
                      value={newSecEn}
                      onChange={(e) => setNewSecEn(e.target.value)}
                      placeholder="e.g. Sufi Devotional"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500/40 rounded-xl px-4 py-2.5 text-sm text-[#cacaca] outline-none transition-all placeholder:text-slate-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">
                      {lang === 'bn' ? 'ক্যাটাগরি আইকন বা ছবি (ঐচ্ছিক)' : 'Category Icon or Image (Optional)'}
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={newSecIcon}
                        onChange={(e) => setNewSecIcon(e.target.value)}
                        placeholder={lang === 'bn' ? 'ইমোজি (যেমন: 📚) অথবা ইমেজের লিঙ্ক' : 'Emoji (e.g. 📚) or any image URL'}
                        className="flex-1 bg-slate-950 border border-slate-800 focus:border-amber-500/40 rounded-xl px-4 py-2.5 text-xs text-slate-100 outline-none transition-all placeholder:text-slate-600 font-sans"
                      />
                      <label className="flex items-center justify-center gap-1.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-amber-500/20 text-slate-300 text-xs font-bold transition-all cursor-pointer active:scale-95 font-sans">
                        <Upload size={13} />
                        <span>{lang === 'bn' ? 'আপলোড' : 'Upload'}</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleIconUpload(e)}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>

                  <button
                    onClick={handleCreateSection}
                    className="w-full bg-slate-900 border border-slate-800 hover:border-amber-500/30 text-amber-400 hover:text-amber-300 font-bold py-2.5 rounded-xl text-xs sm:text-sm shadow-md transition-all active:scale-98 cursor-pointer font-sans"
                  >
                    {t.addSectionBtn}
                  </button>
                </div>
              </div>

            </div>
          )}

          {/* TAB 5: THEME CONTROLS */}
          {activeTab === 'theme' && (
            <div className="flex flex-col gap-6">
              <div className="text-center sm:text-left">
                <h3 className="text-sm font-bold uppercase tracking-wider text-amber-500/90 font-mono mb-2">
                  {t.themeLabel}
                </h3>
                <p className="text-xs text-slate-400">
                  {lang === 'bn' 
                    ? 'যেকোনো থিম সিলেক্ট করার সাথে সাথেই সকল ভিজিটরদের স্ক্রিনে তা লাইভ রিয়েল-টাইম আপডেট হয়ে যাবে।' 
                    : 'Selecting any theme will instantly update the application visual styles key-colors for all connected visitors in real time.'}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {PHYSICAL_THEMES.map((themeOption) => {
                  const isSelected = currentTheme === themeOption.id;
                  return (
                    <button
                      key={themeOption.id}
                      onClick={() => {
                        onChangeTheme(themeOption.id);
                        alert(t.themeSaved);
                      }}
                      className={`relative overflow-hidden p-5 rounded-2xl border text-left transition-all duration-300 transform hover:-translate-y-1 block w-full outline-none focus:outline-none cursor-pointer ${
                        isSelected
                          ? 'border-amber-400 bg-amber-500/10 shadow-lg shadow-amber-500/5'
                          : 'border-emerald-500/10 bg-[#000d0b]/40 hover:bg-[#000d0b]/85 hover:border-emerald-500/30'
                      }`}
                    >
                      {/* Interactive indicator */}
                      <div className="flex justify-between items-start mb-4">
                        <span className="text-sm font-extrabold text-slate-100">
                          {lang === 'bn' ? themeOption.nameBn : themeOption.nameEn}
                        </span>
                        {isSelected && (
                          <span className="text-[10px] bg-gradient-to-r from-amber-500 to-amber-300 text-slate-950 px-2 py-0.5 rounded font-black uppercase font-mono tracking-wider">
                            ACTIVE
                          </span>
                        )}
                      </div>

                      {/* Visual Swatch Color Bars representation */}
                      <div className="flex items-center gap-1.5 mt-2">
                        <span 
                          className="w-4 h-4 rounded-full border border-white/10" 
                          style={{ backgroundColor: themeOption.primaryBg }} 
                          title="Base Background"
                        />
                        <span 
                          className="w-4 h-4 rounded-full border border-white/10" 
                          style={{ backgroundColor: themeOption.headerBg }} 
                          title="Header Color"
                        />
                        <span 
                          className="w-4 h-4 rounded-full border border-white/10" 
                          style={{ backgroundColor: themeOption.badgeBgFrom }} 
                          title="Badge Color"
                        />
                        <span 
                          className="w-4 h-4 rounded-full border border-white/10" 
                          style={{ backgroundColor: themeOption.accentText }} 
                          title="Accent Text"
                        />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {activeTab === 'students' && (
            <div className="flex flex-col gap-6">
              {/* Tab Header Card */}
              <div className="bg-[#000d0b]/40 border border-emerald-500/15 rounded-2xl p-4 sm:p-5 animate-in fade-in duration-200 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-bold text-amber-400 mb-1 flex items-center gap-2">
                    <Award size={16} />
                    {lang === 'bn' ? '🎓 শিক্ষার্থী ভর্তি ও উপস্থিতির তথ্য' : '🎓 Admission & Attendance Hub'}
                  </h4>
                  <p className="text-xs text-slate-400">
                    {lang === 'bn' 
                      ? 'শিক্ষার্থীদের ভর্তি বিবরণ দেখুন, দৈনিক হাজিরা (উপস্থিত/অনুপস্থিত) নির্ধারণ করুন এবং প্রিন্টযোগ্য প্রিন্টার রিপোর্ট তালিকা সংগ্রহ করুন।' 
                      : 'Track student enrollments, mark daily present or absent status, and print thermal receipt ledger reports.'}
                  </p>
                </div>
                {/* Admin Control Switch for public online student registration */}
                <div className="bg-[#021f1a]/85 border border-emerald-500/20 rounded-xl p-3 flex items-center gap-3 w-full md:w-auto shrink-0 select-none">
                  <div className="flex flex-col">
                    <span className="text-[11px] font-extrabold text-amber-400 uppercase tracking-wide">
                      {lang === 'bn' ? 'অনলাইন ভর্তি' : 'Online Admission'}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {isAdmissionEnabled 
                        ? (lang === 'bn' ? '🟢 চালু আছে' : '🟢 Opened') 
                        : (lang === 'bn' ? '🔴 বন্ধ আছে' : '🔴 Closed')
                      }
                    </span>
                  </div>
                  <button
                    onClick={() => onUpdateAdmissionEnabled?.(!isAdmissionEnabled)}
                    className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      isAdmissionEnabled ? 'bg-amber-500' : 'bg-slate-700'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                        isAdmissionEnabled ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* Analytics Dashboard Grid */}
              {(() => {
                const totalStudents = students.length;
                const activeStudents = students.filter(s => !s.status || s.status === 'active').length;
                const completedStudents = students.filter(s => s.status === 'completed').length;
                
                // Attendance
                const overallPres = students.reduce((acc, current) => {
                  let pc = 0;
                  if (current.attendance) {
                    Object.values(current.attendance).forEach(v => { if (v === 'present') pc++; });
                  }
                  return acc + pc;
                }, 0);
                const overallAbs = students.reduce((acc, current) => {
                  let ac = 0;
                  if (current.attendance) {
                    Object.values(current.attendance).forEach(v => { if (v === 'absent') ac++; });
                  }
                  return acc + ac;
                }, 0);
                const overallTot = overallPres + overallAbs;
                const overallRate = overallTot > 0 ? Math.round((overallPres / overallTot) * 100) : 100;

                return (
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 animate-in fade-in slide-in-from-bottom-3 duration-300 delay-75">
                    {/* Card 1: Total Enrolled */}
                    <div className="bg-[#021f1a]/40 backdrop-blur-md border border-emerald-500/10 rounded-2xl p-4.5 flex flex-col justify-between relative overflow-hidden group hover:border-emerald-500/25 transition-all duration-300 shadow-lg">
                      <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-emerald-500/5 to-transparent rounded-full -mr-6 -mt-6 pointer-events-none transition-transform group-hover:scale-110" />
                      <div className="flex items-center justify-between mb-3.5">
                        <span className="text-[10px] font-black tracking-widest text-emerald-400 font-mono uppercase">
                          {lang === 'bn' ? 'মোট শিক্ষার্থী' : 'Enrollments'}
                        </span>
                        <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                          <Users size={14} />
                        </div>
                      </div>
                      <div>
                        <span className="text-2xl sm:text-3xl font-black text-slate-100 font-mono leading-none">
                          {totalStudents}
                        </span>
                        <p className="text-[9px] text-slate-500 mt-1 font-sans">
                          {lang === 'bn' ? 'আজীবন নথিভুক্ত শিক্ষার্থী সংখ্যা' : 'Lifetime registered learners'}
                        </p>
                      </div>
                    </div>

                    {/* Card 2: Active Students */}
                    <div className="bg-[#021f1a]/40 backdrop-blur-md border border-emerald-500/10 rounded-2xl p-4.5 flex flex-col justify-between relative overflow-hidden group hover:border-emerald-500/25 transition-all duration-300 shadow-lg">
                      <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-teal-500/5 to-transparent rounded-full -mr-6 -mt-6 pointer-events-none transition-transform group-hover:scale-110" />
                      <div className="flex items-center justify-between mb-3.5">
                        <span className="text-[10px] font-black tracking-widest text-[#34d399] font-mono uppercase">
                          {lang === 'bn' ? 'সক্রিয় শিক্ষার্থী' : 'Active Learners'}
                        </span>
                        <div className="p-2 rounded-xl bg-[#10b981]/10 border border-[#10b981]/20 text-emerald-400">
                          <BookOpen size={14} />
                        </div>
                      </div>
                      <div>
                        <span className="text-2xl sm:text-3xl font-black text-slate-100 font-mono leading-none">
                          {activeStudents}
                        </span>
                        <p className="text-[9px] text-[#34d399]/70 mt-1 font-sans flex items-center gap-1">
                          <span className="w-1.5 h-1.5 bg-[#10b981] rounded-full animate-pulse" />
                          {lang === 'bn' ? 'বর্তমানে ক্লাস করছেন' : 'Actively attending class'}
                        </p>
                      </div>
                    </div>

                    {/* Card 3: Completed */}
                    <div className="bg-[#021f1a]/40 backdrop-blur-md border border-emerald-500/10 rounded-2xl p-4.5 flex flex-col justify-between relative overflow-hidden group hover:border-emerald-500/25 transition-all duration-300 shadow-lg">
                      <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-purple-500/5 to-transparent rounded-full -mr-6 -mt-6 pointer-events-none transition-transform group-hover:scale-110" />
                      <div className="flex items-center justify-between mb-3.5">
                        <span className="text-[10px] font-black tracking-widest text-purple-400 font-mono uppercase">
                          {lang === 'bn' ? 'কোর্স সম্পন্ন' : 'Graduates'}
                        </span>
                        <div className="p-2 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400">
                          <Award size={14} />
                        </div>
                      </div>
                      <div>
                        <span className="text-2xl sm:text-3xl font-black text-slate-100 font-mono leading-none">
                          {completedStudents}
                        </span>
                        <p className="text-[9px] text-slate-500 mt-1 font-sans">
                          {lang === 'bn' ? 'সনদপত্রপ্রাপ্ত গ্র্যাজুয়েট' : 'Verified alumni with certificates'}
                        </p>
                      </div>
                    </div>

                    {/* Card 4: Attendance performance */}
                    <div className="bg-[#021f1a]/40 backdrop-blur-md border border-emerald-500/10 rounded-2xl p-4.5 flex flex-col justify-between relative overflow-hidden group hover:border-emerald-500/25 transition-all duration-300 shadow-lg">
                      <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-amber-500/5 to-transparent rounded-full -mr-6 -mt-6 pointer-events-none transition-transform group-hover:scale-110" />
                      <div className="flex items-center justify-between mb-3.5">
                        <span className="text-[10px] font-black tracking-widest text-amber-400 font-mono uppercase">
                          {lang === 'bn' ? 'হাজিরার গড় হার' : 'Attendance Rate'}
                        </span>
                        <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
                          <LineChart size={14} />
                        </div>
                      </div>
                      <div>
                        <div className="flex items-baseline gap-1.5 leading-none">
                          <span className="text-2xl sm:text-3xl font-black text-slate-100 font-mono">
                            {overallRate}%
                          </span>
                        </div>
                        {/* attendance visual micro progress bar */}
                        <div className="w-full bg-slate-950/50 h-1 rounded-full mt-2.5 overflow-hidden">
                          <div 
                            className="bg-gradient-to-r from-emerald-500 to-amber-400 h-full rounded-full transition-all duration-500"
                            style={{ width: `${overallRate}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Attendance Date Selector and Search Group */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 items-end">
                {/* Date Input */}
                <div className="bg-[#000d0b]/50 border border-emerald-500/15 rounded-xl p-3 flex flex-col gap-2">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-[#34d399] flex items-center gap-1.5 font-mono">
                    <Calendar size={11} />
                    {lang === 'bn' ? 'উপস্থিতির তারিখ নির্বাচন' : 'Attendance Date'}
                  </span>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-3 py-2 text-xs text-[#1e293b] outline-none"
                    style={{ color: '#ffffff', backgroundColor: '#000d0b' }}
                  />
                </div>

                {/* Filter Input */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-teal-600/60 w-3.5 h-3.5" />
                  <input
                    type="text"
                    value={studentFilter}
                    onChange={(e) => setStudentFilter(e.target.value)}
                    placeholder={lang === 'bn' ? 'শিক্ষার্থীর নাম বা মোবাইল দিয়ে খুঁজুন...' : 'Search name or mobile...'}
                    className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl pl-9 pr-4 py-2.5 text-xs text-slate-100 outline-none placeholder-teal-600/30 font-sans"
                  />
                </div>
              </div>

              {/* Student Admission Table List */}
              <div className="bg-[#000d0b]/50 border border-emerald-500/15 rounded-2xl overflow-hidden">
                <div className="px-4 py-3 bg-[#011e19]/40 border-b border-emerald-950 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                  <span className="text-xs font-bold text-amber-400 font-mono">
                    {lang === 'bn' ? `সর্বমোট শিক্ষার্থী: ${students.length} জন` : `Enrolled: ${students.length} students`}
                  </span>
                  <div className="flex gap-2 w-full sm:w-auto">
                    <button
                      type="button"
                      onClick={handleExportStudents}
                      className="flex items-center gap-1.5 px-3 py-1 bg-teal-500/10 hover:bg-teal-500/25 text-teal-300 border border-teal-500/30 rounded-lg text-xs font-bold font-sans transition-all active:scale-95 cursor-pointer"
                      title={lang === 'bn' ? 'এক্সেল বা সিএসভি ফাইলে ব্যাকআপ ডাউনলোড করুন' : 'Export Excel/CSV Backup'}
                    >
                      <Download size={12} />
                      <span>{lang === 'bn' ? 'ব্যাকআপ ডাউনলোড' : 'Download Backup'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        if (isSyncing) return;
                        setIsSyncing(true);
                        try {
                          if (onSyncAllStudents) {
                            await onSyncAllStudents();
                            setAlertConfig({
                              isOpen: true,
                              title: lang === 'bn' ? '✅ ডাটাবেজ চূড়ান্ত সেভ সফল' : '✅ Database Save Successful',
                              message: lang === 'bn' 
                                ? 'সকল শিক্ষার্থীর তথ্য ফায়ারবেস ক্লাউড ডাটাবেজ এবং অফলাইন ব্যাকআপে সফলভাবে সুরক্ষিত করা হয়েছে!' 
                                : 'Successfully synchronized and saved all student records into Firebase Realtime Database!',
                            });
                          }
                        } catch (err) {
                          setAlertConfig({
                            isOpen: true,
                            title: lang === 'bn' ? '❌ সংরক্ষণ ব্যর্থ' : '❌ Save Failed',
                            message: lang === 'bn' 
                              ? 'ক্লাউড ডাটাবেজে তথ্য চূড়ান্ত সংরক্ষণ করা সম্ভব হয়নি।' 
                              : 'Unable to sync records to Firebase Cloud. Please check your network connection.',
                          });
                        } finally {
                          setIsSyncing(false);
                        }
                      }}
                      disabled={isSyncing}
                      className={`flex items-center gap-1.5 px-3 py-1 text-xs font-bold font-sans transition-all active:scale-95 cursor-pointer rounded-lg border ${
                        isSyncing 
                          ? 'bg-slate-800 text-slate-500 border-slate-700 cursor-not-allowed' 
                          : 'bg-emerald-500/10 hover:bg-emerald-500/25 text-emerald-300 border-emerald-500/30'
                      }`}
                      title={lang === 'bn' ? 'সব শিক্ষার্থীর তথ্য ফায়ারবেস ক্লাউড ডাটাবেজে চূড়ান্ত সংরক্ষণ করুন' : 'Force sync all student data with cloud database'}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full ${isSyncing ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'}`} />
                      <span>{isSyncing ? (lang === 'bn' ? 'সেভ হচ্ছে...' : 'Saving...') : (lang === 'bn' ? 'চূড়ান্ত সেভ (ফায়ারবেস)' : 'Final Save (Firebase)')}</span>
                    </button>
                    <button
                      onClick={() => setIsAddingStudent(!isAddingStudent)}
                      className="flex items-center gap-1.5 px-3 py-1 bg-amber-500 hover:bg-amber-600 text-[#011411] rounded-lg text-xs font-bold font-sans transition-all active:scale-95 cursor-pointer shadow-sm shadow-amber-500/10"
                    >
                      <Plus size={12} />
                      <span>{lang === 'bn' ? 'শিক্ষার্থী যোগ করুন' : 'Add Student'}</span>
                    </button>
                  </div>
                </div>

                {isAddingStudent && (
                  <form 
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!newStdNameBn.trim() || !newStdNameEn.trim() || !newStdFather.trim() || !newStdMother.trim() || !newStdMobile.trim() || !newStdAddress.trim() || !newStdBatchTime.trim() || !newStdClassDays.trim() || !newStdCourseDuration.trim()) {
                        setAlertConfig({
                          isOpen: true,
                          title: lang === 'bn' ? '⚠️ তথ্য অসম্পূর্ণ' : '⚠️ Incomplete Info',
                          message: lang === 'bn' ? 'অনুগ্রহ করে সব তথ্য পূরণ করুন!' : 'Please fill in all fields!',
                        });
                        return;
                      }
                      
                      const mobilePattern = /^[0-9+-\s]{5,18}$/;
                      if (!mobilePattern.test(newStdMobile)) {
                        setAlertConfig({
                          isOpen: true,
                          title: lang === 'bn' ? '⚠️ ভুল মোবাইল নম্বর' : '⚠️ Invalid Mobile',
                          message: lang === 'bn' ? 'সঠিক মোবাইল নম্বর দিন!' : 'Please enter a valid mobile number!',
                        });
                        return;
                      }

                      const studentId = 'STD' + Math.floor(100000 + Math.random() * 900000);
                      const newStudent = {
                        id: studentId,
                        name: newStdNameBn.trim(), // Primary name falls back to Bangla
                        nameBn: newStdNameBn.trim(),
                        nameEn: newStdNameEn.trim(),
                        fatherName: newStdFather.trim(),
                        motherName: newStdMother.trim(),
                        photo: newStdPhoto,
                        mobile: newStdMobile.trim(),
                        address: newStdAddress.trim(),
                        batchTime: newStdBatchTime.trim(),
                        classDaysPerWeek: newStdClassDays.trim(),
                        courseDuration: newStdCourseDuration.trim(),
                        status: 'active' as const,
                        createdAt: Date.now(),
                        attendance: {},
                      };

                      onAddStudent(newStudent);
                      setNewStdName('');
                      setNewStdNameBn('');
                      setNewStdNameEn('');
                      setNewStdFather('');
                      setNewStdMother('');
                      setNewStdPhoto('');
                      setNewStdMobile('');
                      setNewStdAddress('');
                      setNewStdBatchTime('');
                      setNewStdClassDays('');
                      setNewStdCourseDuration('');
                      setIsAddingStudent(false);
                      setAlertConfig({
                        isOpen: true,
                        title: lang === 'bn' ? '🎉 সফল হয়েছে' : '🎉 Success',
                        message: lang === 'bn' ? 'শিক্ষার্থী সফলভাবে যুক্ত করা হয়েছে!' : 'Student successfully added!',
                      });
                    }}
                    className="p-4 bg-[#012d25]/40 border-b border-emerald-950/60 flex flex-col gap-3 animate-in slide-in-from-top-4 duration-300"
                  >
                    <div className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-1 font-mono">
                      {lang === 'bn' ? '📝 নতুন শিক্ষার্থী নিবন্ধন ফরম' : '📝 New Student Registration Form'}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pb-1">
                      {/* Name Bangla */}
                      <div>
                        <label className="block text-[10px] font-bold text-slate-400 mb-1">
                          {lang === 'bn' ? 'শিক্ষার্থীর নাম (বাংলা) *' : 'Student Name (Bengali) *'}
                        </label>
                        <input
                          type="text"
                          required
                          value={newStdNameBn}
                          onChange={(e) => setNewStdNameBn(e.target.value)}
                          placeholder="যেমন: আহসান হাবিব..."
                          className="w-full bg-[#000d0b]/90 border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none font-sans"
                        />
                      </div>
                      
                      {/* Name English */}
                      <div>
                        <label className="block text-[10px] font-bold text-slate-400 mb-1">
                          {lang === 'bn' ? 'শিক্ষার্থীর নাম (ইংরেজি) *' : 'Student Name (English) *'}
                        </label>
                        <input
                          type="text"
                          required
                          value={newStdNameEn}
                          onChange={(e) => setNewStdNameEn(e.target.value)}
                          placeholder="e.g. Ahsan Habib..."
                          className="w-full bg-[#000d0b]/90 border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none font-sans"
                        />
                      </div>

                      {/* Father's Name */}
                      <div>
                        <label className="block text-[10px] font-bold text-slate-400 mb-1">
                          {lang === 'bn' ? 'পিতার নাম *' : 'Father\'s Name *'}
                        </label>
                        <input
                          type="text"
                          required
                          value={newStdFather}
                          onChange={(e) => setNewStdFather(e.target.value)}
                          placeholder={lang === 'bn' ? 'পিতার নাম লিখুন...' : 'Enter father\'s name...'}
                          className="w-full bg-[#000d0b]/90 border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none font-sans"
                        />
                      </div>

                      {/* Mother's Name */}
                      <div>
                        <label className="block text-[10px] font-bold text-slate-400 mb-1">
                          {lang === 'bn' ? 'মাতার নাম *' : 'Mother\'s Name *'}
                        </label>
                        <input
                          type="text"
                          required
                          value={newStdMother}
                          onChange={(e) => setNewStdMother(e.target.value)}
                          placeholder={lang === 'bn' ? 'মাতার নাম লিখুন...' : 'Enter mother\'s name...'}
                          className="w-full bg-[#000d0b]/90 border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none font-sans"
                        />
                      </div>

                      {/* Mobile Number */}
                      <div>
                        <label className="block text-[10px] font-bold text-slate-400 mb-1">
                          {lang === 'bn' ? 'মোবাইল নম্বর *' : 'Mobile Number *'}
                        </label>
                        <input
                          type="tel"
                          required
                          value={newStdMobile}
                          onChange={(e) => setNewStdMobile(e.target.value)}
                          placeholder={lang === 'bn' ? 'যেমন: ০১৭...' : 'e.g. +88017...'}
                          className="w-full bg-[#000d0b]/90 border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none font-sans"
                        />
                      </div>

                      {/* Photo upload block */}
                      <div>
                        <label className="block text-[10px] font-bold text-slate-400 mb-1">
                          {lang === 'bn' ? 'শিক্ষার্থীর ছবি (ঐচ্ছিক)' : 'Student Photo (Optional)'}
                        </label>
                        <div className="flex items-center gap-2">
                          <label className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 bg-[#000d0b]/90 border border-emerald-500/15 hover:border-amber-500/50 text-slate-300 hover:text-amber-400 rounded-lg cursor-pointer text-[10px] transition-colors">
                            <Camera size={12} className="text-amber-500 shrink-0" />
                            <span>{isNewStdPhotoUploading ? (lang === 'bn' ? 'প্রসেসিং...' : 'Uploading...') : (lang === 'bn' ? 'ছবি দিন' : 'Add Photo')}</span>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={async (e) => {
                                const file = e.target.files?.[0];
                                if (!file) return;
                                try {
                                  setIsNewStdPhotoUploading(true);
                                  const base64 = await compressImageToBase64(file);
                                  setNewStdPhoto(base64);
                                } catch (err) {
                                  console.error(err);
                                } finally {
                                  setIsNewStdPhotoUploading(false);
                                }
                              }}
                              className="hidden"
                            />
                          </label>
                          {newStdPhoto && (
                            <div className="relative w-8 h-8 rounded border border-emerald-500/25 overflow-hidden shrink-0">
                              <img src={newStdPhoto} alt="Student" className="w-full h-full object-cover" />
                              <button
                                type="button"
                                onClick={() => setNewStdPhoto('')}
                                className="absolute inset-0 bg-black/60 opacity-0 hover:opacity-100 flex items-center justify-center text-red-500 text-[10px] transition-opacity cursor-pointer font-bold font-mono"
                              >
                                X
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Batch Time Field */}
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 mb-1">
                        {lang === 'bn' ? '⏰ কয়টার ব্যাচ *' : '⏰ Batch Time *'}
                      </label>
                      <input
                        type="text"
                        required
                        value={newStdBatchTime}
                        onChange={(e) => setNewStdBatchTime(e.target.value)}
                        placeholder={lang === 'bn' ? 'যেমন: বিকেল ৪:০০ টা...' : 'e.g. 04:00 PM...'}
                        className="w-full bg-[#000d0b]/90 border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none font-sans"
                      />
                    </div>

                    {/* Class Days per Week */}
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 mb-1">
                        {lang === 'bn' ? '📅 সপ্তাহে ক্লাস কয়দিন *' : '📅 Class Days per Week *'}
                      </label>
                      <input
                        type="text"
                        required
                        value={newStdClassDays}
                        onChange={(e) => setNewStdClassDays(e.target.value)}
                        placeholder={lang === 'bn' ? 'যেমন: ৩ দিন (সোম, বুধ, শুক্র)...' : 'e.g. 3 Days (Mon, Wed, Fri)...'}
                        className="w-full bg-[#000d0b]/90 border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none font-sans"
                      />
                    </div>

                    {/* Course Duration */}
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 mb-1">
                        {lang === 'bn' ? '🎓 কত মাসের কোর্স *' : '🎓 Course Duration *'}
                      </label>
                      <input
                        type="text"
                        required
                        value={newStdCourseDuration}
                        onChange={(e) => setNewStdCourseDuration(e.target.value)}
                        placeholder={lang === 'bn' ? 'যেমন: ৬ মাস / ১২ মাস...' : 'e.g. 6 Months / 12 Months...'}
                        className="w-full bg-[#000d0b]/90 border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none font-sans"
                      />
                    </div>

                    {/* Address block */}
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 mb-1">
                        {lang === 'bn' ? 'ঠিকানা *' : 'Address *'}
                      </label>
                      <input
                        type="text"
                        required
                        value={newStdAddress}
                        onChange={(e) => setNewStdAddress(e.target.value)}
                        placeholder={lang === 'bn' ? 'স্থায়ী বা वर्तमान ঠিকানা...' : 'Enter permanent or present address...'}
                        className="w-full bg-[#000d0b]/90 border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none font-sans"
                      />
                    </div>

                    <div className="flex justify-end gap-2 pt-2 border-t border-emerald-950/20 mt-1">
                      <button
                        type="button"
                        onClick={() => {
                          setIsAddingStudent(false);
                          setNewStdName('');
                          setNewStdNameBn('');
                          setNewStdNameEn('');
                          setNewStdFather('');
                          setNewStdMother('');
                          setNewStdPhoto('');
                          setNewStdMobile('');
                          setNewStdAddress('');
                          setNewStdBatchTime('');
                          setNewStdClassDays('');
                          setNewStdCourseDuration('');
                        }}
                        className="px-3 py-1.5 border border-emerald-500/20 bg-[#000d0b]/40 text-[#34d399] hover:bg-[#000d0b]/80 rounded-lg text-xs font-semibold cursor-pointer text-center"
                      >
                        {lang === 'bn' ? 'বাতিল' : 'Cancel'}
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-[#011411] font-bold rounded-lg text-xs transition-colors cursor-pointer shadow shadow-emerald-500/25"
                      >
                        {lang === 'bn' ? 'সংরক্ষণ করুন' : 'Save Student'}
                      </button>
                    </div>
                  </form>
                )}

                {/* Status Tab Selector */}
                <div className="flex border-b border-emerald-950/40 bg-[#001411]/20 font-sans text-xs">
                  <button
                    onClick={() => setAdminStudentTab('active')}
                    className={`flex-1 py-2.5 font-bold transition-all text-center border-b-2 flex items-center justify-center gap-1.5 cursor-pointer ${
                      adminStudentTab === 'active'
                        ? 'border-emerald-500 text-emerald-400 bg-emerald-500/5'
                        : 'border-transparent text-slate-400 hover:text-slate-300'
                    }`}
                  >
                    <span>🟢 {lang === 'bn' ? 'সক্রিয় শিক্ষার্থী' : 'Active'}</span>
                    <span className="text-[10px] pl-1.5 pr-1.5 py-0.2 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full font-mono">
                      {students.filter(s => (s.status || 'active') === 'active').length}
                    </span>
                  </button>
                  <button
                    onClick={() => setAdminStudentTab('old')}
                    className={`flex-1 py-2.5 font-bold transition-all text-center border-b-2 flex items-center justify-center gap-1.5 cursor-pointer ${
                      adminStudentTab === 'old'
                        ? 'border-amber-500 text-amber-500 bg-amber-500/5'
                        : 'border-transparent text-slate-400 hover:text-slate-300'
                    }`}
                  >
                    <span>🎓 {lang === 'bn' ? 'পুরাতন শিক্ষার্থী (Old Student)' : 'Old Students'}</span>
                    <span className="text-[10px] pl-1.5 pr-1.5 py-0.2 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded-full font-mono">
                      {students.filter(s => s.status === 'old' || s.status === 'completed').length}
                    </span>
                  </button>
                </div>

                <div className="max-h-[550px] overflow-y-auto divide-y divide-emerald-500/10 scrollbar-thin">
                  {students.length === 0 ? (
                    <div className="py-8 text-center text-xs text-slate-500 font-sans flex flex-col items-center justify-center gap-2">
                      <AlertCircle size={28} className="text-amber-500/60" />
                      {lang === 'bn' 
                        ? 'কোনো নিবন্ধিত শিক্ষার্থী পাওয়া যায়নি। ভর্তি ফরম পূরণ করুন!' 
                        : 'No students enrolled yet. Submit the registration form!'}
                    </div>
                  ) : (() => {
                    const statusFiltered = students.filter((std) => {
                      const currentStatus = std.status || 'active';
                      if (adminStudentTab === 'active') {
                        return currentStatus === 'active';
                      } else {
                        return currentStatus === 'old' || currentStatus === 'completed';
                      }
                    });

                    const filtered = statusFiltered.filter((std) => {
                      const query = studentFilter.toLowerCase().trim();
                      if (!query) return true;
                      return (
                        (std.name || '').toLowerCase().includes(query) ||
                        (std.nameBn || '').toLowerCase().includes(query) ||
                        (std.nameEn || '').toLowerCase().includes(query) ||
                        (std.mobile || '').includes(query)
                      );
                    });

                    if (filtered.length === 0) {
                      return (
                        <div className="py-8 text-center text-xs text-slate-500">
                          {lang === 'bn' ? 'কোনো শিক্ষার্থী পছন্দসই অনুসন্ধানের সাথে মেলেনি।' : 'No search matching students found.'}
                        </div>
                      );
                    }

                    return filtered.map((student) => {
                      const attendanceStatus = student.attendance?.[selectedDate];
                      const attendance = student.attendance || {};
                      const presentDays = Object.values(attendance).filter(status => status === 'present').length;
                      const absentDays = Object.values(attendance).filter(status => status === 'absent').length;

                      return (
                        <motion.div
                          key={student.id}
                          layout
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          whileHover={{
                            y: -2,
                            backgroundColor: "rgba(0, 13, 11, 0.45)",
                            borderColor: "rgba(16, 185, 129, 0.15)",
                            boxShadow: "0 8px 30px rgba(0, 0, 0, 0.12)"
                          }}
                          transition={{ duration: 0.2, ease: "easeOut" }}
                          className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border border-emerald-500/0 rounded-xl transition-all duration-300"
                        >
                          <div className="flex gap-3 min-w-0">
                            {/* Avatar or Photo */}
                            <div className="w-10 h-10 rounded border border-emerald-500/15 overflow-hidden bg-emerald-500/5 shrink-0 flex items-center justify-center">
                              {student.photo ? (
                                <img src={student.photo} alt="Student" className="w-full h-full object-cover" />
                              ) : (
                                <User size={18} className="text-emerald-500/60" />
                              )}
                            </div>

                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5 mb-1 flex-wrap">
                                <span className="text-xs font-black text-slate-200">
                                  {student.nameBn || student.name}
                                </span>
                                {student.nameEn && (
                                  <span className="text-[10px] text-slate-400 font-sans uppercase">
                                    ({student.nameEn})
                                  </span>
                                )}
                                <span className="text-[9px] font-mono text-emerald-400 bg-emerald-500/5 border border-emerald-500/10 px-1 py-0.5 rounded">
                                  {student.id}
                                </span>
                              </div>
                              
                              <div className="flex flex-col gap-0.5 text-[11px] text-slate-400 font-sans">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span>📞 {student.mobile}</span>
                                  <span className="text-slate-600">|</span>
                                  <span className="truncate">📍 {student.address}</span>
                                </div>
                                {(student.fatherName || student.motherName) && (
                                  <div className="text-[10px] text-slate-500 flex items-center gap-2 flex-wrap mt-0.5">
                                    {student.fatherName && <span>👨‍👦 {lang === 'bn' ? `পিতা: ${student.fatherName}` : `Father: ${student.fatherName}`}</span>}
                                    {student.motherName && <span>👩‍👦 {lang === 'bn' ? `মাতা: ${student.motherName}` : `Mother: ${student.motherName}`}</span>}
                                  </div>
                                )}
                                
                                <div className="text-[10px] text-[#34d399]/85 font-sans flex items-center gap-2 flex-wrap mt-1">
                                  {student.batchTime && <span className="bg-[#000d0b]/80 border border-emerald-500/10 px-1.5 py-0.5 rounded">⏰ {lang === 'bn' ? `ব্যাচ: ${student.batchTime}` : `Batch: ${student.batchTime}`}</span>}
                                  {student.classDaysPerWeek && <span className="bg-[#000d0b]/80 border border-emerald-500/10 px-1.5 py-0.5 rounded font-mono">📅 {lang === 'bn' ? `সাপ্তাহিক ক্লাস: ${student.classDaysPerWeek}` : `Classes: ${student.classDaysPerWeek}`}</span>}
                                  {student.courseDuration && <span className="bg-[#000d0b]/80 border border-emerald-500/10 px-1.5 py-0.5 rounded font-bold">🎓 {lang === 'bn' ? `মেয়াদ: ${student.courseDuration}` : `Duration: ${student.courseDuration}`}</span>}
                                  
                                  {/* Interactive Status Switcher Toggle with Spring Transition */}
                                  <div className="flex items-center gap-1.5 bg-[#000d0b]/60 border border-emerald-500/10 px-2 py-0.5 rounded-md hover:border-emerald-500/20 transition-all select-none">
                                    <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider font-sans">
                                      {lang === 'bn' ? 'অবস্থা:' : 'Status:'}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const isCurrentlyActive = !student.status || student.status === 'active';
                                        const updatedStudent: Student = {
                                          ...student,
                                          status: isCurrentlyActive ? 'old' : 'active'
                                        };
                                        onUpdateStudent(updatedStudent);
                                      }}
                                      className={`w-9 h-5 rounded-full p-0.5 transition-colors duration-350 relative flex items-center cursor-pointer overflow-hidden ${
                                        (!student.status || student.status === 'active')
                                          ? 'bg-emerald-500/20 border border-emerald-500/20'
                                          : 'bg-amber-500/20 border border-amber-500/20'
                                      }`}
                                      title={lang === 'bn' ? 'অবস্থা পরিবর্তন করুন (সক্রিয়/পুরাতন)' : 'Toggle status (Active/Old)'}
                                    >
                                      <motion.div
                                        layout
                                        transition={{ type: "spring", stiffness: 500, damping: 25 }}
                                        className={`w-3.5 h-3.5 rounded-full shadow-md ${
                                          (!student.status || student.status === 'active')
                                            ? 'bg-emerald-400'
                                            : 'bg-amber-400'
                                        }`}
                                        style={{
                                          marginLeft: (!student.status || student.status === 'active') ? 'auto' : '0px',
                                          marginRight: (!student.status || student.status === 'active') ? '0px' : 'auto',
                                        }}
                                      />
                                    </button>
                                    <span className={`text-[10px] font-bold font-sans uppercase tracking-wider ${
                                      (!student.status || student.status === 'active')
                                        ? 'text-emerald-400'
                                        : 'text-amber-400'
                                    }`}>
                                      {(!student.status || student.status === 'active')
                                        ? (lang === 'bn' ? 'সক্রিয়' : 'Active')
                                        : (student.status === 'completed'
                                          ? (lang === 'bn' ? 'সম্পন্ন' : 'Completed')
                                          : (lang === 'bn' ? 'পুরাতন' : 'Old')
                                        )}
                                    </span>
                                  </div>
                                </div>
                                <div className="flex items-center gap-1.5 flex-wrap mt-1 text-[9px] font-bold font-mono">
                                  <span className="text-emerald-400 bg-emerald-500/10 border border-emerald-500/25 px-1.5 py-0.5 rounded">
                                    🟢 {presentDays} {lang === 'bn' ? 'উপস্থিত' : 'Present'}
                                  </span>
                                  <span className="text-red-400 bg-red-500/10 border border-red-500/25 px-1.5 py-0.5 rounded">
                                    🔴 {absentDays} {lang === 'bn' ? 'অনুপস্থিত' : 'Absent'}
                                  </span>
                                  <span className="text-amber-400 bg-amber-500/10 border border-amber-500/25 px-1.5 py-0.5 rounded">
                                    📊 {student.results?.length || 0} {lang === 'bn' ? 'ফলাফল' : 'Results'}
                                  </span>
                                  <span className="text-purple-400 bg-purple-500/10 border border-purple-500/25 px-1.5 py-0.5 rounded">
                                    📜 {student.certificates?.length || 0} {lang === 'bn' ? 'সনদ' : 'Certificates'}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Attendance Mark Options */}
                          <div className="flex items-center gap-2 shrink-0 self-end sm:self-center flex-wrap justify-end">
                            {/* Edit Student Info Button */}
                            <button
                              onClick={() => {
                                setEditingStudent(student);
                                setEditStdNameBn(student.nameBn || student.name || '');
                                setEditStdNameEn(student.nameEn || '');
                                setEditStdFather(student.fatherName || '');
                                setEditStdMother(student.motherName || '');
                                setEditStdPhoto(student.photo || '');
                                setEditStdMobile(student.mobile || '');
                                setEditStdAddress(student.address || '');
                                setEditStdBatchTime(student.batchTime || '');
                                setEditStdClassDays(student.classDaysPerWeek || '');
                                setEditStdCourseDuration(student.courseDuration || '');
                                setEditStdStatus(student.status || 'active');
                              }}
                              className="px-2 py-1.5 border border-blue-500/25 bg-blue-500/10 text-blue-300 hover:bg-blue-500/20 rounded-lg text-[10px] font-bold transition-all flex items-center gap-0.5 cursor-pointer"
                              title={lang === 'bn' ? 'শিক্ষার্থীর তথ্য পরিবর্তন' : 'Edit Student Info'}
                            >
                              <Edit size={10} />
                              <span>{lang === 'bn' ? 'এডিট' : 'Edit'}</span>
                            </button>

                            {/* Manage Results Button */}
                            <button
                              onClick={() => setResultManagingStudent(student)}
                              className="px-2 py-1.5 border border-amber-500/25 bg-amber-500/10 text-amber-300 hover:bg-amber-500/20 rounded-lg text-[10px] font-bold transition-all flex items-center gap-0.5 cursor-pointer"
                              title={lang === 'bn' ? 'পরীক্ষার ফলাফল সাবমিট' : 'Submit Results'}
                            >
                              <FileText size={10} />
                              <span>{lang === 'bn' ? '+ ফলাফল' : '+ Result'}</span>
                            </button>

                            {/* Manage Certificates Button */}
                            <button
                              onClick={() => setCertManagingStudent(student)}
                              className="px-2 py-1.5 border border-purple-500/25 bg-purple-500/10 text-purple-300 hover:bg-purple-500/20 rounded-lg text-[10px] font-bold transition-all flex items-center gap-0.5 cursor-pointer"
                              title={lang === 'bn' ? 'সনদপত্র সাবমিট' : 'Submit Certificates'}
                            >
                              <Award size={10} />
                              <span>{lang === 'bn' ? '+ সনদ' : '+ Cert'}</span>
                            </button>

                            {/* Complete Course Shortcut Button for Active Students */}
                            {(!student.status || student.status === 'active') && (
                              <button
                                onClick={() => {
                                  setConfirmConfig({
                                    isOpen: true,
                                    title: lang === 'bn' ? '🎓 কোর্স সম্পন্ন নির্ধারণ' : '🎓 Mark Course Completed',
                                    message: lang === 'bn' 
                                      ? `আপনি কি '${student.nameBn || student.name}' এর কোর্স সফলভাবে সম্পন্ন ঘোষণা করতে চান? এই শিক্ষার্থীকে 'পুরাতন শিক্ষার্থী' ক্যাটাগরিতে স্থানান্তর করা হবে!` 
                                      : `Are you sure you want to declare course completion for '${student.nameEn || student.name}'? This student will be moved to the Old Students section.`,
                                    onConfirm: () => {
                                      const updatedStudent: Student = {
                                        ...student,
                                        status: 'completed'
                                      };
                                      onUpdateStudent(updatedStudent);
                                      setAlertConfig({
                                        isOpen: true,
                                        title: lang === 'bn' ? '🎉 কোর্স সম্পন্ন' : '🎉 Course Completed',
                                        message: lang === 'bn' 
                                          ? 'শিক্ষার্থীকে সফলভাবে পুরাতন শিক্ষার্থী ক্যাটাগরিতে পাঠানো হয়েছে!' 
                                          : 'Student transitioned successfully to Old Students list!',
                                      });
                                    }
                                  });
                                }}
                                className="px-2 py-1.5 border border-amber-500/20 bg-amber-500/5 text-amber-400 hover:bg-amber-500/20 rounded-lg text-[10px] font-bold transition-all flex items-center gap-0.5 cursor-pointer"
                                title={lang === 'bn' ? 'কোর্স সম্পন্ন করুন' : 'Mark Completed'}
                              >
                                <GraduationCap size={10} />
                                <span>{lang === 'bn' ? 'কোর্স সম্পন্ন' : 'Complete'}</span>
                              </button>
                            )}

                            {/* Present Button */}
                            <button
                              onClick={() => {
                                onUpdateStudentAttendance(student.id, selectedDate, 'present');
                              }}
                              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                                attendanceStatus === 'present'
                                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                                  : 'bg-[#000d0b]/80 border border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/10'
                              }`}
                            >
                              <Check size={12} />
                              <span>{lang === 'bn' ? 'উপস্থিত' : 'Present'}</span>
                            </button>

                            {/* Absent Button */}
                            <button
                              onClick={() => {
                                onUpdateStudentAttendance(student.id, selectedDate, 'absent');
                              }}
                              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                                attendanceStatus === 'absent'
                                  ? 'bg-red-500 text-slate-950 shadow-md shadow-red-500/20'
                                  : 'bg-[#000d0b]/80 border border-red-500/20 text-red-400 hover:bg-red-500/10'
                              }`}
                            >
                              <X size={12} />
                              <span>{lang === 'bn' ? 'অনুপস্থিত' : 'Absent'}</span>
                            </button>

                            {/* Print QR Code Student Admission Slip */}
                            <button
                              onClick={() => printStudentSlip(student)}
                              className="p-2 border border-amber-500/15 bg-amber-500/5 hover:bg-amber-500/20 text-amber-400 rounded-lg transition-colors cursor-pointer"
                              title={lang === 'bn' ? 'ভর্তি স্লিপ (QR কোডসহ)' : 'Print Verification Slip'}
                            >
                              <Printer size={12} />
                            </button>

                            {/* Delete Button */}
                            <button
                              onClick={() => {
                                setConfirmConfig({
                                  isOpen: true,
                                  title: lang === 'bn' ? '⚠️ শিক্ষার্থী মুছুন' : '⚠️ Delete Student',
                                  message: lang === 'bn' ? 'আপনি কি এই শিক্ষার্থীকে স্থায়ীভাবে মুছে ফেলতে চান?' : 'Are you sure you want to permanently delete this student?',
                                  onConfirm: () => {
                                    onDeleteStudent(student.id);
                                  }
                                });
                              }}
                              className="p-2 border border-red-500/15 bg-red-500/5 hover:bg-red-500/20 text-red-300 hover:text-red-400 rounded-lg transition-colors cursor-pointer"
                              title={lang === 'bn' ? 'শিক্ষার্থী মুছুন' : 'Delete Student'}
                            >
                              <Trash size={12} />
                            </button>
                          </div>
                        </motion.div>
                      );
                    });
                  })()}
                </div>
              </div>

              {/* EPSON Printed Attendance Result Sheet section */}
              <div className="flex flex-col gap-3">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-amber-400 font-mono uppercase tracking-wider">
                    {lang === 'bn' ? '🖨️ ইপ্সন থার্মাল হাজিরা স্লিপ শিট' : '🖨️ Epson Thermal Attendance Result Sheet'}
                  </span>
                  
                  {/* Action Print Buttons */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        const win = window.open('', '_blank');
                        if (win) {
                          win.document.write(`
                            <html>
                              <head>
                                <title>Attendance Result Slip</title>
                                <style>
                                  body { font-family: monospace; padding: 25px; background: #fff; color: #000; font-size: 14px; line-height: 1.4; }
                                  pre { white-space: pre-wrap; font-family: monospace; }
                                </style>
                              </head>
                              <body onload="window.print()">
                                <pre>${getEpsonResultSheet()}</pre>
                              </body>
                            </html>
                          `);
                          win.document.close();
                        }
                      }}
                      className="flex items-center gap-1 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-[#011411] rounded-lg text-xs font-bold cursor-pointer transition-all active:scale-95"
                    >
                      <Printer size={12} />
                      <span>{lang === 'bn' ? 'প্রিন্ট স্লিপ' : 'Print Slip'}</span>
                    </button>
                    
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(getEpsonResultSheet());
                        alert(lang === 'bn' ? '📋 তথ্য ক্লিপবোর্ডে কপি করা হয়েছে।' : '📋 Report copied to clipboard.');
                      }}
                      className="flex items-center gap-1 px-3 py-1.5 border border-emerald-500/20 bg-[#000d0b]/80 text-[#34d399] rounded-lg text-xs font-bold cursor-pointer transition-all hover:bg-emerald-500/10"
                    >
                      <Check size={12} />
                      <span>{lang === 'bn' ? 'কপি করুন' : 'Copy Text'}</span>
                    </button>
                  </div>
                </div>

                {/* Epson POS Receipt Mockup UI */}
                <div className="relative select-text bg-[#f5f4eb] text-[#1c1c1a] border-[#121212] border-2 p-5 sm:p-7 font-mono rounded-lg shadow-inner overflow-hidden leading-relaxed max-h-[290px] overflow-y-auto scrollbar-thin">
                  
                  {/* Fake continuous feed side holes of receipt paper roll */}
                  <div className="absolute left-1 top-0 bottom-0 flex flex-col justify-between py-2 pointer-events-none opacity-45">
                    {Array.from({ length: 12 }).map((_, i) => (
                      <span key={i} className="w-2.5 h-2.5 rounded-full bg-[#121212]/15 border border-[#121212]/20"></span>
                    ))}
                  </div>
                  <div className="absolute right-1 top-0 bottom-0 flex flex-col justify-between py-2 pointer-events-none opacity-45">
                    {Array.from({ length: 12 }).map((_, i) => (
                      <span key={i} className="w-2.5 h-2.5 rounded-full bg-[#121212]/15 border border-[#121212]/20"></span>
                    ))}
                  </div>

                  <pre className="text-xs tracking-tighter whitespace-pre whitespace-pre-wrap font-mono select-all ml-2 w-full overflow-x-auto text-[10px] sm:text-xs">
                    {getEpsonResultSheet()}
                  </pre>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'appDownload' && (
            <div className="flex flex-col gap-6 animate-in fade-in duration-200">
              {/* Tab Header Card */}
              <div className="bg-[#000d0b]/40 border border-emerald-500/15 rounded-2xl p-4 sm:p-5">
                <h4 className="text-sm font-bold text-amber-400 mb-1 flex items-center gap-2 font-sans">
                  <Download size={16} />
                  {lang === 'bn' ? '📱 অ্যাপ ডাউনলোড ও কিউআর কোড কনফিগারেশন' : '📱 App Download & QR Configuration Office'}
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {lang === 'bn' 
                    ? 'ইউজার প্যানেলে প্রদর্শিত অফিশিয়াল অ্যাপ ডাউনলোডের লিংক এবং কিউআর কোড/ছবিটি এখান থেকে নিয়ন্ত্রণ করুন।' 
                    : 'Manage the official application download hyper-link and scanable QR code or badge image displayed in the public student portal.'}
                </p>
              </div>

              {/* Settings Configuration Form */}
              <div className="bg-[#011e19]/30 border border-emerald-500/10 p-5 rounded-2xl flex flex-col gap-5">
                
                {/* Download URL Input */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                    {lang === 'bn' ? 'অ্যাপ ডাউনলোড লিংক' : 'Application Download Link'}
                  </label>
                  <input
                    type="url"
                    value={downloadUrlInput}
                    onChange={(e) => setDownloadUrlInput(e.target.value)}
                    placeholder={lang === 'bn' ? 'যেমন: https://play.google.com/store/apps/details?id=...' : 'e.g. https://play.google.com/store/apps/details?id=...'}
                    className="w-full bg-[#000d0b]/90 border border-emerald-500/15 focus:border-emerald-500/50 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-100 outline-none transition-all font-mono"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    {lang === 'bn'
                      ? 'মোবাইল ইউজারদের জন্য ডাউনলোড বাটনে এই লিংকটি সংযুক্ত হবে।'
                      : 'This address will be mapped to the action download button for mobile clients.'}
                  </span>
                </div>

                {/* QR Code / Badge Picture Upload */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                    {lang === 'bn' ? 'কিউআর কোড বা ডাউনলোড ব্যাজ ছবি' : 'QR Code or App Download Image'}
                  </label>
                  
                  <div className="flex flex-col sm:flex-row items-stretch gap-4">
                    {/* Upload drop zone */}
                    <div 
                      onDragEnter={(e) => handleDrag(e, setDragActiveBadge)}
                      onDragOver={(e) => handleDrag(e, setDragActiveBadge)}
                      onDragLeave={(e) => handleDrag(e, setDragActiveBadge)}
                      onDrop={async (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setDragActiveBadge(false);
                        const file = e.dataTransfer.files?.[0];
                        if (!file) return;
                        try {
                          setIsBadgeUploading(true);
                          const base64 = await compressImageToBase64(file);
                          setBadgeUrlInput(base64);
                        } catch (err) {
                          console.error("Failed to drag-drop badge image:", err);
                        } finally {
                          setIsBadgeUploading(false);
                        }
                      }}
                      className={`flex-1 min-h-[120px] rounded-xl border border-dashed flex flex-col items-center justify-center p-4 transition-all relative ${
                        dragActiveBadge 
                          ? 'border-amber-400 bg-amber-400/10 text-amber-200' 
                          : 'border-emerald-500/15 hover:border-emerald-500/40 bg-[#000d0b]/40 text-slate-400'
                      }`}
                    >
                      <input
                        type="file"
                        accept="image/*"
                        id="app-badge-file-upload"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          try {
                            setIsBadgeUploading(true);
                            const base64 = await compressImageToBase64(file);
                            setBadgeUrlInput(base64);
                          } catch (err) {
                            console.error("Failed to select badge image:", err);
                          } finally {
                            setIsBadgeUploading(false);
                          }
                        }}
                        className="hidden"
                      />
                      
                      <label htmlFor="app-badge-file-upload" className="cursor-pointer flex flex-col items-center justify-center gap-1.5 w-full h-full">
                        <ImageIcon size={22} className="text-amber-500/80" />
                        <span className="text-[11px] font-bold text-slate-300">
                          {isBadgeUploading ? (lang === 'bn' ? 'প্রসেসিং হচ্ছে...' : 'Processing image...') : (lang === 'bn' ? 'ছবি ক্লিক করুন অথবা ড্র্যাগ করুন' : 'Click to Upload or Drag and Drop')}
                        </span>
                        <span className="text-[9px] text-slate-500 font-sans">
                          {lang === 'bn' ? 'সপারিশকৃত: বর্গাকার কিউআর কোড বা পিএনজি ব্যাজ ছবি' : 'Recommended: Square QR Code graphic or PNG image'}
                        </span>
                      </label>
                    </div>

                    {/* Preview window */}
                    <div className="w-full sm:w-[150px] shrink-0 border border-emerald-500/15 bg-[#000d0b]/40 rounded-xl p-3 flex flex-col items-center justify-center text-center">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 font-mono">
                        {lang === 'bn' ? 'প্রিভিউ' : 'Live Preview'}
                      </span>
                      {badgeUrlInput ? (
                        <div className="relative group rounded-lg overflow-hidden border border-slate-700 bg-white p-1">
                          <img 
                            src={badgeUrlInput} 
                            alt="QR Badge preview" 
                            className="w-24 h-24 object-contain" 
                            referrerPolicy="no-referrer"
                          />
                          <button
                            type="button"
                            onClick={() => setBadgeUrlInput('')}
                            className="absolute inset-0 bg-black/80 flex items-center justify-center text-red-500 font-bold opacity-0 group-hover:opacity-100 transition-opacity text-xs cursor-pointer"
                          >
                            {lang === 'bn' ? 'রিমুভ' : 'Remove'}
                          </button>
                        </div>
                      ) : (
                        <div className="w-24 h-24 border border-dashed border-slate-800/80 rounded-lg flex items-center justify-center text-slate-600 italic text-[11px] bg-slate-950/20 font-sans">
                          {lang === 'bn' ? 'ছবি নেই' : 'No Image'}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Form Action Controls */}
                <div className="flex justify-end gap-3 pt-3 border-t border-emerald-500/10 mt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setDownloadUrlInput(appDownload?.downloadUrl || '');
                      setBadgeUrlInput(appDownload?.badgeUrl || '');
                    }}
                    className="px-4 py-2 border border-slate-700 text-slate-400 hover:text-white rounded-xl text-xs font-semibold cursor-pointer transition-colors hover:bg-slate-800/40"
                  >
                    {lang === 'bn' ? 'রিসেট' : 'Reset'}
                  </button>
                  <button
                    type="button"
                    disabled={isBadgeUploading}
                    onClick={() => {
                      if (onUpdateAppDownload) {
                        onUpdateAppDownload({
                          downloadUrl: downloadUrlInput.trim(),
                          badgeUrl: badgeUrlInput,
                        });
                        alert(lang === 'bn' ? 'সফলভাবে ডাউনলোড অপশন আপডেট করা হয়েছে!' : 'App download options updated successfully!');
                      }
                    }}
                    className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-300 hover:from-amber-400 hover:to-amber-200 text-[#011412] font-black rounded-xl text-xs sm:text-sm shadow-md transition-all active:scale-95 cursor-pointer disabled:opacity-50"
                  >
                    {lang === 'bn' ? 'পরিবর্তন সংরক্ষণ করুন' : 'Save General Changes'}
                  </button>
                </div>

              </div>
              
              {/* Note banner */}
              <div className="p-3 bg-amber-500/5 border border-amber-500/10 rounded-xl text-[11px] text-amber-500 leading-relaxed font-sans">
                {lang === 'bn'
                  ? '💡 এখানে আপনি যে কিউআর কোড বা অ্যাপ ডাউনলোড লিংকটি যুক্ত করবেন, তা শিক্ষার্থীরা তাদের পোর্টালে (Student Portal Modal) গেলেই দেখতে পাবেন এবং তা সহজে স্ক্যান করতে পারবেন।'
                  : '💡 The link and QR Code configure elements uploaded here will show up beautifully on the student search portal, optimized for scanning as well as mobile redirection.'}
              </div>

            </div>
          )}

          {activeTab === 'notice' && (
            <div className="flex flex-col gap-6 animate-in fade-in duration-200">
              {/* Tab Header Card */}
              <div className="bg-[#000d0b]/40 border border-emerald-500/15 rounded-2xl p-4 sm:p-5">
                <h4 className="text-sm font-bold text-amber-400 mb-1 flex items-center gap-2 font-sans">
                  <Megaphone size={16} />
                  {lang === 'bn' ? '📢 স্ক্রল নোটিশ ও ঘোষণা কনফিগারেশন' : '📢 Scroll Notice & Announcements'}
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {lang === 'bn' 
                    ? 'ইউজার প্যানেলে সবার উপরে যে চলমান ঘোষণা টেক্সট বারটি থাকে, তার লেখা এবং গতি এখান থেকে নিয়ন্ত্রণ করতে পারবেন।' 
                    : 'Configure the streaming announcement message and scrolling velocity shown at the top of the user dashboard screens.'}
                </p>
              </div>

              {/* Settings Configuration Form */}
              <div className="bg-[#011e19]/30 border border-emerald-500/10 p-5 rounded-2xl flex flex-col gap-5">
                
                {/* Switch Toggle Option */}
                <div className="flex items-center justify-between bg-[#000d0b]/40 rounded-xl p-3.5 border border-emerald-500/10 mb-2">
                  <div className="flex flex-col gap-0.5">
                    <span className="text-xs font-extrabold text-slate-300">
                      {lang === 'bn' ? 'স্ক্রল নোটিশ দেখান' : 'Show Scroll Notice'}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {lang === 'bn' ? 'ইউজার প্যানেল থেকে এর দৃশ্যমানতা নিয়ন্ত্রণ করুন' : 'Toggle public visibility on main dashboard view'}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setNoticeEnabled(!noticeEnabled)}
                    className={`w-12 h-6 flex items-center rounded-full p-0.5 transition-colors duration-200 cursor-pointer ${
                      noticeEnabled ? 'bg-amber-500' : 'bg-slate-700'
                    }`}
                  >
                    <div
                      className={`bg-slate-900 w-5 h-5 rounded-full shadow-md transform transition-transform duration-200 ${
                        noticeEnabled ? 'translate-x-6' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                {/* Text Bn Input */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                    {lang === 'bn' ? 'ঘোষণা টেক্সট (বাংলা)' : 'Announcement Text (Bangla)'}
                  </label>
                  <textarea
                    rows={2}
                    value={noticeTextBn}
                    onChange={(e) => setNoticeTextBn(e.target.value)}
                    placeholder="বাংলায় ঘোষণার বিবরণ লিখুন..."
                    className="w-full bg-[#000d0b]/90 border border-emerald-500/15 focus:border-emerald-500/50 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-100 outline-none transition-all font-sans leading-relaxed resize-none"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    {lang === 'bn'
                      ? 'অ্যাপের ভাষা যখন বাংলায় থাকবে তখন এই লেখাটি স্ক্রল করবে।'
                      : 'This message will stream banner-style when the active user platform language is Bangla.'}
                  </span>
                </div>

                {/* Text En Input */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-1.5 font-mono">
                    {lang === 'bn' ? 'ঘোষণা টেক্সট (English)' : 'Announcement Text (English)'}
                  </label>
                  <textarea
                    rows={2}
                    value={noticeTextEn}
                    onChange={(e) => setNoticeTextEn(e.target.value)}
                    placeholder="Enter the announcement in English..."
                    className="w-full bg-[#000d0b]/90 border border-emerald-500/15 focus:border-emerald-500/50 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-100 outline-none transition-all font-sans leading-relaxed resize-none"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    {lang === 'bn'
                      ? 'অ্যাপের ভাষা যখন ইংরেজিতে থাকবে তখন এই লেখাটি স্ক্রল করবে।'
                      : 'This message will stream banner-style when the active user platform language is English.'}
                  </span>
                </div>

                {/* Scroll Speed Input Bar */}
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 font-mono">
                      {lang === 'bn' ? 'স্ক্রল করার গতি' : 'Scrolling Speed'}
                    </label>
                    <span className="text-xs font-bold text-amber-400 font-mono">
                      {noticeSpeed} {lang === 'bn' ? 'গতি মাত্রা' : 'units'}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <input
                      type="range"
                      min={10}
                      max={38}
                      value={noticeSpeed}
                      onChange={(e) => setNoticeSpeed(Number(e.target.value))}
                      className="flex-1 accent-amber-500 cursor-pointer h-1.5 bg-[#000d0b] rounded-lg border border-emerald-500/10"
                    />
                    <div className="text-[10px] font-bold text-slate-400 border border-emerald-500/15 bg-[#000d0b] px-2.5 py-1 rounded font-mono">
                      {noticeSpeed > 28 ? (lang === 'bn' ? 'দ্রুত' : 'Fast') : noticeSpeed > 18 ? (lang === 'bn' ? 'মাঝারি' : 'Medium') : (lang === 'bn' ? 'ধীর' : 'Slow')}
                    </div>
                  </div>
                  
                  <span className="text-[10px] text-slate-500 mt-2 block">
                    {lang === 'bn'
                      ? 'স্ক্রল করার গতি বাড়াতে বা কমাতে স্লাইডারটি পরিবর্তন করুন।'
                      : 'Drag this velocity slider to tune how fast the marquee streams across screens.'}
                  </span>
                </div>

                {/* Form Action Controls */}
                <div className="flex justify-end gap-3 pt-3 border-t border-emerald-500/10 mt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setNoticeTextBn(notice?.textBn || '');
                      setNoticeTextEn(notice?.textEn || '');
                      setNoticeEnabled(notice?.enabled !== false);
                      setNoticeSpeed(notice?.speed || 30);
                    }}
                    className="px-4 py-2 border border-slate-700 text-slate-400 hover:text-white rounded-xl text-xs font-semibold cursor-pointer transition-colors hover:bg-slate-800/40"
                  >
                    {lang === 'bn' ? 'রিসেট' : 'Reset'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (onUpdateNotice) {
                        onUpdateNotice({
                          textBn: noticeTextBn.trim(),
                          textEn: noticeTextEn.trim(),
                          enabled: noticeEnabled,
                          speed: noticeSpeed,
                        });
                        alert(lang === 'bn' ? 'সফলভাবে নোটিশ আপডেট করা হয়েছে!' : 'Notice configuration saved successfully!');
                      }
                    }}
                    className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-300 hover:from-amber-400 hover:to-amber-200 text-[#011412] font-black rounded-xl text-xs sm:text-sm shadow-md transition-all active:scale-95 cursor-pointer"
                  >
                    {lang === 'bn' ? 'নোটিশ সংরক্ষণ করুন' : 'Save Notice Settings'}
                  </button>
                </div>

              </div>
              
              {/* Note banner */}
              <div className="p-3 bg-amber-500/5 border border-amber-500/10 rounded-xl text-[11px] text-amber-500 leading-relaxed font-sans">
                {lang === 'bn'
                  ? '💡 চলমান নোটিশটি সব পাতার ওপর দিয়ে সচলভাবে পরিভ্রমণ করবে। প্রয়োজনে এটি যেকোনো সময় বন্ধ করে দিতে পারবেন।'
                  : '💡 The scrolling marquee is visible on the topmost edge of client dashboards. You can pause or disable this feature at any time.'}
              </div>

              {/* ⚡ Live Broadcast Push Notification Form */}
              <div className="bg-[#000d0b]/40 border border-emerald-500/15 rounded-2xl p-4 sm:p-5 mt-2">
                <h4 className="text-sm font-bold text-amber-400 mb-1 flex items-center gap-2 font-sans">
                  <Megaphone size={16} className="text-red-400 animate-pulse" />
                  {lang === 'bn' ? '⚡ মোবাইল সরাসরি পুশ নোটিফিকেশন পাঠান' : '⚡ Broadcast Mobile Push Notification'}
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed mb-4">
                  {lang === 'bn' 
                    ? 'এখান থেকে যেকোনো নোটিশ বা ঘোষণা সরাসরি সকল ব্যবহারকারীর এবং শিক্ষার্থীদের মোবাইলে রিয়েল-টাইমে পুশ নোটিফিকেশন হিসেবে পাঠাতে পারবেন।' 
                    : 'Broadcast instant updates and special notices as push notifications directly to offline and online users\' mobile phones.'}
                </p>

                <form onSubmit={handleSendBroadcastSubmit} className="bg-[#011e19]/30 border border-emerald-500/10 p-5 rounded-xl flex flex-col gap-4 font-sans">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Title Bn */}
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-amber-500/80 mb-1.5 font-mono">
                        {lang === 'bn' ? 'নোটিফিকেশন টাইটেল (বাংলা)' : 'Notification Title (Bangla)'}
                      </label>
                      <input
                        type="text"
                        value={broadcastTitleBn}
                        onChange={(e) => setBroadcastTitleBn(e.target.value)}
                        placeholder="যেমন: নতুন পরীক্ষার রেজাল্ট প্রকাশিত হয়েছে"
                        className="w-full bg-[#000d0b]/95 border border-emerald-500/15 focus:border-red-500/50 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-100 outline-none transition-all"
                      />
                    </div>

                    {/* Title En */}
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-amber-500/80 mb-1.5 font-mono">
                        {lang === 'bn' ? 'নোটিফিকেশন টাইটেল (English - Optional)' : 'Notification Title (English - Optional)'}
                      </label>
                      <input
                        type="text"
                        value={broadcastTitleEn}
                        onChange={(e) => setBroadcastTitleEn(e.target.value)}
                        placeholder="e.g., New Exam Results Published"
                        className="w-full bg-[#000d0b]/95 border border-emerald-500/15 focus:border-red-500/50 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-100 outline-none transition-all"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Body Bn */}
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-amber-500/80 mb-1.5 font-mono">
                        {lang === 'bn' ? 'নোটিফিকেশন বিবরণ (বাংলা)' : 'Notification Message (Bangla)'}
                      </label>
                      <textarea
                        rows={3}
                        value={broadcastBodyBn}
                        onChange={(e) => setBroadcastBodyBn(e.target.value)}
                        placeholder="বিস্তারিত বার্তা বাংলায় লিখুন..."
                        className="w-full bg-[#000d0b]/95 border border-emerald-500/15 focus:border-red-500/50 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-100 outline-none transition-all resize-none font-sans"
                      />
                    </div>

                    {/* Body En */}
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-amber-500/80 mb-1.5 font-mono">
                        {lang === 'bn' ? 'নোটিফিকেশন বিবরণ (English - Optional)' : 'Notification Message (English - Optional)'}
                      </label>
                      <textarea
                        rows={3}
                        value={broadcastBodyEn}
                        onChange={(e) => setBroadcastBodyEn(e.target.value)}
                        placeholder="Write detailed notification message in English..."
                        className="w-full bg-[#000d0b]/95 border border-emerald-500/15 focus:border-red-500/50 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-100 outline-none transition-all resize-none font-sans"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      type="submit"
                      disabled={isSendingBroadcast}
                      className="px-6 py-2.5 bg-gradient-to-r from-red-500 via-orange-500 to-amber-500 hover:from-red-400 hover:to-amber-400 disabled:opacity-50 text-slate-950 font-black rounded-xl text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-orange-500/10 cursor-pointer active:scale-95 transition-all"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="animate-pulse">
                        <line x1="22" y1="2" x2="11" y2="13" />
                        <polygon points="22 2 15 22 11 13 2 9 22 2" />
                      </svg>
                      {isSendingBroadcast 
                        ? (lang === 'bn' ? 'পাঠানো হচ্ছে...' : 'Sending...') 
                        : (lang === 'bn' ? 'নোটিফিকেশন ব্রডকাস্ট করুন' : 'Broadcast Now')}
                    </button>
                  </div>
                </form>
              </div>

              {/* 📬 Sent Notifications History List (Admin only) */}
              <div className="bg-[#000d0b]/40 border border-emerald-500/15 rounded-2xl p-4 sm:p-5 mt-4">
                <h4 className="text-sm font-bold text-amber-400 mb-2 flex items-center gap-2 font-sans">
                  <Bell size={16} className="text-amber-500" />
                  {lang === 'bn' ? '📬 পূর্বের প্রেরিত নোটিফিকেশন সমূহ' : '📬 Previously Broadcasted Updates'}
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed mb-4 font-sans">
                  {lang === 'bn'
                    ? 'এখান থেকে পূর্বে পাঠানো সকল নোটিফিকেশন দেখতে পারবেন এবং চাইলে অপ্রয়োজনীয় নোটিফিকেশন মুছে ফেলতে পারবেন।'
                    : 'View all previously broadcasted notifications and remove any obsolete alerts.'}
                </p>

                <div className="flex flex-col gap-3 max-h-[300px] overflow-y-auto pr-1 scrollbar-thin">
                  {notificationsList.length === 0 ? (
                    <div className="text-center py-8 text-slate-500 text-xs font-semibold font-sans">
                      {lang === 'bn' ? 'কোনো পূর্বের নোটিফিকেশন পাওয়া যায়নি।' : 'No previous notifications found.'}
                    </div>
                  ) : (
                    notificationsList.map((notif) => (
                      <div
                        key={notif.id}
                        className="p-3 rounded-xl bg-[#011a15] border border-emerald-500/10 hover:border-emerald-500/20 flex justify-between items-start gap-4 transition-all"
                      >
                        <div className="flex-1 font-sans">
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <span className="text-xs font-bold text-amber-300">
                              {lang === 'bn' ? notif.titleBn : notif.titleEn}
                            </span>
                            <span className="text-[10px] text-slate-500">
                              {new Date(notif.createdAt).toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US')}
                            </span>
                          </div>
                          <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line">
                            {lang === 'bn' ? notif.bodyBn : notif.bodyEn}
                          </p>
                        </div>
                        
                        {onDeleteNotification && (
                          <button
                            type="button"
                            onClick={() => {
                              if (confirm(lang === 'bn' ? 'আপনি কি নিশ্চিতভাবে এই নোটিফিকেশনটি ডিলিট করতে চান?' : 'Are you sure you want to delete this notification?')) {
                                onDeleteNotification(notif.id);
                              }
                            }}
                            className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 hover:text-rose-300 transition-colors shrink-0 cursor-pointer"
                            title={lang === 'bn' ? 'মুছে ফেলুন' : 'Delete'}
                          >
                            <Trash size={13} />
                          </button>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>

            </div>
          )}

          {activeTab === 'prayerTimes' && (
            <div className="flex flex-col gap-6 animate-in fade-in duration-200">
              {/* Tab Header Card */}
              <div className="bg-[#000d0b]/40 border border-emerald-500/15 rounded-2xl p-4 sm:p-5">
                <h4 className="text-sm font-bold text-amber-400 mb-1 flex items-center gap-2 font-sans">
                  <Clock size={16} />
                  {lang === 'bn' ? '🕌 সালাতের সময়সূচী কনফিগারেশন' : '🕌 Prayer Times Configuration'}
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {lang === 'bn'
                    ? 'ইউজার প্যানেলে সালাত ও নামাজের সময়সূচী প্রদর্শন করার সার্বিক সেটিংস এখান থেকে নিয়ন্ত্রণ ও পরিবর্তন করতে পারবেন।'
                    : 'Manage the visibility, automatic retrieval, or exact custom schedule settings of the daily prayer times widget.'}
                </p>
              </div>

              {/* Settings Configuration Form */}
              <form onSubmit={handleSavePrayerTimesConfig} className="bg-[#011e19]/30 border border-emerald-500/10 p-5 rounded-2xl flex flex-col gap-5">
                
                {/* Switch Toggle: Show Widget */}
                <div className="flex items-center justify-between bg-[#000d0b]/40 rounded-xl p-3.5 border border-emerald-500/10 mb-2">
                  <div className="flex flex-col gap-0.5 whitespace-normal pr-3">
                    <span className="text-xs font-extrabold text-slate-300">
                      {lang === 'bn' ? 'নামাজের সময়সূচী দেখান' : 'Show Prayer Times Widget'}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {lang === 'bn' ? 'ইউজার প্যানেলে নামাজের সময়সূচী উইজেটের দৃশ্যমানতা নিয়ন্ত্রণ করুন' : 'Display or hide the prayer tracker entirely on the main dashboard'}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setPtShowWidget(!ptShowWidget)}
                    className={`w-12 h-6 flex items-center rounded-full p-0.5 transition-colors duration-200 cursor-pointer shrink-0 ${
                      ptShowWidget ? 'bg-amber-500' : 'bg-slate-700'
                    }`}
                  >
                    <div
                      className={`bg-slate-900 w-5 h-5 rounded-full shadow-md transform transition-transform duration-200 ${
                        ptShowWidget ? 'translate-x-6' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                {/* Selection Mode: Automatic vs Manual */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-amber-500/85 mb-2 font-mono">
                    {lang === 'bn' ? 'সময় নির্ধারণের ধরন' : 'Time Retrieval Source'}
                  </label>
                  <div className="grid grid-cols-2 gap-3 p-1.5 bg-[#000d0b]/55 border border-emerald-500/10 rounded-xl">
                    <button
                      type="button"
                      onClick={() => setPtMode('auto')}
                      className={`py-2 px-3 rounded-lg text-xs font-black transition-all cursor-pointer ${
                        ptMode === 'auto'
                          ? 'bg-gradient-to-r from-amber-500 to-amber-300 text-[#011412] font-black'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-[#01231d]/20'
                      }`}
                    >
                      🔄 {lang === 'bn' ? 'অটোমেটিক (API)' : 'Automatic (API)'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setPtMode('manual')}
                      className={`py-2 px-3 rounded-lg text-xs font-black transition-all cursor-pointer ${
                        ptMode === 'manual'
                          ? 'bg-gradient-to-r from-amber-500 to-amber-300 text-[#011412] font-black'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-[#01231d]/20'
                      }`}
                    >
                      ✍️ {lang === 'bn' ? 'ম্যানুয়াল (অ্যাডমিন)' : 'Manual (Custom)'}
                    </button>
                  </div>
                  <span className="text-[10px] text-slate-500 mt-2 block">
                    {lang === 'bn'
                      ? 'অটোমেটিক মোড ইউজারদের আইপি/জিপিএস শহরের ভিত্তিতে সময় রিট্রিভ করে। ম্যানুয়াল সিলেক্ট করলে নিচে বসানো সময়গুলো লোড হবে।'
                      : 'Automatic retrieves live times from Aladhan API. Manual locked forces exact times typed below.'}
                  </span>
                </div>

                {/* Manual Timings Inputs - only active in Manual Mode */}
                {ptMode === 'manual' && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 bg-[#000d0b]/40 border border-emerald-500/10 p-4 rounded-xl animate-in slide-in-from-top-1 duration-150">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-400 mb-1 font-sans">
                        🌅 {lang === 'bn' ? 'ফজর (Fajr)' : 'Fajr'}
                      </label>
                      <input
                        type="text"
                        value={ptFajr}
                        onChange={(e) => setPtFajr(e.target.value)}
                        placeholder="HH:MM"
                        className="w-full bg-[#000d0b] border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 outline-none transition-all font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-400 mb-1 font-sans">
                        ☀️ {lang === 'bn' ? 'সূর্যোদয় (Sunrise)' : 'Sunrise'}
                      </label>
                      <input
                        type="text"
                        value={ptSunrise}
                        onChange={(e) => setPtSunrise(e.target.value)}
                        placeholder="HH:MM"
                        className="w-full bg-[#000d0b] border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 outline-none transition-all font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-400 mb-1 font-sans">
                        ☀️ {lang === 'bn' ? 'যোহর (Dhuhr)' : 'Dhuhr'}
                      </label>
                      <input
                        type="text"
                        value={ptDhuhr}
                        onChange={(e) => setPtDhuhr(e.target.value)}
                        placeholder="HH:MM"
                        className="w-full bg-[#000d0b] border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 outline-none transition-all font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-400 mb-1 font-sans">
                        🌇 {lang === 'bn' ? 'আসর (Asr)' : 'Asr'}
                      </label>
                      <input
                        type="text"
                        value={ptAsr}
                        onChange={(e) => setPtAsr(e.target.value)}
                        placeholder="HH:MM"
                        className="w-full bg-[#000d0b] border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 outline-none transition-all font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-400 mb-1 font-sans">
                        🌇 {lang === 'bn' ? 'মাগরিব (Maghrib)' : 'Maghrib'}
                      </label>
                      <input
                        type="text"
                        value={ptMaghrib}
                        onChange={(e) => setPtMaghrib(e.target.value)}
                        placeholder="HH:MM"
                        className="w-full bg-[#000d0b] border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 outline-none transition-all font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-400 mb-1 font-sans">
                        🌃 {lang === 'bn' ? 'এশা (Isha)' : 'Isha'}
                      </label>
                      <input
                        type="text"
                        value={ptIsha}
                        onChange={(e) => setPtIsha(e.target.value)}
                        placeholder="HH:MM"
                        className="w-full bg-[#000d0b] border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 outline-none transition-all font-mono"
                      />
                    </div>
                    <span className="col-span-full text-[10px] text-slate-500 mt-1 font-sans">
                      {lang === 'bn'
                        ? '🚫 অনুগ্রহ করে সময়গুলো ২৪-ঘণ্টা ফরমেটে (যেমন: 18:45) লিখুন।'
                        : '🚫 Please type custom times in 24-hour format (e.g., 18:45 for 6:45 PM).'}
                    </span>
                  </div>
                )}

                {/* Form Action Controls */}
                <div className="flex justify-end gap-3 pt-3 border-t border-emerald-500/10 mt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setPtShowWidget(prayerTimesConfig?.showWidget !== false);
                      setPtMode(prayerTimesConfig?.mode || 'auto');
                      if (prayerTimesConfig?.manualTimings) {
                        setPtFajr(prayerTimesConfig.manualTimings.Fajr || '04:15');
                        setPtSunrise(prayerTimesConfig.manualTimings.Sunrise || '05:35');
                        setPtDhuhr(prayerTimesConfig.manualTimings.Dhuhr || '12:15');
                        setPtAsr(prayerTimesConfig.manualTimings.Asr || '14:45');
                        setPtMaghrib(prayerTimesConfig.manualTimings.Maghrib || '18:45');
                        setPtIsha(prayerTimesConfig.manualTimings.Isha || '20:00');
                      }
                    }}
                    className="px-4 py-2 border border-slate-700 text-slate-400 hover:text-white rounded-xl text-xs font-semibold cursor-pointer transition-colors hover:bg-slate-800/40"
                  >
                    {lang === 'bn' ? 'রিসেট' : 'Reset'}
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-300 hover:from-amber-400 hover:to-amber-200 text-[#011412] font-black rounded-xl text-xs sm:text-sm shadow-md transition-all active:scale-95 cursor-pointer"
                  >
                    {lang === 'bn' ? 'কনফিগারেশন সংরক্ষণ করুন' : 'Save Configuration'}
                  </button>
                </div>

              </form>
            </div>
          )}

          {activeTab === 'statusBar' && (
            <div className="flex flex-col gap-6 animate-in fade-in duration-200">
              {/* Tab Header Description */}
              <div className="bg-[#000d0b]/40 border border-emerald-500/15 rounded-2xl p-4 sm:p-5">
                <h4 className="text-sm font-bold text-amber-400 mb-1 flex items-center gap-2 font-sans">
                  <ImageIcon size={16} />
                  {lang === 'bn' ? '🖼️ স্লাইড স্ট্যাটাস বার সেটিংস' : '🖼️ Slide Status Bar Settings'}
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {lang === 'bn'
                    ? 'ইউজার প্যানেলে সার্চবারের নিচে একটি সুন্দর রোটেটিং স্ট্যাটাস বার প্রদর্শন করুন। এখান থেকে আপনি স্ট্যাটাস বারটি চালু/বন্ধ করতে পারেন এবং নতুন নোটিশ স্লাইড বা ছবি আপলোড করতে পারবেন।'
                    : 'Display an elegant sliding photo update board directly below the search bar. Easily toggle visibility, add captions, and upload new status images.'}
                </p>
              </div>

              {/* Toggle Enable State */}
              <div className="flex items-center justify-between bg-[#001c18]/80 rounded-2xl p-4 border border-emerald-500/20">
                <div className="flex flex-col gap-0.5 whitespace-normal pr-3 text-left">
                  <span className="text-xs font-extrabold text-slate-200">
                    {lang === 'bn' ? 'স্ট্যাটাস বার অন বা অফ রাখুন' : 'Slide Status Bar Visibility'}
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {lang === 'bn' ? 'স্ট্যাটাস বারটি ইউজার প্যানেলে সরাসরি চালু বা বন্ধ করে দিন' : 'Instantly show or hide the sliding image updates carousel'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => handleSaveStatusBarStatus(!sbEnabled)}
                  className={`w-12 h-6 flex items-center rounded-full p-0.5 transition-colors duration-200 cursor-pointer shrink-0 ${
                    sbEnabled ? 'bg-amber-500' : 'bg-slate-705 bg-slate-700'
                  }`}
                >
                  <div
                    className={`bg-slate-900 w-5 h-5 rounded-full shadow-md transform transition-transform duration-200 ${
                      sbEnabled ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Slide Add/Edit Form */}
              <form onSubmit={handleAddOrEditSlide} className="bg-[#011e19]/30 border border-emerald-500/10 p-5 rounded-2xl flex flex-col gap-4 text-left">
                <h5 className="text-xs font-extrabold tracking-wide text-amber-400 uppercase font-sans">
                  {editingSlideId 
                    ? (lang === 'bn' ? '📝 স্লাইড ক্যাপশন ও ছবি পরিবর্তন' : '📝 Modify Status Slide') 
                    : (lang === 'bn' ? '➕ নতুন আপডেট স্লাইড যোগ করুন' : '➕ Upload New Status Slide')}
                </h5>

                {/* Drag-and-drop Image Upload Zone or Direct URL Paste */}
                <div className="flex flex-col gap-3">
                  <label className="block text-xs font-semibold text-slate-300 font-sans">
                    {lang === 'bn' ? 'আপডেট ইমেজ (ফাইলের সাইজ অবশ্যই ২ মেগাবাইটের কম হতে হবে)' : 'Update Slide Image (File must be < 2MB)'}
                  </label>

                  <div
                    onDragEnter={(e) => { e.preventDefault(); setDragActiveSlide(true); }}
                    onDragOver={(e) => { e.preventDefault(); setDragActiveSlide(true); }}
                    onDragLeave={(e) => { e.preventDefault(); setDragActiveSlide(false); }}
                    onDrop={handleSlideDrop}
                    className={`border-2 border-dashed rounded-xl p-6 text-center transition-all relative flex flex-col items-center justify-center cursor-pointer ${
                      dragActiveSlide 
                        ? 'border-amber-400 bg-amber-500/5' 
                        : 'border-emerald-500/15 hover:border-emerald-555/35 bg-[#000d0b]/40'
                    }`}
                  >
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleSlideFileChange}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    />
                    <div className="flex flex-col items-center justify-center gap-2">
                      <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400">
                        {isSlideUploading ? (
                          <span className="w-5 h-5 rounded-full border-2 border-amber-400 border-t-transparent animate-spin" />
                        ) : (
                          <Upload size={18} />
                        )}
                      </div>
                      <p className="text-xs font-bold text-slate-300">
                        {lang === 'bn' 
                          ? 'মাউস দিয়ে ছবি টেনে এনে এখানে ছাড়ুন অথবা ক্লিক করে আপলোড করুন' 
                          : 'Drag & drop image file here, or click to browse'}
                      </p>
                      <p className="text-[10px] text-slate-500 font-mono">
                        PNG, JPG, JPEG, WEBP files
                      </p>
                    </div>
                  </div>

                  {/* Or Manual enter url */}
                  <div className="flex flex-col gap-1 mt-1">
                    <span className="text-[10px] text-slate-400 uppercase tracking-widest text-center block font-mono">
                      - {lang === 'bn' ? 'অথবা ওয়েব ইমেজ লিঙ্ক প্রদান করুন' : 'OR PASTE DIRECT WEB IMAGE URL'} -
                    </span>
                    <input
                      type="text"
                      placeholder="https://example.com/slide-banner.jpg"
                      value={newSlideUrl}
                      onChange={(e) => setNewSlideUrl(e.target.value)}
                      className="w-full bg-[#000d0b] border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-3 py-2 text-xs text-slate-100 outline-none transition-all font-mono"
                    />
                  </div>
                </div>

                {/* Captions inputs */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-slate-400">
                      {lang === 'bn' ? 'ক্যাপশন (বাংলা)' : 'Caption (Bengali)'}
                    </label>
                    <textarea
                      rows={2}
                      placeholder={lang === 'bn' ? 'গোপন মেসেজ বা টাইটেল বাংলায়...' : 'Type caption in Bengali...'}
                      value={newSlideBn}
                      onChange={(e) => setNewSlideBn(e.target.value)}
                      className="w-full bg-[#000d0b] border border-emerald-500/15 focus:border-amber-500/50 rounded-lg p-2.5 text-xs text-slate-100 outline-none transition-all"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-slate-400">
                      {lang === 'bn' ? 'ক্যাপশন (ইংরেজী)' : 'Caption (English) - Optional'}
                    </label>
                    <textarea
                      rows={2}
                      placeholder={lang === 'bn' ? 'ক্যাপশন দিন ইংরেজিতে...' : 'Type caption in English...'}
                      value={newSlideEn}
                      onChange={(e) => setNewSlideEn(e.target.value)}
                      className="w-full bg-[#000d0b] border border-emerald-500/15 focus:border-amber-500/50 rounded-lg p-2.5 text-xs text-slate-100 outline-none transition-all"
                    />
                  </div>
                </div>

                {/* Action Submit */}
                <div className="flex justify-end gap-2.5 mt-2">
                  {editingSlideId && (
                    <button
                      type="button"
                      onClick={handleCancelSlideEdit}
                      className="px-4 py-2 border border-slate-700 text-slate-400 hover:text-white rounded-xl text-xs font-semibold cursor-pointer transition-colors hover:bg-slate-800/40"
                    >
                      {lang === 'bn' ? 'বাতিল' : 'Cancel'}
                    </button>
                  )}
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-300 hover:from-amber-400 hover:to-amber-200 text-[#011412] font-black rounded-xl text-xs sm:text-sm shadow-md transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
                  >
                    {editingSlideId ? <Check size={14} /> : <Plus size={14} />}
                    <span>
                      {editingSlideId 
                        ? (lang === 'bn' ? 'স্লাইড আপডেট করুন' : 'Update Slide') 
                        : (lang === 'bn' ? 'যোগ করুন' : 'Add Slide')}
                    </span>
                  </button>
                </div>
              </form>

              {/* Slider image previews scroll row */}
              <div className="flex flex-col gap-3 text-left">
                <h5 className="text-xs font-black text-slate-300 font-sans uppercase">
                  {lang === 'bn' ? '📊 বিদ্যমান আপডেট স্লাইডসমূহ' : '📊 Existing Sliders List'}
                </h5>

                {sbSlides.length === 0 ? (
                  <div className="p-8 text-center rounded-2xl border border-emerald-500/5 bg-[#000d0b]/20 text-slate-500 italic text-xs">
                    {lang === 'bn' ? 'কোনো আপডেট স্লাইড যোগ করা নেই।' : 'No sliding image notifications have been configured.'}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    {sbSlides.map((slide) => {
                      const finalCaption = lang === 'bn' 
                        ? slide.captionBn || slide.captionEn || '' 
                        : slide.captionEn || slide.captionBn || '';
                      
                      return (
                        <div key={slide.id} className="bg-[#000d0b]/40 border border-emerald-500/10 rounded-2xl overflow-hidden p-3 flex gap-3 items-start relative hover:border-emerald-500/15 transition-all">
                          {/* Left thumbnail preview */}
                          <img
                            src={slide.imageUrl}
                            alt="thumb"
                            className="w-16 h-16 object-cover rounded-lg shrink-0 border border-emerald-500/10"
                            referrerPolicy="no-referrer"
                          />

                          {/* Info caption */}
                          <div className="flex-1 min-w-0 pr-8">
                            <p className="text-[11px] text-slate-300 font-bold leading-snug line-clamp-2">
                              {finalCaption || (lang === 'bn' ? '(কোনো ক্যাপশন নেই)' : '(No caption provided)')}
                            </p>
                            <p className="text-[9px] text-slate-500 font-mono mt-1 select-all h-4 overflow-hidden text-ellipsis whitespace-nowrap">
                              {slide.imageUrl}
                            </p>
                          </div>

                          {/* Upper action control elements */}
                          <div className="absolute right-2.5 top-2.5 flex items-center gap-1.5 bg-[#000c0a]/80 backdrop-blur-xs p-1 rounded-lg border border-slate-800">
                            <button
                              onClick={() => handleEditSlideSelect(slide)}
                              type="button"
                              className="w-6 h-6 rounded-md hover:bg-slate-800 text-slate-400 hover:text-amber-400 flex items-center justify-center transition-colors cursor-pointer"
                              title={lang === 'bn' ? 'সম্পাদনা করুন' : 'Edit Slide'}
                            >
                              <Edit size={12} />
                            </button>
                            <button
                              onClick={() => handleDeleteSlide(slide.id)}
                              type="button"
                              className="w-6 h-6 rounded-md hover:bg-red-500/10 text-slate-400 hover:text-red-400 flex items-center justify-center transition-colors cursor-pointer"
                              title={lang === 'bn' ? 'মুছে ফেলুন' : 'Delete Slide'}
                            >
                              <Trash size={12} />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          </div> {/* Closes Dynamic Panel Scroll Body */}
        </div> {/* Closes Outer content area Row */}

      </div> {/* Closes Max-W-6xl container */}

      {/* 📊 Manage Student Results Sub-Modal Overlay */}
      {resultManagingStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in zoom-in-95 duration-200">
          <div className="w-full max-w-lg bg-gradient-to-b from-[#012d25] to-[#011411] border border-amber-500/25 p-6 rounded-3xl shadow-2xl relative flex flex-col max-h-[85vh]">
            <button
              onClick={() => setResultManagingStudent(null)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center bg-[#011e19] text-slate-400 hover:text-amber-400 transition-colors cursor-pointer"
            >
              <X size={15} />
            </button>

            <div className="mb-4">
              <h3 className="text-base font-black text-amber-400 flex items-center gap-2">
                <FileText size={18} />
                {lang === 'bn' ? `ফলাফল সাবমিট ও ব্যবস্থাপনা` : `Add & Manage Exam Results`}
              </h3>
              <p className="text-xs text-slate-400 mt-1 font-sans">
                {lang === 'bn' 
                  ? `শিক্ষার্থী: ${resultManagingStudent.nameBn || resultManagingStudent.name} (ID: ${resultManagingStudent.id})` 
                  : `Student: ${resultManagingStudent.nameEn || resultManagingStudent.name} (ID: ${resultManagingStudent.id})`}
              </p>
            </div>

            {/* Add Result Form */}
            <form onSubmit={handleAddResultSubmit} className="bg-[#000d0b]/40 border border-emerald-500/10 p-3.5 rounded-xl flex flex-col gap-3 font-sans">
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest font-mono">
                {lang === 'bn' ? '📝 পরীক্ষার নতুন ফলাফল যুক্তকরণ' : '📝 Submit New Result Card'}
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {/* Exam Name */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">
                    {lang === 'bn' ? 'পরীক্ষা/কোর্সের নাম *' : 'Exam/Course Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={newExamName}
                    onChange={(e) => setNewExamName(e.target.value)}
                    placeholder={lang === 'bn' ? 'যেমন: নূরানী কায়দা পরীক্ষা' : 'e.g. Quran Hifz Exam'}
                    className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 outline-none"
                  />
                </div>

                {/* Marks */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">
                    {lang === 'bn' ? 'প্রাপ্ত নম্বর *' : 'Mark Achieved *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={newExamMarks}
                    onChange={(e) => setNewExamMarks(e.target.value)}
                    placeholder="e.g. 85 / Mumtaz"
                    className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 outline-none"
                  />
                </div>

                {/* Grade */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">
                    {lang === 'bn' ? 'গ্রেড/মন্তব্য *' : 'Grade/Remarks *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={newExamGrade}
                    onChange={(e) => setNewExamGrade(e.target.value)}
                    placeholder="e.g. A+ / Mumtaz"
                    className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 outline-none"
                  />
                </div>

                {/* Date */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">
                    {lang === 'bn' ? 'তারিখ' : 'Publish Date'}
                  </label>
                  <input
                    type="date"
                    value={newExamDate}
                    onChange={(e) => setNewExamDate(e.target.value)}
                    className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 outline-none select-text"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-1.5 rounded-lg text-xs mt-1 cursor-pointer transition-colors"
              >
                {lang === 'bn' ? 'ফলাফল সাবমিট করুন' : 'Submit Result Card'}
              </button>
            </form>

            {/* List of results */}
            <div className="mt-4 flex-1 overflow-y-auto max-h-[220px] divide-y divide-emerald-950/40">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                📋 {lang === 'bn' ? 'পূর্ববর্তী পরীক্ষার রেজাল্ট তালিকা' : 'Registered Grade Sheets'}
              </span>

              {(!resultManagingStudent.results || resultManagingStudent.results.length === 0) ? (
                <div className="py-6 text-center text-xs text-slate-500 font-sans">
                  {lang === 'bn' ? 'এখনো কোনো ফলাফল যুক্ত করা হয়নি।' : 'No grade charts uploaded yet for this student.'}
                </div>
              ) : (
                <div className="flex flex-col gap-1.5 mt-2">
                  {resultManagingStudent.results.map((res) => (
                    <div key={res.id} className="p-2.5 bg-[#000d0b]/60 border border-emerald-500/10 rounded-lg flex items-center justify-between text-xs font-sans">
                      <div>
                        <div className="font-bold text-slate-200">{res.examName}</div>
                        <div className="text-[10px] text-slate-500 mt-0.5">Date: {res.date} | Marks: {res.marks}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-amber-400 px-2 py-0.5 bg-amber-500/10 border border-amber-500/15 rounded text-xs font-mono">
                          {res.grade}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleDeleteResult(res.id)}
                          className="p-1 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded cursor-pointer"
                        >
                          <Trash size={12} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer Close */}
            <div className="border-t border-emerald-500/15 pt-3 mt-4 text-right">
              <button
                onClick={() => setResultManagingStudent(null)}
                className="px-4 py-1.5 bg-[#011e19] hover:bg-[#002d24] text-slate-300 hover:text-white rounded-lg text-xs font-bold cursor-pointer"
              >
                {lang === 'bn' ? 'সম্পন্ন' : 'Done'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 📜 Manage Student Certificates Sub-Modal Overlay */}
      {certManagingStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in zoom-in-95 duration-200">
          <div className="w-full max-w-lg bg-gradient-to-b from-[#012d25] to-[#011411] border border-purple-500/25 p-6 rounded-3xl shadow-2xl relative flex flex-col max-h-[85vh]">
            <button
              onClick={() => setCertManagingStudent(null)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center bg-[#011e19] text-slate-400 hover:text-purple-400 transition-colors cursor-pointer"
            >
              <X size={15} />
            </button>

            <div className="mb-4">
              <h3 className="text-base font-black text-purple-400 flex items-center gap-2">
                <Award size={18} />
                {lang === 'bn' ? `সনদপত্র ও সার্টিফিকেট ব্যবস্থাপনা` : `Add & Manage Certificates`}
              </h3>
              <p className="text-xs text-slate-400 mt-1 font-sans">
                {lang === 'bn' 
                  ? `শিক্ষার্থী: ${certManagingStudent.nameBn || certManagingStudent.name} (ID: ${certManagingStudent.id})` 
                  : `Student: ${certManagingStudent.nameEn || certManagingStudent.name} (ID: ${certManagingStudent.id})`}
              </p>
            </div>

            {/* Add Certificate Form */}
            <form onSubmit={handleAddCertSubmit} className="bg-[#000d0b]/40 border border-purple-500/10 p-3.5 rounded-xl flex flex-col gap-3 font-sans">
              <span className="text-[10px] font-bold text-purple-400 uppercase tracking-widest font-mono">
                {lang === 'bn' ? '📝 পরীক্ষার নতুন সনদপত্র ইস্যু করুন' : '📝 Authorize New Certificate'}
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {/* Cert title */}
                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">
                    {lang === 'bn' ? 'সনদপত্রের নাম/শিরোনাম (বাংলা) *' : 'Certificate Title/Accolade (Bengali) *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={newCertTitle}
                    onChange={(e) => setNewCertTitle(e.target.value)}
                    placeholder={lang === 'bn' ? 'যেমন: হিফজুল কুরআন অ্যাওয়ার্ড সনদ' : 'e.g. Heazul Quran Award Certificate'}
                    className="w-full bg-[#000d0b]/80 border border-purple-500/15 focus:border-purple-500/50 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 outline-none"
                  />
                </div>

                {/* Cert title En */}
                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">
                    {lang === 'bn' ? 'সনদপত্রের নাম/শিরোনাম (ইংরেজি - ঐচ্ছিক)' : 'Certificate Title/Accolade (English - Optional)'}
                  </label>
                  <input
                    type="text"
                    value={newCertTitleEn}
                    onChange={(e) => setNewCertTitleEn(e.target.value)}
                    placeholder="e.g. Complete Quran Recitation Award"
                    className="w-full bg-[#000d0b]/80 border border-purple-500/15 focus:border-purple-500/50 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 outline-none"
                  />
                </div>

                {/* Details */}
                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">
                    {lang === 'bn' ? 'সার্টিফিকেট বিবরণ (বাংলা - ঐচ্ছিক)' : 'Certificate Details (Bengali - Optional)'}
                  </label>
                  <textarea
                    value={newCertDetails}
                    onChange={(e) => setNewCertDetails(e.target.value)}
                    placeholder="সফলতার সাথে পাঠ্য সম্পন্ন করার স্বীকৃতিস্বরূপ..."
                    rows={2}
                    className="w-full bg-[#000d0b]/80 border border-purple-500/15 focus:border-purple-500/50 rounded-lg p-2 text-xs text-slate-100 outline-none resize-none"
                  />
                </div>

                {/* Details En */}
                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">
                    {lang === 'bn' ? 'সার্টিফিকেট বিবরণ (ইংরেজি - ঐচ্ছিক)' : 'Certificate Details (English - Optional)'}
                  </label>
                  <textarea
                    value={newCertDetailsEn}
                    onChange={(e) => setNewCertDetailsEn(e.target.value)}
                    placeholder="In recognition of outstanding performance during the course..."
                    rows={2}
                    className="w-full bg-[#000d0b]/80 border border-purple-500/15 focus:border-purple-500/50 rounded-lg p-2 text-xs text-slate-100 outline-none resize-none"
                  />
                </div>

                {/* Date */}
                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">
                    {lang === 'bn' ? 'ইস্যু করার তারিখ' : 'Issue Date'}
                  </label>
                  <input
                    type="date"
                    value={newCertDate}
                    onChange={(e) => setNewCertDate(e.target.value)}
                    className="w-full bg-[#000d0b]/80 border border-purple-500/15 focus:border-purple-500/50 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 outline-none select-text"
                  />
                </div>

                {/* Watermark Logo Upload */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">
                    {lang === 'bn' ? 'লোগো জলছাপ ছবি (ঐচ্ছিক)' : 'Logo Watermark Image (Optional)'}
                  </label>
                  <div className="flex items-center gap-2">
                    <label className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 bg-[#000d0b]/90 border border-purple-500/15 hover:border-purple-500/40 text-slate-300 hover:text-purple-300 rounded-lg cursor-pointer text-[10px] transition-colors">
                      <Upload size={12} className="text-purple-400 shrink-0" />
                      <span>{isWatermarkUploading ? '...' : (lang === 'bn' ? 'আপলোড করুন' : 'Upload')}</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          try {
                            setIsWatermarkUploading(true);
                            const base64 = await compressImageToBase64(file);
                            setNewCertWatermarkUrl(base64);
                          } catch (err) {
                            console.error(err);
                          } finally {
                            setIsWatermarkUploading(false);
                          }
                        }}
                        className="hidden"
                      />
                    </label>
                    {newCertWatermarkUrl && (
                      <div className="relative w-8 h-8 rounded border border-purple-500/25 overflow-hidden shrink-0 flex items-center justify-center bg-white">
                        <img src={newCertWatermarkUrl} alt="Watermark" className="w-full h-full object-contain p-0.5" />
                        <button
                          type="button"
                          onClick={() => setNewCertWatermarkUrl('')}
                          className="absolute inset-0 bg-black/70 opacity-0 hover:opacity-100 flex items-center justify-center text-red-500 text-[10px] font-bold cursor-pointer"
                        >
                          X
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Authority Signature Upload */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">
                    {lang === 'bn' ? 'কর্তৃপক্ষের স্বাক্ষর ছবি (ঐচ্ছিক)' : 'Authority Signature (Optional)'}
                  </label>
                  <div className="flex items-center gap-2">
                    <label className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 bg-[#000d0b]/90 border border-purple-500/15 hover:border-purple-500/40 text-slate-300 hover:text-purple-300 rounded-lg cursor-pointer text-[10px] transition-colors">
                      <Upload size={12} className="text-purple-400 shrink-0" />
                      <span>{isSignatureUploading ? '...' : (lang === 'bn' ? 'স্বাক্ষর ছবি' : 'Signature Pic')}</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          try {
                            setIsSignatureUploading(true);
                            const base64 = await compressImageToBase64(file);
                            setNewCertSignatureUrl(base64);
                          } catch (err) {
                            console.error(err);
                          } finally {
                            setIsSignatureUploading(false);
                          }
                        }}
                        className="hidden"
                      />
                    </label>
                    {newCertSignatureUrl && (
                      <div className="relative w-8 h-8 rounded border border-purple-500/25 overflow-hidden shrink-0 flex items-center justify-center bg-white">
                        <img src={newCertSignatureUrl} alt="Signature" className="w-full h-full object-contain p-0.5" />
                        <button
                          type="button"
                          onClick={() => setNewCertSignatureUrl('')}
                          className="absolute inset-0 bg-black/70 opacity-0 hover:opacity-100 flex items-center justify-center text-red-500 text-[10px] font-bold cursor-pointer"
                        >
                          X
                        </button>
                      </div>
                    )}
                  </div>
                </div>



                {/* Authority Signature Title */}
                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">
                    {lang === 'bn' ? 'কর্তৃপক্ষের পদবি / নাম (বাংলা - ঐচ্ছিক)' : 'Authority Title / Name (Bengali - Optional)'}
                  </label>
                  <input
                    type="text"
                    value={newCertSignatureTitle}
                    onChange={(e) => setNewCertSignatureTitle(e.target.value)}
                    placeholder={lang === 'bn' ? 'যেমন: পরিচালক / প্রধান শিক্ষক' : 'যেমন: পরিচালক / প্রধান শিক্ষক'}
                    className="w-full bg-[#000d0b]/80 border border-purple-500/15 focus:border-purple-500/50 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 outline-none"
                  />
                </div>

                {/* Authority Signature Title En */}
                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">
                    {lang === 'bn' ? 'কর্তৃপক্ষের পদবি / নাম (ইংরেজি - ঐচ্ছিক)' : 'Authority Title / Name (English - Optional)'}
                  </label>
                  <input
                    type="text"
                    value={newCertSignatureTitleEn}
                    onChange={(e) => setNewCertSignatureTitleEn(e.target.value)}
                    placeholder="e.g. Director / Headmaster"
                    className="w-full bg-[#000d0b]/80 border border-purple-500/15 focus:border-purple-500/50 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold py-1.5 rounded-lg text-xs mt-1 cursor-pointer transition-colors"
              >
                {lang === 'bn' ? 'সনদপত্র ইস্যু করুন' : 'Issue Certificate'}
              </button>
            </form>

            {/* List of certificates */}
            <div className="mt-4 flex-1 overflow-y-auto max-h-[160px] divide-y divide-[#011e19]">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                📋 {lang === 'bn' ? 'ইস্যু করা বিদ্যমান সনদপত্রসমূহ' : 'Active Generated Certifications'}
              </span>

              {(!certManagingStudent.certificates || certManagingStudent.certificates.length === 0) ? (
                <div className="py-6 text-center text-xs text-slate-500 font-sans">
                  {lang === 'bn' ? 'এখনো কোনো সনদপত্র ইস্যু করা হয়নি।' : 'No verified certificates generated yet.'}
                </div>
              ) : (
                <div className="flex flex-col gap-1.5 mt-2">
                  {certManagingStudent.certificates.map((cert) => (
                    <div key={cert.id} className="p-2.5 bg-[#000d0b]/60 border border-purple-500/10 rounded-lg flex items-center justify-between text-xs font-sans">
                      <div className="min-w-0 flex-1 pr-2">
                        <div className="font-bold text-purple-300 truncate flex items-center gap-1.5 flex-wrap">
                          <span>📜 {cert.certificateName}</span>
                          {cert.signatureUrl && (
                            <span className="px-1.5 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded text-[8px] font-black leading-none shrink-0 inline-block">🖋️ {lang === 'bn' ? 'স্বাক্ষরিত' : 'Signed'}</span>
                          )}
                          {cert.watermarkUrl && (
                            <span className="px-1.5 py-0.5 bg-purple-500/10 text-purple-400 border border-purple-500/20 rounded text-[8px] font-black leading-none shrink-0 inline-block">🖼️ {lang === 'bn' ? 'জলছাপ' : 'Watermark'}</span>
                          )}
                        </div>
                        <div className="text-[9px] text-slate-500 mt-1 truncate font-mono">Issue: {cert.issueDate} {cert.details ? `| ${cert.details}` : ''}</div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleDeleteCert(cert.id)}
                        className="p-1 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded cursor-pointer shrink-0"
                      >
                        <Trash size={12} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer Close */}
            <div className="border-t border-[#011e19] pt-3 mt-4 text-right">
              <button
                onClick={() => setCertManagingStudent(null)}
                className="px-4 py-1.5 bg-[#011e19] hover:bg-[#002d24] text-slate-300 hover:text-white rounded-lg text-xs font-bold cursor-pointer"
              >
                {lang === 'bn' ? 'সম্পন্ন' : 'Done'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 📝 Edit Student Info Sub-Modal Overlay */}
      {editingStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in zoom-in-95 duration-200">
          <div className="w-full max-w-lg bg-gradient-to-b from-[#012d25] to-[#011411] border border-blue-500/25 p-6 rounded-3xl shadow-2xl relative flex flex-col max-h-[85vh] overflow-y-auto">
            <button
              type="button"
              onClick={() => setEditingStudent(null)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center bg-[#011e19] text-slate-400 hover:text-blue-400 transition-colors cursor-pointer"
            >
              <X size={15} />
            </button>

            <div className="mb-4">
              <h3 className="text-base font-black text-blue-400 flex items-center gap-2 font-mono">
                <Edit size={18} />
                {lang === 'bn' ? `শিক্ষার্থীর তথ্য পরিবর্তন করুন` : `Edit Student Information`}
              </h3>
              <p className="text-xs text-slate-400 mt-1 font-sans">
                {lang === 'bn' 
                  ? `এখানে শিক্ষার্থীর ভর্তি বিবরণ সংশোধন করুন (ID: ${editingStudent.id})` 
                  : `Modify enrollment details dynamically for student ID: ${editingStudent.id}`}
              </p>
            </div>

            <form 
              onSubmit={(e) => {
                e.preventDefault();
                if (!editStdNameBn.trim() || !editStdNameEn.trim() || !editStdFather.trim() || !editStdMother.trim() || !editStdMobile.trim() || !editStdAddress.trim() || !editStdBatchTime.trim() || !editStdClassDays.trim() || !editStdCourseDuration.trim()) {
                  setAlertConfig({
                    isOpen: true,
                    title: lang === 'bn' ? '⚠️ তথ্য অসম্পূর্ণ' : '⚠️ Incomplete Info',
                    message: lang === 'bn' ? 'অনুগ্রহ করে সব তথ্য পূরণ করুন!' : 'Please fill in all fields!',
                  });
                  return;
                }

                const updatedStudent: Student = {
                  ...editingStudent,
                  name: editStdNameBn.trim(),
                  nameBn: editStdNameBn.trim(),
                  nameEn: editStdNameEn.trim(),
                  fatherName: editStdFather.trim(),
                  motherName: editStdMother.trim(),
                  photo: editStdPhoto,
                  mobile: editStdMobile.trim(),
                  address: editStdAddress.trim(),
                  batchTime: editStdBatchTime.trim(),
                  classDaysPerWeek: editStdClassDays.trim(),
                  courseDuration: editStdCourseDuration.trim(),
                  status: editStdStatus,
                };

                onUpdateStudent(updatedStudent);
                setEditingStudent(null);
                setAlertConfig({
                  isOpen: true,
                  title: lang === 'bn' ? '🎉 সফল হয়েছে' : '🎉 Success',
                  message: lang === 'bn' ? 'শিক্ষার্থীর তথ্য সফলভাবে আপডেট করা হয়েছে!' : 'Student information successfully updated!',
                });
              }}
              className="flex flex-col gap-3 font-sans text-left"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pb-1">
                {/* Name Bangla */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">
                    {lang === 'bn' ? 'শিক্ষার্থীর নাম (বাংলা) *' : 'Student Name (Bengali) *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={editStdNameBn}
                    onChange={(e) => setEditStdNameBn(e.target.value)}
                    className="w-full bg-[#000d0b]/90 border border-blue-500/15 focus:border-blue-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none"
                  />
                </div>
                
                {/* Name English */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">
                    {lang === 'bn' ? 'শিক্ষার্থীর নাম (ইংরেজি) *' : 'Student Name (English) *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={editStdNameEn}
                    onChange={(e) => setEditStdNameEn(e.target.value)}
                    className="w-full bg-[#000d0b]/90 border border-blue-500/15 focus:border-blue-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none"
                  />
                </div>

                {/* Father's Name */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">
                    {lang === 'bn' ? 'পিতার নাম *' : 'Father\'s Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={editStdFather}
                    onChange={(e) => setEditStdFather(e.target.value)}
                    className="w-full bg-[#000d0b]/90 border border-blue-500/15 focus:border-blue-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none"
                  />
                </div>

                {/* Mother's Name */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">
                    {lang === 'bn' ? 'মাতার নাম *' : 'Mother\'s Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={editStdMother}
                    onChange={(e) => setEditStdMother(e.target.value)}
                    className="w-full bg-[#000d0b]/90 border border-blue-500/15 focus:border-blue-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none"
                  />
                </div>

                {/* Mobile Number */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">
                    {lang === 'bn' ? 'মোবাইল নম্বর *' : 'Mobile Number *'}
                  </label>
                  <input
                    type="tel"
                    required
                    value={editStdMobile}
                    onChange={(e) => setEditStdMobile(e.target.value)}
                    className="w-full bg-[#000d0b]/90 border border-blue-500/15 focus:border-blue-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none"
                  />
                </div>

                {/* Photo upload block */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">
                    {lang === 'bn' ? 'শিক্ষার্থীর ছবি (ঐচ্ছিক)' : 'Student Photo (Optional)'}
                  </label>
                  <div className="flex items-center gap-2">
                    <label className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 bg-[#000d0b]/90 border border-blue-500/15 hover:border-blue-500/40 text-slate-300 hover:text-blue-400 rounded-lg cursor-pointer text-[10px] transition-colors font-semibold">
                      <Camera size={12} className="text-blue-400 shrink-0" />
                      <span>{isEditStdPhotoUploading ? '...' : (lang === 'bn' ? 'ছবি দিন' : 'Add Photo')}</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          try {
                            setIsEditStdPhotoUploading(true);
                            const base64 = await compressImageToBase64(file);
                            setEditStdPhoto(base64);
                          } catch (err) {
                            console.error(err);
                          } finally {
                            setIsEditStdPhotoUploading(false);
                          }
                        }}
                        className="hidden"
                      />
                    </label>
                    {editStdPhoto && (
                      <div className="relative w-8 h-8 rounded border border-blue-500/25 overflow-hidden shrink-0">
                        <img src={editStdPhoto} alt="Student" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => setEditStdPhoto('')}
                          className="absolute inset-0 bg-black/60 opacity-0 hover:opacity-100 flex items-center justify-center text-red-500 text-[10px] transition-opacity cursor-pointer font-bold font-mono"
                        >
                          X
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Batch Time field */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 mb-1">
                  {lang === 'bn' ? '⏰ কয়টার ব্যাচ *' : '⏰ Batch Time *'}
                </label>
                <input
                  type="text"
                  required
                  value={editStdBatchTime}
                  onChange={(e) => setEditStdBatchTime(e.target.value)}
                  placeholder={lang === 'bn' ? 'যেমন: বিকেল ৪:০০ টা...' : 'e.g. 04:00 PM...'}
                  className="w-full bg-[#000d0b]/90 border border-blue-500/15 focus:border-blue-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none"
                />
              </div>

              {/* Class Days per week */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 mb-1">
                  {lang === 'bn' ? '📅 সপ্তাহে ক্লাস কয়দিন *' : '📅 Class Days per Week *'}
                </label>
                <input
                  type="text"
                  required
                  value={editStdClassDays}
                  onChange={(e) => setEditStdClassDays(e.target.value)}
                  placeholder={lang === 'bn' ? 'যেমন: ৩ দিন...' : 'e.g. 3 Days...'}
                  className="w-full bg-[#000d0b]/90 border border-blue-500/15 focus:border-blue-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none"
                />
              </div>

              {/* Course Duration field */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 mb-1">
                  {lang === 'bn' ? '🎓 কত মাসের কোর্স *' : '🎓 Course Duration *'}
                </label>
                <input
                  type="text"
                  required
                  value={editStdCourseDuration}
                  onChange={(e) => setEditStdCourseDuration(e.target.value)}
                  placeholder={lang === 'bn' ? 'যেমন: ৬ মাস...' : 'e.g. 6 Months...'}
                  className="w-full bg-[#000d0b]/90 border border-blue-500/15 focus:border-blue-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none"
                />
              </div>

              {/* Status field */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 mb-1">
                  {lang === 'bn' ? '🟢 শিক্ষার্থীর অবস্থা' : '🟢 Student Status'}
                </label>
                <select
                  value={editStdStatus}
                  onChange={(e) => setEditStdStatus(e.target.value as 'active' | 'completed' | 'old')}
                  className="w-full bg-slate-900 border border-blue-500/15 focus:border-blue-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none"
                >
                  <option value="active">{lang === 'bn' ? '🟢 সক্রিয় শিক্ষার্থী (Active)' : '🟢 Active Student'}</option>
                  <option value="completed">{lang === 'bn' ? '🎓 কোর্স সম্পন্ন (Completed)' : '🎓 Course Completed'}</option>
                  <option value="old">{lang === 'bn' ? '📜 পুরাতন শিক্ষার্থী (Old)' : '📜 Old Student'}</option>
                </select>
              </div>

              {/* Address block */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 mb-1">
                  {lang === 'bn' ? 'ঠিকানা *' : 'Address *'}
                </label>
                <input
                  type="text"
                  required
                  value={editStdAddress}
                  onChange={(e) => setEditStdAddress(e.target.value)}
                  className="w-full bg-[#000d0b]/90 border border-blue-500/15 focus:border-blue-500/50 rounded-lg px-3 py-1.5 text-xs text-slate-100 outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-emerald-950/40 mt-1">
                <button
                  type="button"
                  onClick={() => setEditingStudent(null)}
                  className="px-4 py-1.5 border border-blue-500/20 bg-[#000d0b]/40 text-blue-400 rounded-lg hover:bg-[#000d0b]/80 text-xs font-semibold cursor-pointer"
                >
                  {lang === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-1.5 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-[#011411] font-bold rounded-lg text-xs transition-colors cursor-pointer shadow-md shadow-blue-500/20"
                >
                  {lang === 'bn' ? 'পরিবর্তন সংরক্ষণ' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Custom Confirmation Popup Overlay */}
      {confirmConfig.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in zoom-in-95 duration-200">
          <div className="w-full max-w-sm rounded-[24px] border border-amber-500/30 bg-gradient-to-br from-[#012d25] to-[#011411] p-6 text-slate-100 shadow-2xl">
            <h3 className="text-base font-bold text-amber-400 mb-2 flex items-center gap-2">
              <AlertCircle size={20} className="text-amber-500 animate-pulse" />
              {confirmConfig.title}
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed mb-6">
              {confirmConfig.message}
            </p>
            <div className="flex gap-3 justify-end text-xs font-bold">
              <button
                onClick={() => setConfirmConfig(prev => ({ ...prev, isOpen: false }))}
                className="px-4 py-2 border border-emerald-500/20 bg-[#000d0b]/40 text-[#34d399] rounded-xl hover:bg-[#000d0b]/80 cursor-pointer transition-colors"
              >
                {lang === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                onClick={() => {
                  confirmConfig.onConfirm();
                  setConfirmConfig(prev => ({ ...prev, isOpen: false }));
                }}
                className="px-4 py-2 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-[#011411] rounded-xl shadow-lg transition-all active:scale-95 cursor-pointer"
              >
                {lang === 'bn' ? 'হ্যাঁ, নিশ্চিত' : 'Yes, Confirm'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Alert Popup Overlay */}
      {alertConfig.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in zoom-in-95 duration-200">
          <div className="w-full max-w-sm rounded-[24px] border border-emerald-500/30 bg-gradient-to-br from-[#012d25] to-[#011411] p-6 text-slate-100 shadow-2xl">
            <h3 className="text-base font-bold text-amber-400 mb-2 flex items-center gap-2">
              <AlertCircle size={20} className="text-amber-500" />
              {alertConfig.title}
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed mb-6">
              {alertConfig.message}
            </p>
            <div className="flex justify-end text-xs font-bold">
              <button
                onClick={() => setAlertConfig(prev => ({ ...prev, isOpen: false }))}
                className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-[#011411] rounded-xl shadow-lg transition-all active:scale-95 cursor-pointer"
              >
                {lang === 'bn' ? 'ঠিক আছে' : 'OK'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
