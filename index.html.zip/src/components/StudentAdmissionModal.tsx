import React, { useState } from 'react';
import { X, User, Phone, MapPin, CheckCircle, Award, Camera, QrCode, AlertCircle } from 'lucide-react';
import { Student } from '../types';

// Helper to downscale and compress images to extremely small base64 string
const compressImageToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 150;
        const MAX_HEIGHT = 150;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
        resolve(dataUrl);
      };
      img.onerror = (err) => reject(err);
    };
    reader.onerror = (err) => reject(err);
  });
};

interface StudentAdmissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'bn' | 'en';
  students: Student[];
  onAddStudent: (newStudent: Student) => void;
  isAdmissionEnabled?: boolean;
}

export const StudentAdmissionModal: React.FC<StudentAdmissionModalProps> = ({
  isOpen,
  onClose,
  lang,
  students,
  onAddStudent,
  isAdmissionEnabled = true,
}) => {
  const [nameBn, setNameBn] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [fatherName, setFatherName] = useState('');
  const [motherName, setMotherName] = useState('');
  const [mobile, setMobile] = useState('');
  const [address, setAddress] = useState('');
  const [photo, setPhoto] = useState<string>('');
  const [batchTime, setBatchTime] = useState('');
  const [classDaysPerWeek, setClassDaysPerWeek] = useState('');
  const [courseDuration, setCourseDuration] = useState('');
  const [isPhotoUploading, setIsPhotoUploading] = useState(false);

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [newlyAdmittedId, setNewlyAdmittedId] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handlePhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setError(lang === 'bn' ? '⚠️ ফাইলের সাইজ অবশ্যই ৫ মেগাবাইটের কম হতে হবে!' : '⚠️ Image size must be less than 5MB!');
      return;
    }

    try {
      setIsPhotoUploading(true);
      setError(null);
      const base64 = await compressImageToBase64(file);
      setPhoto(base64);
    } catch (err) {
      console.error(err);
      setError(lang === 'bn' ? '⚠️ ছবিটি প্রসেস করতে সমস্যা হয়েছে!' : '⚠️ Failed to process image!');
    } finally {
      setIsPhotoUploading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!nameEn.trim() || !nameBn.trim() || !fatherName.trim() || !motherName.trim() || !mobile.trim() || !address.trim() || !batchTime.trim() || !classDaysPerWeek.trim() || !courseDuration.trim()) {
      setError(lang === 'bn' ? '⚠️ অনুগ্রহ করে সব তথ্য পূরণ করুন!' : '⚠️ Please fill in all fields!');
      return;
    }

    // Basic mobile validation helper
    const mobilePattern = /^[0-9+-\s]{5,18}$/;
    if (!mobilePattern.test(mobile)) {
      setError(lang === 'bn' ? '⚠️ সঠিক মোবাইল নম্বর দিন!' : '⚠️ Please enter a valid mobile number!');
      return;
    }

    const studentId = 'STD' + Math.floor(100000 + Math.random() * 900000);
    const newStudent: Student = {
      id: studentId,
      name: nameBn.trim(), // Use Bengali name as default compatibility display name
      nameBn: nameBn.trim(),
      nameEn: nameEn.trim(),
      fatherName: fatherName.trim(),
      motherName: motherName.trim(),
      photo: photo || '', // Optional base64 string
      mobile: mobile.trim(),
      address: address.trim(),
      batchTime: batchTime.trim(),
      classDaysPerWeek: classDaysPerWeek.trim(),
      courseDuration: courseDuration.trim(),
      status: 'active',
      createdAt: Date.now(),
      attendance: {},
    };

    onAddStudent(newStudent);
    setNewlyAdmittedId(studentId);
    setIsSubmitted(true);
  };

  const handleReset = () => {
    setNameEn('');
    setNameBn('');
    setFatherName('');
    setMotherName('');
    setMobile('');
    setAddress('');
    setPhoto('');
    setBatchTime('');
    setClassDaysPerWeek('');
    setCourseDuration('');
    setError(null);
    setIsSubmitted(false);
    setNewlyAdmittedId('');
    onClose();
  };

  // Structured plain-text scan-verification data
  const qrVerificationText = `Verified Student ID: ${newlyAdmittedId}
Student (EN): ${nameEn}
Student (BN): ${nameBn}
Father Name : ${fatherName}
Mother Name : ${motherName}
Mobile No   : ${mobile}
Batch Time  : ${batchTime}
Class Days  : ${classDaysPerWeek}
Duration    : ${courseDuration}
Address     : ${address}
Admission   : ${new Date().toLocaleDateString()}`;

  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(qrVerificationText)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm overflow-y-auto animate-fade-in">
      <div className="relative w-full max-w-xl overflow-hidden rounded-3xl border border-amber-500/30 bg-gradient-to-br from-[#012d25] to-[#011411] shadow-2xl p-5 sm:p-7 text-slate-100 max-h-[92vh] overflow-y-auto">
        
        {/* Absolute top close button */}
        <button
          onClick={handleReset}
          className="absolute top-4 right-4 text-slate-400 hover:text-white bg-black/40 hover:bg-black/60 p-1.5 rounded-full transition-all cursor-pointer z-10"
        >
          <X size={18} />
        </button>

        {!isSubmitted ? (
          !isAdmissionEnabled ? (
            <div className="text-center py-6 animate-in fade-in zoom-in-95 duration-300">
              <div className="w-14 h-14 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-500 flex items-center justify-center mb-4 mx-auto animate-pulse">
                <AlertCircle size={26} />
              </div>
              
              <h3 className="text-lg font-black text-amber-400 mb-2">
                {lang === 'bn' ? 'ভর্তি সাময়িকভাবে বন্ধ আছে' : 'Admission Temporarily Closed'}
              </h3>
              
              <p className="text-xs text-slate-400 max-w-sm mx-auto mb-6 leading-relaxed">
                {lang === 'bn' 
                  ? 'বর্তমানে নতুন শিক্ষার্থী ভর্তি কার্যক্রম সাময়িকভাবে বন্ধ রয়েছে। পরবর্তীতে নতুন ব্যাচে ভর্তি শুরুর তথ্য নোটিশ বোর্ডে জানানো হবে।' 
                  : 'Student enrollments are temporarily closed at this moment. Stay tuned for the next batch announcement on the notice board.'}
              </p>
              
              <button
                type="button"
                onClick={handleReset}
                className="px-5 py-2 hover:scale-[1.02] border border-amber-500/25 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-md"
              >
                {lang === 'bn' ? 'বন্ধ করুন' : 'Close'}
              </button>
            </div>
          ) : (
            <div>
              <div className="flex items-center gap-3 mb-5 border-b border-emerald-950 pb-4">
                <div className="p-2.5 bg-amber-500/10 rounded-2xl border border-amber-500/30 text-amber-400 shrink-0">
                  <Award size={22} />
                </div>
                <div>
                  <h3 className="text-lg font-bold tracking-tight text-amber-400">
                    {lang === 'bn' ? '🎓 শিক্ষার্থী ভর্তি ফরম' : '🎓 Student Admission'}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {lang === 'bn' ? 'প্রয়োজনীয় তথ্য দিয়ে ও ছবি আপলোড করে ফরমটি সাবমিট করুন' : 'Fill up the form and upload photo to apply'}
                  </p>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                {error && (
                  <div className="p-3 rounded-2xl bg-red-500/10 border border-red-500/25 text-red-400 text-xs font-bold font-sans text-center animate-in fade-in zoom-in-95 duration-150">
                    {error}
                  </div>
                )}

                {/* Scrollable container with styled scrollbar for all student admission fields options */}
                <div className="max-h-[50vh] overflow-y-auto pr-1.5 space-y-4">
                  
                  {/* Grid Wrapper for standard input fields */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Bengali Name Field */}
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-amber-500/85 mb-1 font-mono">
                        {lang === 'bn' ? '👤 শিক্ষার্থীর নাম (বাংলা)' : '👤 Student Name (Bengali)'} <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 text-teal-600/60 w-3.5 h-3.5" />
                        <input
                          type="text"
                          value={nameBn}
                          onChange={(e) => setNameBn(e.target.value)}
                          required
                          placeholder="যেমন: আহসান হাবিব..."
                          className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 outline-none placeholder-teal-600/40 transition-all font-sans"
                        />
                      </div>
                    </div>

                    {/* English Name Field */}
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-amber-500/85 mb-1 font-mono">
                        {lang === 'bn' ? '👤 শিক্ষার্থীর নাম (ইংরেজি)' : '👤 Student Name (English)'} <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 text-teal-600/60 w-3.5 h-3.5" />
                        <input
                          type="text"
                          value={nameEn}
                          onChange={(e) => setNameEn(e.target.value)}
                          required
                          placeholder="e.g. Ahsan Habib..."
                          className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 outline-none placeholder-teal-600/40 transition-all font-sans"
                        />
                      </div>
                    </div>

                    {/* Father's Name Field */}
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-amber-500/85 mb-1 font-mono">
                        {lang === 'bn' ? '👨‍👦 পিতার নাম' : '👨‍👦 Father\'s Name'} <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 text-teal-600/60 w-3.5 h-3.5" />
                        <input
                          type="text"
                          value={fatherName}
                          onChange={(e) => setFatherName(e.target.value)}
                          required
                          placeholder={lang === 'bn' ? 'বাবার নাম লিখুন...' : 'Enter father\'s name...'}
                          className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 outline-none placeholder-teal-600/40 transition-all font-sans"
                        />
                      </div>
                    </div>

                    {/* Mother's Name Field */}
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-amber-500/85 mb-1 font-mono">
                        {lang === 'bn' ? '👩‍👦 মাতার নাম' : '👩‍👦 Mother\'s Name'} <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 text-teal-600/60 w-3.5 h-3.5" />
                        <input
                          type="text"
                          value={motherName}
                          onChange={(e) => setMotherName(e.target.value)}
                          required
                          placeholder={lang === 'bn' ? 'মায়ের নাম লিখুন...' : 'Enter mother\'s name...'}
                          className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 outline-none placeholder-teal-600/40 transition-all font-sans"
                        />
                      </div>
                    </div>

                    {/* Mobile Number Field */}
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-amber-500/85 mb-1 font-mono">
                        {lang === 'bn' ? '📞 মোবাইল নম্বর' : '📞 Mobile Number'} <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-teal-600/60 w-3.5 h-3.5" />
                        <input
                          type="tel"
                          value={mobile}
                          onChange={(e) => setMobile(e.target.value)}
                          required
                          placeholder={lang === 'bn' ? 'যেমন: ০১৭...' : 'e.g. +88017...'}
                          className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 outline-none placeholder-teal-600/40 transition-all font-sans"
                        />
                      </div>
                    </div>

                    {/* Photo Upload Field */}
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-amber-500/85 mb-1 font-mono">
                        {lang === 'bn' ? '🖼️ শিক্ষার্থীর ছবি (ঐচ্ছিক)' : '🖼️ Student Photo (Optional)'}
                      </label>
                      <div className="flex items-center gap-3">
                        <label className="flex flex-1 items-center justify-center gap-2 px-3 py-2 bg-[#000d0b]/80 border border-dashed border-emerald-500/25 hover:border-amber-500/50 rounded-xl cursor-pointer text-slate-300 hover:text-amber-400 transition-all text-xs">
                          <Camera size={14} className="text-amber-500" />
                          <span className="font-semibold">{isPhotoUploading ? (lang === 'bn' ? 'প্রসেসিং...' : 'Processing...') : (lang === 'bn' ? 'ছবি নির্বাচন করুন' : 'Select Photo')}</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handlePhotoChange}
                            className="hidden"
                          />
                        </label>
                        {photo && (
                          <div className="relative w-10 h-10 rounded-lg overflow-hidden border border-emerald-500/30 shrink-0">
                            <img src={photo || "/placeholder.svg"} alt="Preview" className="w-full h-full object-cover" />
                            <button
                              type="button"
                              onClick={() => setPhoto('')}
                              className="absolute inset-0 bg-black/60 opacity-0 hover:opacity-100 flex items-center justify-center text-red-400 text-[10px] transition-opacity cursor-pointer"
                            >
                              Clear
                            </button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Batch Time Field */}
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-amber-500/85 mb-1 font-mono">
                        {lang === 'bn' ? '⏰ কয়টার ব্যাচ' : '⏰ Batch Time'} <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          value={batchTime}
                          onChange={(e) => setBatchTime(e.target.value)}
                          required
                          placeholder={lang === 'bn' ? 'যেমন: বিকেল ৪:০০ টা...' : 'e.g. 04:00 PM...'}
                          className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none placeholder-teal-600/40 transition-all font-sans"
                        />
                      </div>
                    </div>

                    {/* Days of Class per Week */}
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-amber-500/85 mb-1 font-mono">
                        {lang === 'bn' ? '📅 সপ্তাহে ক্লাস কয়দিন' : '📅 Class Days per Week'} <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          value={classDaysPerWeek}
                          onChange={(e) => setClassDaysPerWeek(e.target.value)}
                          required
                          placeholder={lang === 'bn' ? 'যেমন: ৩ দিন (সোম, বুধ, শুক্র)...' : 'e.g. 3 Days (Mon, Wed, Fri)...'}
                          className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none placeholder-teal-600/40 transition-all font-sans"
                        />
                      </div>
                    </div>

                    {/* Course Duration */}
                    <div className="md:col-span-2">
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-amber-500/85 mb-1 font-mono">
                        {lang === 'bn' ? '🎓 কত মাসের কোর্স' : '🎓 Course Duration'} <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          value={courseDuration}
                          onChange={(e) => setCourseDuration(e.target.value)}
                          required
                          placeholder={lang === 'bn' ? 'যেমন: ৬ মাস / ১২ মাস...' : 'e.g. 6 Months / 12 Months...'}
                          className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none placeholder-teal-600/40 transition-all font-sans"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Address Field (Full Width) */}
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-amber-500/85 mb-1 font-mono">
                      {lang === 'bn' ? '📍 বর্তমান ও স্থায়ী ঠিকানা' : '📍 Present & Permanent Address'} <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3 text-teal-600/60 w-3.5 h-3.5" />
                      <textarea
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        required
                        rows={2}
                        placeholder={lang === 'bn' ? 'সম্পূর্ণ ঠিকানা লিখুন...' : 'Enter complete address...'}
                        className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 outline-none placeholder-teal-600/40 transition-all font-sans resize-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="flex-1 py-2.5 border border-emerald-500/20 bg-[#000d0b]/40 hover:bg-[#000d0b]/80 text-[#34d399] rounded-xl text-xs font-semibold transition-all cursor-pointer"
                  >
                    {lang === 'bn' ? 'বাতিল' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-[#011411] rounded-xl text-xs font-bold shadow-lg shadow-amber-500/15 transition-all active:scale-95 cursor-pointer"
                  >
                    {lang === 'bn' ? 'ভর্তি নিশ্চিত করুন' : 'Confirm Admission'}
                  </button>
                </div>
              </form>
            </div>
          )
        ) : (
          <div className="text-center py-2 flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mb-3 animate-bounce">
              <CheckCircle size={24} />
            </div>
            
            <h3 className="text-xl font-bold text-emerald-400 mb-1">
              {lang === 'bn' ? 'ভর্তি সফলভাবে সম্পন্ন হয়েছে!' : 'Admission Successfully Done!'}
            </h3>
            
            <p className="text-[10px] text-slate-400 max-w-xs mb-4">
              {lang === 'bn' 
                ? 'আইডি কার্ড, রশিদ ও ভেরিফিকেশন কিউআর কোড (QR Code) তৈরি করা হয়েছে।' 
                : 'Student ID card, admission slip and verification QR Code created.'}
            </p>

            {/* Premium printed Slip/Token Style with details, photo, and live QR code */}
            <div id="print-slip-area" className="w-full bg-stone-100 border-2 border-stone-300 text-stone-900 rounded-2xl p-4 font-mono text-left shadow-inner select-text text-xs relative overflow-hidden">
              <div className="text-center border-b border-dashed border-stone-400 pb-2 mb-3">
                <p className="font-bold text-xs uppercase tracking-widest text-[#012d25]">SWARGADHONI ACADEMY</p>
                <p className="text-[8px] text-stone-500">{lang === 'bn' ? 'ভর্তি রশিদ ও শিক্ষার্থী পত্র' : 'Admission Slip & Docket'}</p>
                <p className="text-[9px] text-stone-400">{new Date().toLocaleString()}</p>
              </div>

              {/* Flex block holding receipt data & student photo */}
              <div className="flex justify-between gap-4">
                <div className="space-y-1 text-[11px] leading-relaxed text-stone-700 font-mono flex-1">
                  <p className="text-stone-900"><span className="font-bold">ID NO  :</span> {newlyAdmittedId}</p>
                  <p className="text-stone-900"><span className="font-bold">NAME BN:</span> {nameBn}</p>
                  <p className="text-stone-900"><span className="font-bold">NAME EN:</span> {nameEn.toUpperCase()}</p>
                  <p><span className="font-bold">FATHER :</span> {fatherName}</p>
                  <p><span className="font-bold">MOTHER :</span> {motherName}</p>
                  <p><span className="font-bold">MOBILE :</span> {mobile}</p>
                  <p><span className="font-bold">BATCH  :</span> {batchTime}</p>
                  <p><span className="font-bold">CLASSES:</span> {classDaysPerWeek}</p>
                  <p><span className="font-bold">DUR    :</span> {courseDuration}</p>
                  <p className="whitespace-pre-wrap"><span className="font-bold">ADD    :</span> {address}</p>
                </div>
                
                {/* Photo rendering inside receipt */}
                {photo ? (
                  <div className="w-16 h-20 border border-stone-400 bg-stone-200/50 p-0.5 rounded shadow-sm shrink-0 flex flex-col justify-between items-center text-center">
                    <img src={photo || "/placeholder.svg"} alt="Student" className="w-full h-14 object-cover rounded" />
                    <span className="text-[7px] text-stone-500 font-bold scale-90">PHOTO</span>
                  </div>
                ) : (
                  <div className="w-16 h-20 border border-stone-400 bg-stone-200/55 rounded shrink-0 flex flex-col justify-center items-center text-center text-stone-400">
                    <Camera size={18} className="text-stone-400 mb-0.5" />
                    <span className="text-[7px] font-bold">NO IMG</span>
                  </div>
                )}
              </div>

              {/* Bottom dashed boundary with the beautifully rendered QR server Verification code */}
              <div className="border-t border-dashed border-stone-400 pt-3 mt-3 flex flex-col sm:flex-row items-center justify-between gap-2 bg-[#f0f0ed] p-2 rounded-lg">
                <div className="text-left flex-1 min-w-0 pr-1 select-none">
                  <p className="text-[9px] font-bold uppercase text-[#012d25] flex items-center gap-1">
                    <QrCode size={10} className="text-emerald-700" />
                    <span>SECURE QR VERIFIED</span>
                  </p>
                  <p className="text-[8px] text-stone-500 leading-tight mt-0.5">
                    {lang === 'bn' ? 'মোবাইল ক্যামেরা দিয়ে স্ক্যান করে তথ্য যাচাই করুন।' : 'Scan using smartphone camera to verify admission.'}
                  </p>
                </div>
                
                {/* Live QR Image */}
                <div className="bg-white p-1 border border-stone-300 rounded shrink-0 shadow-sm">
                  <img 
                    src={qrCodeUrl} 
                    alt="Admission Verification QR Code" 
                    className="w-14 h-14" 
                    crossOrigin="anonymous" 
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>

              <div className="mt-2.5 text-center">
                <p className="text-[8px] text-stone-400 font-bold tracking-widest uppercase">OFFICIAL SWARGADHONI VALID DOCUMENT</p>
              </div>
            </div>

            {/* Quick browser print action */}
            <div className="flex gap-2 w-full mt-4">
              <button
                onClick={() => {
                  const printAreaRef = document.getElementById('print-slip-area');
                  if (!printAreaRef) return;
                  const win = window.open('', '_blank');
                  if (win) {
                    win.document.write(`
                      <html>
                        <head>
                          <title>Admission Slip - ${newlyAdmittedId}</title>
                          <style>
                            body {
                              font-family: monospace;
                              padding: 20px;
                              display: flex;
                              justify-content: center;
                              align-items: center;
                              min-height: 100vh;
                              background: #fff;
                              color: #000;
                            }
                            #print-slip {
                              width: 380px;
                              border: 2px solid #555;
                              border-radius: 12px;
                              padding: 16px;
                              box-sizing: border-box;
                            }
                            .center { text-align: center; }
                            .dashed-border { border-bottom: 1px dashed #555; margin: 10px 0; }
                            .flex-row { display: flex; justify-content: space-between; gap: 15px; margin-bottom: 12px; }
                            .flex-1 { flex: 1; }
                            .details p { margin: 4px 0; font-size: 11px; line-height: 1.4; }
                            .student-photo { width: 70px; height: 90px; border: 1px solid #777; border-radius: 4px; object-fit: cover; }
                            .qr-container { display: flex; align-items: center; justify-content: space-between; background: #f5f5f5; padding: 8px; border-radius: 6px; }
                            .qr-img { width: 64px; height: 64px; background: white; margin-left: auto; border: 1px solid #ddd; padding: 1px; }
                            .qr-info { font-size: 8px; color: #555; text-align: left; }
                            .title { font-weight: bold; font-size: 14px; margin: 0; color: #111; tracking-widest: uppercase; }
                          </style>
                        </head>
                        <body onload="window.print(); window.close();">
                          <div id="print-slip">
                            <div class="center">
                              <h3 class="title">SWARGADHONI ACADEMY</h3>
                              <p style="font-size: 10px; margin: 2px 0;">${lang === 'bn' ? 'ভর্তি রশিদ ও তথ্য স্লিপ' : 'Admission Slip & Info'}</p>
                              <p style="font-size: 9px; color: #666; margin: 2px 0;">${new Date().toLocaleString()}</p>
                            </div>
                            <div class="dashed-border"></div>
                            <div class="flex-row">
                              <div class="details flex-1">
                                <p><strong>ID NO:</strong> ${newlyAdmittedId}</p>
                                <p><strong>NAME (BN):</strong> ${nameBn}</p>
                                <p><strong>NAME (EN):</strong> ${nameEn.toUpperCase()}</p>
                                <p><strong>FATHER:</strong> ${fatherName}</p>
                                <p><strong>MOTHER:</strong> ${motherName}</p>
                                <p><strong>MOBILE:</strong> ${mobile}</p>
                                <p><strong>BATCH:</strong> ${batchTime}</p>
                                <p><strong>CLASSES:</strong> ${classDaysPerWeek}</p>
                                <p><strong>DURATION:</strong> ${courseDuration}</p>
                                <p style="white-space: pre-wrap;"><strong>ADDR:</strong> ${address}</p>
                              </div>
                              ${photo ? `<img class="student-photo" src="${photo}" />` : `<div style="width: 70px; height: 90px; border: 1px dashed #777; display: flex; align-items: center; justify-content: center; font-size: 8px; color: #777;">NO IMAGE</div>`}
                            </div>
                            <div class="dashed-border"></div>
                            <div class="qr-container">
                              <div class="qr-info">
                                <p style="font-weight: bold; color: #000; margin: 0; font-size: 9px;">SECURE QR VERIFIED</p>
                                <p style="margin: 3px 0 0 0; line-height: 1.2;">${lang === 'bn' ? 'মোবাইল ক্যামেরা স্ক্যান যাচাইকরণের জন্য।' : 'Scan with mobile camera to verify.'}</p>
                              </div>
                              <img class="qr-img" src="${qrCodeUrl}" />
                            </div>
                            <div class="center" style="margin-top: 10px; font-size: 8px; color: #888;">OFFICIAL VALIDATED DOCUMENT</div>
                          </div>
                        </body>
                      </html>
                    `);
                    win.document.close();
                  }
                }}
                className="flex-1 py-3 bg-[#011e19] border border-emerald-500/20 hover:bg-[#012d25] text-amber-400 font-bold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <span>🖨️ {lang === 'bn' ? 'স্লিপ প্রিন্ট করুন' : 'Print Slip'}</span>
              </button>

              <button
                onClick={handleReset}
                className="flex-1 py-3 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-[#011411] font-bold rounded-xl text-xs shadow-md transition-all active:scale-95 cursor-pointer"
              >
                {lang === 'bn' ? 'বন্ধ করুন' : 'Finish & Close'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
