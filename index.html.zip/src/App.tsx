import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Lock, X, ChevronDown, ChevronUp, Github, Heart, CheckCircle, Phone, MessageCircle, Facebook, ExternalLink, BookOpen, GraduationCap, UserPlus, Smartphone, Wifi, WifiOff, Bell } from 'lucide-react';

// Core Components
import Splash from './components/Splash';
import Navbar from './components/Navbar';
import SearchAndFilter from './components/SearchAndFilter';
import ItemCard from './components/ItemCard';
import LyricsModal from './components/LyricsModal';
import VideoModal from './components/VideoModal';
import { UtsargaModal, LekhokModal } from './components/InfoModals';
import AdminPanel from './components/AdminPanel';
import { StudentAdmissionModal } from './components/StudentAdmissionModal';
import StudentPortalModal from './components/StudentPortalModal';
import AppDownloadModal from './components/AppDownloadModal';
import PrayerTimeWidget from './components/PrayerTimeWidget';
import StatusBarWidget from './components/StatusBarWidget';

// Default and Translation Assets
import {
  INITIAL_ITEMS,
  INITIAL_SECTIONS,
  INITIAL_SECTION_NAMES,
  INITIAL_INFO_TEXTS,
  TRANSLATIONS,
  PHYSICAL_THEMES,
} from './data';
import { IslamicItem, SectionNames, InfoTexts, Student, PrayerTimesConfig, StatusBarConfig, AppNotification } from './types';
import { onValue, ref, set, runTransaction } from 'firebase/database';
import {
  db,
  saveItemsToFirebase,
  saveSingleItemToFirebase,
  deleteItemFromFirebase,
  saveSectionsToFirebase,
  saveSectionNamesToFirebase,
  saveInfoToFirebase,
  saveThemeToFirebase,
  saveStudentsToFirebase,
  saveSingleStudentToFirebase,
  deleteStudentFromFirebase,
  saveAppDownloadToFirebase,
  saveNoticeToFirebase,
  savePrayerTimesConfigToFirebase,
  saveStatusBarConfigToFirebase,
  saveAdmissionEnabledToFirebase,
  saveNotificationToFirebase,
  deleteNotificationFromFirebase,
} from './firebase';

const DEFAULT_NOTICE = {
  textBn: 'স্বর্গধ্বনি একাডেমিতে আপনাকে স্বাগতম! এখানে আপনি পাবেন আধুনিক সব ইসলামিক গজল, লিরিক্স, ভিডিও এবং মানসম্মত শিক্ষা কার্যক্রম।',
  textEn: 'Welcome to Swargadhoni Academy! Explore our extensive collection of modern Islamic lyrics, beautiful video playbacks, and dynamic learning programs.',
  enabled: true,
  speed: 30
};

const DEFAULT_PRAYER_CONFIG: PrayerTimesConfig = {
  showWidget: true,
  mode: 'auto',
  manualTimings: {
    Fajr: "04:15",
    Sunrise: "05:35",
    Dhuhr: "12:15",
    Asr: "16:45",
    Maghrib: "18:45",
    Isha: "20:00"
  }
};

const DEFAULT_STATUS_BAR_CONFIG: StatusBarConfig = {
  enabled: true,
  slides: [
    {
      id: 'slide-1',
      imageUrl: 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&auto=format&fit=crop&q=80',
      captionBn: 'স্বর্গধ্বনি একাডেমিতে স্বাগতম - আধুনিক ইসলামিক গজল ও সুরের রাজ্য!',
      captionEn: 'Welcome to Swargadhoni Academy - The realm of modern Islamic lyrics!'
    },
    {
      id: 'slide-2',
      imageUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80',
      captionBn: 'সরাসরি আমাদের নতুন শিক্ষাবর্ষের গজল ও লিরিক্স প্রশিক্ষণ শুরু হচ্ছে!',
      captionEn: 'Enrolling starts for our new lyric writing and voice coaching program!'
    }
  ]
};

export default function App() {
  // 1. Core State Initialization
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [lang, setLang] = useState<'bn' | 'en'>(() => {
    return (localStorage.getItem('swarg_lang') as 'bn' | 'en') || 'bn';
  });
  const [currentTheme, setCurrentTheme] = useState<string>(() => {
    return localStorage.getItem('swarg_theme') || 'emerald';
  });

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [currentCategory, setCurrentCategory] = useState<string>('all');

  // Media items, categories, and generic customization states
  const [items, setItems] = useState<IslamicItem[]>(() => {
    const saved = localStorage.getItem('swarg_items');
    return saved ? JSON.parse(saved) : INITIAL_ITEMS;
  });
  const [sections, setSections] = useState<string[]>(() => {
    const saved = localStorage.getItem('swarg_sections');
    return saved ? JSON.parse(saved) : INITIAL_SECTIONS;
  });
  const [sectionNames, setSectionNames] = useState<SectionNames>(() => {
    const saved = localStorage.getItem('swarg_section_names');
    return saved ? JSON.parse(saved) : INITIAL_SECTION_NAMES;
  });
  const [info, setInfo] = useState<InfoTexts>(() => {
    const saved = localStorage.getItem('swarg_info_texts');
    return saved ? { ...INITIAL_INFO_TEXTS, ...JSON.parse(saved) } : INITIAL_INFO_TEXTS;
  });

  // Students admission state pool - Powered by cloud Firebase Database with LocalStorage offline backup
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('swarg_students_backup');
    return saved ? JSON.parse(saved) : [];
  });
  const [isFirebaseLoading, setIsFirebaseLoading] = useState<boolean>(true);
  
  // App Download link and QR Code image config
  const [appDownload, setAppDownload] = useState<{ downloadUrl?: string; badgeUrl?: string }>(() => {
    const saved = localStorage.getItem('swarg_app_download');
    return saved ? JSON.parse(saved) : {};
  });

  // Scrolling text banner/marquee state
  const [notice, setNotice] = useState<{ textBn: string; textEn: string; enabled: boolean; speed?: number }>(() => {
    const saved = localStorage.getItem('swarg_notice');
    return saved ? JSON.parse(saved) : DEFAULT_NOTICE;
  });

  // Prayer Times Configuration Sync State
  const [prayerTimesConfig, setPrayerTimesConfig] = useState<PrayerTimesConfig>(() => {
    const saved = localStorage.getItem('swarg_prayer_config');
    return saved ? JSON.parse(saved) : DEFAULT_PRAYER_CONFIG;
  });

  // Sliding Image Status Bar Config
  const [statusBarConfig, setStatusBarConfig] = useState<StatusBarConfig>(() => {
    const saved = localStorage.getItem('swarg_status_bar_config');
    return saved ? JSON.parse(saved) : DEFAULT_STATUS_BAR_CONFIG;
  });

  // Real-time visitor counter state
  const [visitCount, setVisitCount] = useState<number>(0);
  
  const [isAdmissionOpen, setIsAdmissionOpen] = useState<boolean>(false);
  const [isAdmissionEnabled, setIsAdmissionEnabled] = useState<boolean>(true);
  const [isStudentPortalOpen, setIsStudentPortalOpen] = useState<boolean>(false);
  const [isAppDownloadOpen, setIsAppDownloadOpen] = useState<boolean>(false);

  // 2. Navigation, collapsing cards & active selections
  const [activeLyricsItem, setActiveLyricsItem] = useState<IslamicItem | null>(null);
  const [activeVideo, setActiveVideo] = useState<{ url: string; title: string } | null>(null);

  const [isUtsargaOpen, setIsUtsargaOpen] = useState<boolean>(false);
  const [isLekhokOpen, setIsLekhokOpen] = useState<boolean>(false);

  // Admin access validation states
  const [isAdminAuthOpen, setIsAdminAuthOpen] = useState<boolean>(false);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState<boolean>(false);
  const [passwordInput, setPasswordInput] = useState<string>('');
  const [authError, setAuthError] = useState<string | null>(null);

  // Local state to manage collapsed states of individual category card-decks
  const [collapsedCategories, setCollapsedCategories] = useState<{ [key: string]: boolean }>({});
  
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Broadcast Notifications State
  const [activeNotification, setActiveNotification] = useState<AppNotification | null>(null);
  const [showNotificationPopup, setShowNotificationPopup] = useState<boolean>(false);
  const [hasShownOnSessionStart, setHasShownOnSessionStart] = useState<boolean>(false);
  const [showOnboardingPermissionPrompt, setShowOnboardingPermissionPrompt] = useState<boolean>(false);
  const [notificationsList, setNotificationsList] = useState<AppNotification[]>([]);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState<boolean>(false);

  // Online/Offline and Firebase Connection Status State
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [isFirebaseConnected, setIsFirebaseConnected] = useState<boolean>(true);

  // Monitor connection status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Listen to Firebase Realtime Database connection status
    const connectedRef = ref(db, '.info/connected');
    const unsubscribeConnected = onValue(connectedRef, (snap) => {
      setIsFirebaseConnected(!!snap.val());
    });

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      unsubscribeConnected();
    };
  }, []);

  const [wasDisconnected, setWasDisconnected] = useState<boolean>(false);
  const [showConnectedToast, setShowConnectedToast] = useState<boolean>(false);

  useEffect(() => {
    if (!isOnline || !isFirebaseConnected) {
      setWasDisconnected(true);
    } else if (isOnline && isFirebaseConnected && wasDisconnected) {
      setWasDisconnected(false);
      setShowConnectedToast(true);
      const timer = setTimeout(() => {
        setShowConnectedToast(false);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [isOnline, isFirebaseConnected, wasDisconnected]);

  const t = TRANSLATIONS[lang];

  // Dynamic Deep-Link auto-open shared item
  useEffect(() => {
    if (items && items.length > 0) {
      const params = new URLSearchParams(window.location.search);
      const sharedId = params.get('sharedItem') || params.get('item');
      if (sharedId) {
        const found = items.find(i => i.id === sharedId);
        if (found) {
          setTimeout(() => {
            setActiveLyricsItem(found);
          }, 300);
          
          // Clean the query parameters elegantly
          const newUrl = window.location.pathname + window.location.hash;
          window.history.replaceState({}, document.title, newUrl);
        }
      }
    }
  }, [items]);

  // Toast self-dismiss timer
  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => {
        setToastMessage(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  // Capture secret password in the Search bar to automatically unlock and open the Admin Panel
  useEffect(() => {
    const trimmedQuery = searchQuery.trim();
    if (trimmedQuery === 'Ahsan@1992' || trimmedQuery === 'ahsan@1992') {
      const timer = setTimeout(() => {
        setSearchQuery('');
        setIsAdminPanelOpen(true);
        setToastMessage(lang === 'bn' ? '🔐 এডমিন প্যানেলে সফলভাবে প্রবেশ করেছেন!' : '🔐 Successfully entered Admin Panel!');
      }, 450);
      return () => clearTimeout(timer);
    }
  }, [searchQuery, lang]);

  // Combined web clipboard copying and system native sharing action
  const handleShareItem = async (item: IslamicItem) => {
    const isBn = lang === 'bn';
    const categoryLabel = sectionNames[item.category]
      ? isBn
        ? sectionNames[item.category].bn
        : sectionNames[item.category].en
      : item.category;

    const formattedText = `🕌 *[${isBn ? 'স্বর্গধ্বনি একাডেমি' : 'Swargadhoni Academy'}]* 🕌\n\n` +
      `*${isBn ? 'শিরোনাম' : 'Title'}:* ${item.title}\n` +
      `*${isBn ? 'বিভাগ' : 'Category'}:* ${categoryLabel}\n\n` +
      (item.lyrics ? `*${isBn ? 'গানের কথা (Lyrics)' : 'Lyrics'}:*\n---------------------------------------\n${item.lyrics}\n---------------------------------------\n\n` : '') +
      ((item.videoUrl && item.mediaType !== 'lyrics') ? `*${isBn ? 'ইউটিউব ভিডিও লিঙ্ক' : 'YouTube Video'}:* ${item.videoUrl}\n\n` : '') +
      `*${isBn ? 'অ্যাপ লিঙ্ক' : 'App Link'}:* ${window.location.origin}${window.location.pathname}?sharedItem=${item.id}`;

    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(formattedText);
        setToastMessage(t.shareSuccess);
      } else {
        // Fallback for older browsers
        const textarea = document.createElement('textarea');
        textarea.value = formattedText;
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        setToastMessage(t.shareSuccess);
      }
    } catch (err) {
      console.error('Clipboard write failed:', err);
    }

    // Call mobile native share sheet if possible
    if (navigator.share) {
      try {
        await navigator.share({
          title: item.title,
          text: `${item.title} - ${categoryLabel}`,
          url: `${window.location.origin}${window.location.pathname}?sharedItem=${item.id}`
        });
      } catch (shareErr) {
        console.log('Native share canceled or unsuccessful', shareErr);
      }
    }
  };

  // 3. Side Effects for Persistence & Splash Timer
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
      
      // Open the custom onboarding permission prompt immediately after splash screen if permission is not already granted
      if ('Notification' in window) {
        if (Notification.permission !== 'granted') {
          setShowOnboardingPermissionPrompt(true);
        }
      } else {
        // Show onboarding prompt for environments that don't support native notifications so the user can see it
        setShowOnboardingPermissionPrompt(true);
      }
    }, 1800);
    return () => clearTimeout(timer);
  }, []);

  // Sync state mutations to LocalStorage standard persistence
  useEffect(() => {
    localStorage.setItem('swarg_lang', lang);
  }, [lang]);

  useEffect(() => {
    localStorage.setItem('swarg_theme', currentTheme);
  }, [currentTheme]);

  useEffect(() => {
    localStorage.setItem('swarg_items', JSON.stringify(items));
  }, [items]);

  useEffect(() => {
    localStorage.setItem('swarg_sections', JSON.stringify(sections));
  }, [sections]);

  useEffect(() => {
    localStorage.setItem('swarg_section_names', JSON.stringify(sectionNames));
  }, [sectionNames]);

  useEffect(() => {
    try {
      localStorage.setItem('swarg_info_texts', JSON.stringify(info));
    } catch (e) {
      console.warn("Storage write failed:", e);
    }
  }, [info]);

  useEffect(() => {
    try {
      localStorage.setItem('swarg_app_download', JSON.stringify(appDownload));
    } catch (e) {
      console.warn("Storage write failed:", e);
    }
  }, [appDownload]);

  useEffect(() => {
    try {
      localStorage.setItem('swarg_notice', JSON.stringify(notice));
    } catch (e) {
      console.warn("Storage write failed:", e);
    }
  }, [notice]);

  useEffect(() => {
    try {
      localStorage.setItem('swarg_prayer_config', JSON.stringify(prayerTimesConfig));
    } catch (e) {
      console.warn("Storage write failed:", e);
    }
  }, [prayerTimesConfig]);

  useEffect(() => {
    try {
      localStorage.setItem('swarg_status_bar_config', JSON.stringify(statusBarConfig));
    } catch (e) {
      console.warn("Storage write failed:", e);
    }
  }, [statusBarConfig]);

  useEffect(() => {
    try {
      if (students && students.length > 0) {
        localStorage.setItem('swarg_students_backup', JSON.stringify(students));
      }
    } catch (e) {
      console.warn("Storage write failed for student backup:", e);
    }
  }, [students]);

  // Web-Audio and System Web Push notification helpers
  const playNotificationSound = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      
      const playTone = (freq: number, start: number, duration: number) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, start);
        
        gain.gain.setValueAtTime(0, start);
        gain.gain.linearRampToValueAtTime(0.2, start + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(start);
        osc.stop(start + duration);
      };
      
      const now = ctx.currentTime;
      playTone(587.33, now, 0.4); // D5 (Note)
      playTone(880, now + 0.12, 0.6); // A5 (Note)
    } catch (err) {
      console.error("Audio chime play error:", err);
    }
  };

  // Unlock Web Audio automatically on the first user click/touch for mobile devices
  useEffect(() => {
    let unlocked = false;
    const unlockAudio = () => {
      if (unlocked) return;
      try {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioContextClass) {
          const ctx = new AudioContextClass();
          // Play a tiny 0.01s silent tone to unlock iOS/Android browser audio context
          const buffer = ctx.createBuffer(1, 1, 22050);
          const source = ctx.createBufferSource();
          source.buffer = buffer;
          source.connect(ctx.destination);
          source.start(0);
          if (ctx.state === 'suspended') {
            ctx.resume();
          }
          unlocked = true;
          console.log("Web Audio successfully unlocked on mobile gesture interaction.");
        }
      } catch (e) {
        console.warn("Could not unlock Web Audio context:", e);
      }
      
      window.removeEventListener('click', unlockAudio);
      window.removeEventListener('touchstart', unlockAudio);
    };

    window.addEventListener('click', unlockAudio);
    window.addEventListener('touchstart', unlockAudio);
    return () => {
      window.removeEventListener('click', unlockAudio);
      window.removeEventListener('touchstart', unlockAudio);
    };
  }, []);

  const triggerNativeNotification = (title: string, body: string) => {
    if ('Notification' in window) {
      if (Notification.permission === 'granted') {
        try {
          new Notification(title, {
            body: body,
            icon: '/favicon.ico'
          });
        } catch (err) {
          console.error('Failed to trigger native notification', err);
        }
      }
    }
  };

  const handleIncomingNotification = (notif: AppNotification) => {
    const lastSeenId = localStorage.getItem('swarg_last_seen_notif_id');
    const fortyEightHoursAgo = Date.now() - 48 * 60 * 60 * 1000;
    
    if (notif && notif.id && notif.createdAt && notif.createdAt > fortyEightHoursAgo) {
      // Determine if this is a brand new broadcast notification
      const isNewNotif = notif.id !== lastSeenId;
      // Show if it is a new notification or we haven't shown any active notice on start of this session
      const shouldShow = isNewNotif || !hasShownOnSessionStart;

      if (shouldShow) {
        setActiveNotification(notif);
        setShowNotificationPopup(true);
        
        // Only trigger the notify chime sound and system desktop alert if it is a brand new live broadcast
        if (isNewNotif) {
          playNotificationSound();
          const titleText = lang === 'bn' ? notif.titleBn : notif.titleEn;
          const bodyText = lang === 'bn' ? notif.bodyBn : notif.bodyEn;
          triggerNativeNotification(titleText, bodyText);
        }
        
        setHasShownOnSessionStart(true);
      }
    }
  };

  const handleRequestNotificationPermission = () => {
    if ('Notification' in window) {
      try {
        Notification.requestPermission().then((permission) => {
          if (permission === 'granted') {
            playNotificationSound();
            setToastMessage(lang === 'bn' ? 'সাফল্যের সাথে নোটিফিকেশন চালু করা হয়েছে! ধন্যবাদ।' : 'System notifications successfully enabled! Thank you.');
          } else {
            // Provide alternative details for mobile/webview where native permission might be denied or restricted
            playNotificationSound();
            setToastMessage(lang === 'bn' 
              ? 'ইন-অ্যাপ লাইভ নোটিফিকেশন চালু করা হয়েছে! নতুন কোনো গজল আসলে আপনি অ্যাপে থাকলে সুর শুনতে পাবেন।' 
              : 'In-app live alerts successfully active! You will hear a beautiful chime when updates arrive.');
          }
        }).catch(() => {
          playNotificationSound();
          setToastMessage(lang === 'bn' 
            ? 'ইন-অ্যাপ লাইভ নোটিফিকেশন চালু করা হয়েছে! নতুন গজল বা বিজ্ঞপ্তির সুর সরাসরি শুনতে পাবেন।' 
            : 'In-app live alerts successfully active! Sound alerts will play instantly.');
        });
      } catch (err) {
        playNotificationSound();
        setToastMessage(lang === 'bn' 
          ? 'ইন-অ্যাপ লাইভ নোটিফিকেশন চালু করা হয়েছে! নতুন গজল বা বিজ্ঞপ্তির সুর সরাসরি শুনতে পাবেন।' 
          : 'In-app live alerts successfully active! Sound alerts will play instantly.');
      }
    } else {
      // Friendly, highly reassurance-focused response for iOS/Mobile browsers without native Notifications support
      playNotificationSound();
      setToastMessage(lang === 'bn' 
        ? 'মোবাইলে ইন-অ্যাপ লাইভ নোটিফিকেশন সক্রিয় হয়েছে! নতুন কিছু যুক্ত হলে সাথে সাথে সুর শুনতে ও দেখতে পাবেন।' 
        : 'In-app Live Alerts successfully activated on your mobile device! Chime sound unlocked.');
    }
  };

  // Real-time synchronization with Firebase Database
  useEffect(() => {
    const rootRef = ref(db, '/');
    const unsubscribe = onValue(rootRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val();
        if (data.items) {
          const loadedItems = Array.isArray(data.items)
            ? data.items
            : Object.values(data.items);
          setItems(loadedItems.filter((i): i is IslamicItem => i !== null && i !== undefined));
        } else {
          set(ref(db, 'items'), INITIAL_ITEMS);
        }

        if (data.sections) {
          const loadedSections = Array.isArray(data.sections)
            ? data.sections
            : Object.values(data.sections);
          setSections(loadedSections.filter((s): s is string => s !== null && s !== undefined));
        } else {
          set(ref(db, 'sections'), INITIAL_SECTIONS);
        }

        if (data.sectionNames) {
          setSectionNames(data.sectionNames);
        } else {
          set(ref(db, 'sectionNames'), INITIAL_SECTION_NAMES);
        }

        if (data.info) {
          const mergedInfo = { ...INITIAL_INFO_TEXTS, ...data.info };
          if (!data.info.contactPhone) {
            mergedInfo.contactPhone = INITIAL_INFO_TEXTS.contactPhone;
          }
          if (!data.info.contactWhatsapp) {
            mergedInfo.contactWhatsapp = INITIAL_INFO_TEXTS.contactWhatsapp;
          }
          if (!data.info.contactFacebook) {
            mergedInfo.contactFacebook = INITIAL_INFO_TEXTS.contactFacebook;
          }
          if (data.info.showContactBar === undefined) {
            mergedInfo.showContactBar = INITIAL_INFO_TEXTS.showContactBar;
          }
          setInfo(mergedInfo);
        } else {
          set(ref(db, 'info'), INITIAL_INFO_TEXTS);
        }

        if (data.theme) {
          setCurrentTheme(data.theme);
        } else {
          set(ref(db, 'theme'), 'emerald');
        }

        if (data.students) {
          const loadedStudents = Array.isArray(data.students)
            ? data.students
            : Object.values(data.students);
          setStudents(loadedStudents.filter((s): s is Student => s !== null && s !== undefined));
        } else {
          setStudents([]);
        }

        if (data.appDownload) {
          setAppDownload(data.appDownload);
        } else {
          setAppDownload({});
        }

        if (data.notice) {
          setNotice(data.notice);
        } else {
          setNotice(DEFAULT_NOTICE);
        }

        if (data.prayerTimesConfig) {
          setPrayerTimesConfig(data.prayerTimesConfig);
        } else {
          set(ref(db, 'prayerTimesConfig'), DEFAULT_PRAYER_CONFIG);
        }

        if (data.statusBarConfig) {
          setStatusBarConfig(data.statusBarConfig);
        } else {
          set(ref(db, 'statusBarConfig'), DEFAULT_STATUS_BAR_CONFIG);
        }

        if (data.visitCount !== undefined) {
          setVisitCount(data.visitCount);
        } else {
          set(ref(db, 'visitCount'), 1);
        }

        if (data.isAdmissionEnabled !== undefined) {
          setIsAdmissionEnabled(data.isAdmissionEnabled);
        } else {
          set(ref(db, 'isAdmissionEnabled'), true);
        }

        if (data.notifications) {
          const loadedNotifications = Array.isArray(data.notifications)
            ? data.notifications
            : Object.values(data.notifications);
          const filtered = loadedNotifications
            .filter((n): n is AppNotification => n !== null && n !== undefined)
            .sort((a, b) => b.createdAt - a.createdAt);
          setNotificationsList(filtered);
        } else {
          setNotificationsList([]);
        }

        if (data.lastNotification) {
          handleIncomingNotification(data.lastNotification);
        }
      } else {
        // Automatically seed the database if it is brand new or empty
        set(ref(db, '/'), {
          items: INITIAL_ITEMS,
          sections: INITIAL_SECTIONS,
          sectionNames: INITIAL_SECTION_NAMES,
          info: INITIAL_INFO_TEXTS,
          theme: 'emerald',
          students: {},
          appDownload: {},
          notice: DEFAULT_NOTICE,
          prayerTimesConfig: DEFAULT_PRAYER_CONFIG,
          statusBarConfig: DEFAULT_STATUS_BAR_CONFIG,
          visitCount: 1,
          isAdmissionEnabled: true,
        });
      }
      setIsFirebaseLoading(false);
    }, (error) => {
      console.error("Firebase connection / synchronized database fetch error:", error);
      setIsFirebaseLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Increment visitor count once per user session
  useEffect(() => {
    try {
      const sessionVisited = sessionStorage.getItem('swarg_session_visited');
      if (!sessionVisited) {
        sessionStorage.setItem('swarg_session_visited', 'true');
        const visitCountRef = ref(db, 'visitCount');
        runTransaction(visitCountRef, (currentVal) => {
          return (currentVal || 0) + 1;
        }).catch((err) => {
          console.error("Error writing session visitor transaction:", err);
        });
      }
    } catch (e) {
      console.error("Local storage / session storage disabled or error:", e);
    }
  }, []);

  const handleAddStudent = (newStudent: Student) => {
    setStudents((prev) => {
      const updated = [...prev, newStudent];
      saveSingleStudentToFirebase(newStudent);
      return updated;
    });
  };

  const handleDeleteStudent = (studentId: string) => {
    setStudents((prev) => {
      const updated = prev.filter((s) => s.id !== studentId);
      deleteStudentFromFirebase(studentId);
      return updated;
    });
  };

  const handleUpdateStudentAttendance = (studentId: string, dateStr: string, status: 'present' | 'absent') => {
    setStudents((prev) => {
      let targetStudent: Student | null = null;
      const updated = prev.map((std) => {
        if (std.id === studentId) {
          targetStudent = {
            ...std,
            attendance: {
              ...(std.attendance || {}),
              [dateStr]: status,
            },
          };
          return targetStudent;
        }
        return std;
      });
      if (targetStudent) {
        saveSingleStudentToFirebase(targetStudent);
      }
      return updated;
    });
  };

  const handleUpdateStudent = (updatedStudent: Student) => {
    setStudents((prev) => {
      const updated = prev.map((std) => (std.id === updatedStudent.id ? updatedStudent : std));
      saveSingleStudentToFirebase(updatedStudent);
      return updated;
    });
  };

  // Collapsible toggle helper
  const toggleCategoryCollapse = (cat: string) => {
    setCollapsedCategories((prev) => ({
      ...prev,
      [cat]: !prev[cat],
    }));
  };

  // 4. Admin Auth validation
  const handleAdminAuthSubmit = () => {
    setAuthError(null);
    if (passwordInput === 'Ahsan@1992') {
      setIsAdminAuthOpen(false);
      setIsAdminPanelOpen(true);
      setPasswordInput('');
    } else {
      setAuthError(t.wrongPassword);
    }
  };

  // Lyrics pop-up handler
  const triggerLyricsModal = (id: string) => {
    const target = items.find((i) => i.id === id);
    if (target) {
      setActiveLyricsItem(target);
    }
  };

  // Filtering songs
  const filteredItems = items.filter((item) => {
    // Exact category matching
    const matchesCategory = currentCategory === 'all' || item.category === currentCategory;

    // Search matches either Title or Lyrics content beautifully
    const normalizedQuery = searchQuery.toLowerCase().trim();
    if (!normalizedQuery) return matchesCategory;

    const matchesTitle = item.title.toLowerCase().includes(normalizedQuery);
    const matchesLyrics = item.lyrics ? item.lyrics.toLowerCase().includes(normalizedQuery) : false;

    return matchesCategory && (matchesTitle || matchesLyrics);
  });

  // Helper helper to split items by sections
  const getItemsForSection = (sec: string) => {
    return filteredItems.filter((i) => i.category === sec);
  };

  const activeThemeConfig = PHYSICAL_THEMES.find((t) => t.id === currentTheme) || PHYSICAL_THEMES[0];

  return (
    <div 
      className="min-h-screen text-slate-100 font-sans relative overflow-x-hidden select-none transition-colors duration-500"
      style={{ backgroundColor: 'var(--bg-primary)' }}
    >
      <style>{`
        :root {
          --bg-primary: ${activeThemeConfig.primaryBg};
          --bg-via: ${activeThemeConfig.viaBg};
          --bg-to: ${activeThemeConfig.toBg};
          --card-bg: ${activeThemeConfig.cardBg};
          --card-border: ${activeThemeConfig.cardBorder};
          --header-bg: ${activeThemeConfig.headerBg};
          --header-border: ${activeThemeConfig.headerBorder};
          --header-hover: ${activeThemeConfig.headerHover};
          --glow-left: ${activeThemeConfig.glowLeft};
          --glow-right: ${activeThemeConfig.glowRight};
          --accent-text: ${activeThemeConfig.accentText};
          --accent-bg: ${activeThemeConfig.accentBg};
          --accent-border: ${activeThemeConfig.accentBorder};
          --badge-bg-from: ${activeThemeConfig.badgeBgFrom};
          --badge-bg-to: ${activeThemeConfig.badgeBgTo};
          --footer-bg: ${activeThemeConfig.footerBg};
          --footer-border: ${activeThemeConfig.footerBorder};
          --modal-from: ${activeThemeConfig.modalFrom};
          --modal-to: ${activeThemeConfig.modalTo};
          --modal-btn-hover: ${activeThemeConfig.modalBtnHover};
          --navbar-border: ${activeThemeConfig.navbarBorder};
          --navbar-bg: ${activeThemeConfig.navbarBg};
        }
        @keyframes marquee {
          0% { transform: translate3d(0, 0, 0); }
          100% { transform: translate3d(-50%, 0, 0); }
        }
        .animate-marquee {
          display: inline-flex;
          white-space: nowrap;
          animation: marquee var(--marquee-speed, 25s) linear infinite;
        }
        .animate-marquee:hover {
          animation-play-state: paused;
        }
      `}</style>
      
      {/* 0.5-inch (48px) supreme top letterbox boundary/mask (always empty) */}
      <div 
        className="fixed top-0 left-0 right-0 h-[48px] z-50 transition-colors duration-500 pointer-events-none"
        style={{
          background: 'linear-gradient(to bottom, var(--bg-primary) 85%, transparent)'
        }}
      />

      {/* Exquisite Radiant Glowing ambient background overlays */}
      <div 
        className="fixed inset-0 z-[-1] pointer-events-none overflow-hidden transition-all duration-500"
        style={{ background: 'linear-gradient(to bottom, var(--bg-primary), var(--bg-via), var(--bg-to))' }}
      >
        <div 
          className="absolute top-[-10%] left-[-20%] w-[80%] h-[80%] rounded-full blur-[140px] animate-pulse duration-10000 transition-all duration-500"
          style={{ backgroundColor: 'var(--glow-left)' }}
        />
        <div 
          className="absolute bottom-[-10%] right-[-25%] w-[80%] h-[80%] rounded-full blur-[150px] animate-pulse duration-[12000ms] transition-all duration-500"
          style={{ backgroundColor: 'var(--glow-right)' }}
        />
      </div>

      <AnimatePresence mode="wait">
        {showSplash ? (
          <Splash key="splash" onComplete={() => setShowSplash(false)} info={info} />
        ) : (
          <motion.div
            key="app-main"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col min-h-screen pt-[48px]"
          >
            {/* Nav assembly */}
            <Navbar
              lang={lang}
              onToggleLang={() => setLang(lang === 'bn' ? 'en' : 'bn')}
              info={info}
              notificationsCount={notificationsList.length}
              onOpenNotifications={() => setIsNotificationsOpen(true)}
            />

            {/* Scrolling Notice Marquee Bar */}
            {notice?.enabled && (notice.textBn || notice.textEn) && (
              <div 
                className="w-full bg-[#001310]/80 backdrop-blur-xs border-y border-emerald-500/10 flex items-center z-10 overflow-hidden text-xs py-2 group select-none"
                style={{
                  '--marquee-speed': `${Math.max(10, 130 - (notice.speed || 30) * 3)}s`
                } as any}
              >
                {/* Fixed Label Badge */}
                <div 
                  className="px-3 sm:px-4 py-0.5 sm:py-1 bg-gradient-to-r from-amber-500/20 to-amber-500/5 border-r border-amber-500/20 text-amber-400 font-extrabold uppercase rounded-r-lg flex items-center gap-1.5 shrink-0 z-20 shadow-sm font-sans"
                >
                  <span className="animate-pulse">📢</span>
                  <span className="text-[10px] sm:text-xs tracking-wider">{lang === 'bn' ? 'ঘোষণা:' : 'Notice:'}</span>
                </div>

                {/* Marquee Container wrapper */}
                <div className="flex-1 overflow-hidden relative flex items-center">
                  <div className="animate-marquee shrink-0 flex items-center gap-16 pr-16 text-slate-200 font-medium tracking-wide text-[11px] sm:text-xs">
                    <span>{lang === 'bn' ? (notice.textBn || notice.textEn) : (notice.textEn || notice.textBn)}</span>
                    {/* Repeated text for seamless continuous infinite horizontal looping */}
                    <span>{lang === 'bn' ? (notice.textBn || notice.textEn) : (notice.textEn || notice.textBn)}</span>
                  </div>
                </div>
              </div>
            )}

            {/* Main scroll dynamic content layout */}
            <main className="flex-1 w-full max-w-4xl mx-auto px-4 pb-24">
              
              {/* Unique Magazine/Editorial Hero Header Card */}
              <div className="relative mb-8 pt-8 overflow-hidden rounded-3xl border border-emerald-500/10 bg-gradient-to-br from-[#01201a]/45 via-[#011613]/80 to-[#000504]/90 p-6 sm:p-8 text-center shadow-2xl shadow-emerald-950/25 animate-in fade-in slide-in-from-top-4 duration-500 select-none">
                {/* Visual glowing crescent background */}
                <div className="absolute top-0 right-0 w-44 h-44 bg-amber-500/[0.02] rounded-full blur-3xl pointer-events-none" />
                <div className="absolute bottom-0 left-0 w-36 h-36 bg-teal-500/[0.01] rounded-full blur-2xl pointer-events-none" />

                {/* Visual "Welcome / স্বাগতম" Above with separate unique style */}
                <div className="flex justify-center mb-5">
                  <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gradient-to-r from-amber-500/15 via-emerald-500/10 to-amber-500/15 border border-amber-500/30 text-amber-300 font-extrabold text-xs sm:text-sm uppercase tracking-widest shadow-lg shadow-amber-500/[0.05] relative overflow-hidden group">
                    <span className="absolute inset-0 bg-gradient-to-r from-transparent via-amber-400/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 ease-in-out" />
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="font-serif italic tracking-wide">{lang === 'bn' ? '❀ স্বাগতম ❀' : '❀ WELCOME ❀'}</span>
                  </span>
                </div>

                <h2 className="text-2xl sm:text-4xl font-black tracking-tight text-slate-100 font-sans leading-tight mb-3">
                  {lang === 'bn' ? 'স্বর্গধ্বনি একাডেমি' : 'Swargadhoni Academy'}
                </h2>
                
                <p 
                  className="text-xs sm:text-sm font-black uppercase tracking-widest font-mono mb-2.5 transition-colors duration-500"
                  style={{ color: 'var(--accent-text)' }}
                >
                  {t.subtitle}
                </p>
                
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
                  
                  {/* Card 1: Utsarga */}
                  <button
                    onClick={() => setIsUtsargaOpen(true)}
                    className="group relative flex flex-row items-center gap-1.5 p-1.5 border rounded-lg transition-all duration-300 hover:translate-y-[-1px] cursor-pointer bg-gradient-to-br from-rose-950/15 via-[#011411] to-[#011e19] border-rose-500/20 hover:border-rose-500/40 active:scale-95"
                  >
                    <div className="p-1 rounded-md bg-rose-500/10 text-rose-400 group-hover:scale-110 transition-transform duration-300 flex items-center justify-center shrink-0">
                      <Heart size={12} className="fill-rose-500/15 text-rose-400" />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-[9px] sm:text-[10px] font-extrabold text-rose-300 group-hover:text-rose-100 transition-colors leading-tight">
                        {t.utsarga}
                      </span>
                      <span className="text-[7px] text-rose-500/60 font-medium font-sans leading-none mt-0.5 line-clamp-1">
                        {lang === 'bn' ? 'শ্রদ্ধাঞ্জলি' : 'Tribute'}
                      </span>
                    </div>
                  </button>

                  {/* Card 2: Lekhok */}
                  <button
                    onClick={() => setIsLekhokOpen(true)}
                    className="group relative flex flex-row items-center gap-1.5 p-1.5 border rounded-lg transition-all duration-300 hover:translate-y-[-1px] cursor-pointer bg-gradient-to-br from-[#01251f]/20 via-[#011411] to-[#011e19] border-slate-700/50 hover:border-slate-400 active:scale-95"
                  >
                    <div className="p-1 rounded-md bg-slate-500/10 text-slate-300 group-hover:scale-110 transition-transform duration-300 flex items-center justify-center shrink-0">
                      <BookOpen size={12} className="text-slate-300" />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-[9px] sm:text-[10px] font-extrabold text-slate-200 group-hover:text-white transition-colors leading-tight">
                        {t.lekhok}
                      </span>
                      <span className="text-[7px] text-slate-500 font-medium font-sans leading-none mt-0.5 line-clamp-1">
                        {lang === 'bn' ? 'পরিচিতি' : 'About'}
                      </span>
                    </div>
                  </button>

                  {/* Card 3: Student Portal */}
                  <button
                    onClick={() => setIsStudentPortalOpen(true)}
                    className="group relative flex flex-row items-center gap-1.5 p-1.5 border rounded-lg transition-all duration-300 hover:translate-y-[-1px] cursor-pointer bg-gradient-to-br from-blue-950/15 via-[#011411] to-[#011e19] border-blue-500/20 hover:border-blue-500/40 active:scale-95"
                  >
                    <div className="p-1 rounded-md bg-blue-500/10 text-blue-400 group-hover:scale-110 transition-transform duration-300 flex items-center justify-center shrink-0 relative">
                      <span className="absolute top-0.5 right-0.5 h-1 w-1 rounded-full bg-blue-400 animate-pulse" />
                      <GraduationCap size={12} className="text-blue-400" />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-[9px] sm:text-[10px] font-extrabold text-blue-300 group-hover:text-blue-100 transition-colors leading-tight">
                        {lang === 'bn' ? 'পোর্টাল' : 'Portal'}
                      </span>
                      <span className="text-[7px] text-blue-500/60 font-medium font-sans leading-none mt-0.5 line-clamp-1">
                        {lang === 'bn' ? 'রেজাল্ট ও আইডি' : 'Results & ID'}
                      </span>
                    </div>
                  </button>

                  {/* Card 4: Admission */}
                  <button
                    onClick={() => setIsAdmissionOpen(true)}
                    className="group relative flex flex-row items-center gap-1.5 p-1.5 border rounded-lg transition-all duration-300 hover:translate-y-[-1px] cursor-pointer bg-gradient-to-br from-emerald-950/15 via-[#011411] to-[#011e19] border-emerald-500/20 hover:border-emerald-500/40 active:scale-95"
                  >
                    <div className="p-1 rounded-md bg-emerald-500/10 text-emerald-400 group-hover:scale-110 transition-transform duration-300 flex items-center justify-center shrink-0">
                      <UserPlus size={12} className="text-emerald-400" />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-[9px] sm:text-[10px] font-extrabold text-emerald-300 group-hover:text-emerald-100 transition-colors leading-tight">
                        {lang === 'bn' ? 'ভর্তি' : 'Admission'}
                      </span>
                      <span className="text-[7px] text-emerald-500/60 font-medium font-sans leading-none mt-0.5 line-clamp-1">
                        {lang === 'bn' ? 'আবেদন' : 'Apply'}
                      </span>
                    </div>
                  </button>

                  {/* Card 5: App Download */}
                  <button
                    onClick={() => setIsAppDownloadOpen(true)}
                    className="group relative flex flex-row items-center gap-1.5 p-1.5 border rounded-lg transition-all duration-300 hover:translate-y-[-1px] cursor-pointer bg-gradient-to-br from-amber-950/15 via-[#011411] to-[#011e19] border-amber-500/20 hover:border-amber-500/40 active:scale-95"
                  >
                    <div className="p-1 rounded-md bg-amber-500/10 text-amber-400 group-hover:scale-110 transition-transform duration-300 flex items-center justify-center shrink-0">
                      <Smartphone size={12} className="text-amber-400" />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-[9px] sm:text-[10px] font-extrabold text-amber-300 group-hover:text-amber-100 transition-colors leading-tight">
                        {lang === 'bn' ? 'অ্যাপ' : 'App'}
                      </span>
                      <span className="text-[7px] text-amber-500/60 font-medium font-sans leading-none mt-0.5 line-clamp-1">
                        {lang === 'bn' ? 'ডাউনলোড' : 'Download'}
                      </span>
                    </div>
                  </button>

                </div>
              </div>

              {info.showContactBar !== false && (() => {
                const displayContactPhone = info.contactPhone || "";
                const displayContactWhatsapp = info.contactWhatsapp || "";
                const displayContactFacebook = info.contactFacebook || "";
                
                if (!displayContactPhone && !displayContactWhatsapp && !displayContactFacebook) return null;

                return (
                  <div className="w-full mb-3 bg-gradient-to-r from-emerald-950/30 via-[#011411]/60 to-emerald-950/30 border border-emerald-500/15 backdrop-blur-md rounded-xl p-1 px-3 flex flex-row items-center justify-between gap-1.5 shadow-xl shadow-emerald-950/5 animate-in fade-in slide-in-from-top-2 duration-300">
                    <div className="flex items-center gap-1.5">
                      <span className="flex h-1.5 w-1.5 relative">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                      </span>
                      <span className="text-[9px] sm:text-[10px] font-extrabold text-teal-400 uppercase tracking-wider font-sans flex items-center gap-1">
                        📞 {lang === 'bn' ? 'যোগাযোগ:' : 'Contact:'}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center justify-end gap-1.5">
                      {displayContactPhone && (
                        <a
                          href={`tel:${displayContactPhone}`}
                          className="flex items-center gap-1 px-2 py-0.5 sm:py-1 bg-[#001713] hover:bg-emerald-500 hover:text-[#011411] text-emerald-300 font-bold text-[9px] sm:text-[10px] rounded-lg border border-emerald-500/25 transition-all duration-200 cursor-pointer"
                          title={lang === 'bn' ? 'সরাসরি কল করুন' : 'Call directly'}
                        >
                          <Phone size={10} className="shrink-0 animate-pulse" />
                          <span>{displayContactPhone}</span>
                        </a>
                      )}

                      {displayContactWhatsapp && (
                        <a
                          href={displayContactWhatsapp}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1 px-2 py-0.5 sm:py-1 bg-[#25d366]/10 hover:bg-[#25d366] hover:text-[#011411] text-[#25d366] font-bold text-[9px] sm:text-[10px] rounded-lg border border-[#25d366]/20 transition-all duration-200 cursor-pointer"
                          title={lang === 'bn' ? 'হোয়াটসঅ্যাপে যোগাযোগ করুন' : 'Contact on WhatsApp'}
                        >
                          <MessageCircle size={10} className="shrink-0" />
                          <span>{lang === 'bn' ? 'হোয়াটসঅ্যাপ' : 'WhatsApp'}</span>
                        </a>
                      )}

                      {displayContactFacebook && (
                        <a
                          href={displayContactFacebook}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1 px-2 py-0.5 sm:py-1 bg-[#1877f2]/10 hover:bg-[#1877f2] hover:text-white text-[#1877f2] font-bold text-[9px] sm:text-[10px] rounded-lg border border-[#1877f2]/20 transition-all duration-200 cursor-pointer"
                          title={lang === 'bn' ? 'ফেসবুক পেজ ভিジット করুন' : 'Visit Facebook Page'}
                        >
                          <Facebook size={10} className="shrink-0" />
                          <span>{lang === 'bn' ? 'ফেসবুক' : 'Facebook'}</span>
                        </a>
                      )}
                    </div>
                  </div>
                );
              })()}

              <SearchAndFilter
                lang={lang}
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
                sections={sections}
                sectionNames={sectionNames}
                currentCategory={currentCategory}
                onSelectCategory={setCurrentCategory}
              />

              {/* Dynamic Slides Status Bar Widget */}
              {statusBarConfig?.enabled !== false && currentCategory === 'all' && !searchQuery.trim() && (
                <div className="mt-6 mb-2 animate-in fade-in duration-300">
                  <StatusBarWidget lang={lang} config={statusBarConfig} />
                </div>
              )}

              {/* Islamic Prayer Times Widget Block - Show only when enabled and 'All' category is active and no search query active */}
              {prayerTimesConfig?.showWidget !== false && currentCategory === 'all' && !searchQuery.trim() && (
                <div className="mt-6 mb-6 animate-in fade-in duration-300">
                  <PrayerTimeWidget lang={lang} prayerTimesConfig={prayerTimesConfig} />
                </div>
              )}

              {/* Islamic Medley Lists */}
              <div className="mt-6 flex flex-col gap-6">
                {sections.map((sectionKey) => {
                  const sectionItems = getItemsForSection(sectionKey);
                  if (sectionItems.length === 0) return null;

                  const isCollapsed = collapsedCategories[sectionKey] || false;
                  const sectionNamesObj = sectionNames[sectionKey];
                  const titleLabel = sectionNamesObj
                    ? lang === 'bn'
                      ? sectionNamesObj.bn
                      : sectionNamesObj.en
                    : sectionKey;

                  // Custom icon selection support for headers
                  let headerIconElement: React.ReactNode = null;
                  if (sectionNamesObj?.icon) {
                    const trimmed = sectionNamesObj.icon.trim();
                    if (
                      trimmed.startsWith('http://') ||
                      trimmed.startsWith('https://') ||
                      trimmed.startsWith('/') ||
                      trimmed.startsWith('data:image')
                    ) {
                      headerIconElement = (
                        <img
                          src={trimmed}
                          alt=""
                          className="w-5 h-5 object-cover rounded shadow-md border border-emerald-500/20"
                          referrerPolicy="no-referrer"
                        />
                      );
                    } else {
                      headerIconElement = <span className="text-base select-none">{trimmed}</span>;
                    }
                  } else {
                    let iconEmoji = '🎵';
                    if (sectionKey === 'hamd') iconEmoji = '🕌';
                    else if (sectionKey === 'nat') iconEmoji = '⭐';
                    else if (sectionKey === 'gazal') iconEmoji = '🎤';
                    else if (sectionKey === 'mankabat') iconEmoji = '📿';
                    headerIconElement = <span className="text-base select-none">{iconEmoji}</span>;
                  }

                  return (
                    <div
                      key={sectionKey}
                      className="rounded-3xl overflow-hidden transition-all duration-300 shadow-sm border"
                      style={{
                        backgroundColor: 'var(--card-bg)',
                        borderColor: 'var(--card-border)'
                      }}
                    >
                      {/* Responsive collapsible header bar with Golden counts */}
                      <div
                        onClick={() => toggleCategoryCollapse(sectionKey)}
                        className="flex justify-between items-center px-5 py-4 border-b hover:opacity-90 transition-all cursor-pointer select-none"
                        style={{
                          backgroundColor: 'var(--header-bg)',
                          borderColor: 'var(--header-border)'
                        }}
                      >
                        <div className="flex items-center gap-3">
                          <span 
                            className="text-sm text-slate-950 font-black px-2.5 py-0.5 rounded-lg font-mono"
                            style={{
                              background: 'linear-gradient(to right, var(--badge-bg-from), var(--badge-bg-to))'
                            }}
                          >
                            {sectionItems.length}
                          </span>
                          <div className="flex items-center gap-2">
                            {headerIconElement}
                            <h3 
                              className="text-base sm:text-lg font-extrabold tracking-tight transition-colors duration-500"
                              style={{ color: 'var(--accent-text)' }}
                            >
                              {titleLabel}
                            </h3>
                          </div>
                        </div>

                        <button className="text-slate-400 hover:text-white transition-colors">
                          {isCollapsed ? <ChevronDown size={18} /> : <ChevronUp size={18} />}
                        </button>
                      </div>

                      {/* Dropdown lists with premium transition */}
                      {!isCollapsed && (
                        <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5 max-h-[75vh] overflow-y-auto scrollbar-thin">
                          {sectionItems.map((item) => (
                            <ItemCard
                              key={item.id}
                              item={item}
                              lang={lang}
                              sectionNames={sectionNames}
                              onLyricsClick={triggerLyricsModal}
                              onVideoClick={(url, title) => setActiveVideo({ url, title })}
                              onShareClick={handleShareItem}
                            />
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}

                {filteredItems.length === 0 && (
                  <div className="text-center py-16">
                    <p className="text-slate-500 italic text-sm sm:text-base">{t.noItems}</p>
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery('')}
                        className="text-amber-400 hover:text-amber-300 hover:underline text-xs mt-2 cursor-pointer"
                      >
                        Reset Search
                      </button>
                    )}
                  </div>
                )}
              </div>

            </main>

            {/* Footer containing credits */}
            <footer 
              className="w-full border-t py-8 px-6 text-center select-none shrink-0"
              style={{
                backgroundColor: 'var(--footer-bg)',
                borderColor: 'var(--footer-border)'
              }}
            >
              {/* Professional live visitor counter tracking panel */}
              <div id="footer_visitor_counter" className="max-w-xs mx-auto mb-5 p-4 rounded-3xl border text-center shadow-lg hover:shadow-emerald-500/5 duration-300 transition-all flex items-center justify-between gap-4 bg-[#021f1a]/60 border-emerald-500/25 relative overflow-hidden group">
                {/* Glowing subtle background gradient */}
                <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/10 to-transparent opacity-50 group-hover:opacity-100 transition-opacity pointer-events-none" />
                
                <div className="flex items-center gap-3 relative z-10">
                  <div className="bg-emerald-500/10 border border-emerald-500/20 p-2.5 rounded-2xl text-emerald-400 relative">
                    <span className="absolute top-1 right-1 flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#10b981] opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-[#10b981]"></span>
                    </span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
                      <circle cx="9" cy="7" r="4"/>
                      <path d="M22 21v-2a4 4 0 0 0-3-3.87"/>
                      <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                    </svg>
                  </div>
                  <div className="text-left font-sans">
                    <p className="text-xs font-black text-slate-200 leading-tight">
                      {lang === 'bn' ? 'মোট ভিজিটর সংখ্যা' : 'Total App Visitors'}
                    </p>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
                      <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wide">
                        {lang === 'bn' ? 'লাইভ ট্র্যাকিং' : 'Live Tracking'}
                      </p>
                    </div>
                  </div>
                </div>
                
                {/* Odometer styled digit slots */}
                <div className="flex gap-1 relative z-10">
                  {String(visitCount).padStart(6, '0').split('').map((digit, i) => (
                    <span 
                      key={i} 
                      className="bg-[#000d0b] border border-emerald-500/20 text-emerald-400 text-xs font-mono font-black px-2 py-1 rounded-lg"
                    >
                      {digit}
                    </span>
                  ))}
                </div>
              </div>

              {/* PWA / Notification Enabler Widget */}
              <div className="max-w-xs mx-auto mb-5 p-3.5 rounded-2xl border text-center transition-all bg-[#001713]/80 border-emerald-500/25 relative overflow-hidden flex flex-col items-center gap-1.5 font-sans shadow-lg shadow-emerald-950/20">
                <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest flex items-center gap-1.5 font-mono">
                  🔔 {lang === 'bn' ? 'মোবাইল নোটিফিকেশন' : 'Mobile Push alerts'}
                </span>
                <p className="text-[10px] text-slate-300 leading-normal font-sans">
                  {lang === 'bn' 
                    ? 'এপের সকল লাইভ ঘোষণা, নোটিশ, পরীক্ষার ফলাফল ও গুরুত্বপূর্ণ নোটিফিকেশন সরাসরি ফোনে সঙ্গে সঙ্গে পেতে এটি চালু করুন।' 
                    : 'Receive instantly-emitted learning notes, live notification updates and exam grade alerts on your phone.'}
                </p>
                <button
                  onClick={handleRequestNotificationPermission}
                  className="px-4 py-2 mt-1 sm:mt-1.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 text-xs font-extrabold rounded-xl shadow-md transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
                    <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
                  </svg>
                  {lang === 'bn' ? 'অনুমতি দিন / নোটিফিকেশন অন করুন' : 'Enable Live Alerts'}
                </button>
              </div>

              <p 
                className="text-xs font-bold tracking-widest font-mono uppercase mb-1 flex items-center justify-center gap-2 transition-colors duration-500"
                style={{ color: 'var(--accent-text)' }}
              >
                <span>رَبِّ زِدْنِي عِلْمًا</span>
                <span className="text-slate-500">•</span>
                <span className="text-slate-400 font-sans tracking-normal">আল কুরআন ২০:১১৪</span>
              </p>
              <p className="text-slate-500 text-[11px] mt-1 tracking-wider uppercase">
                {t.createdBy}
              </p>
              
              <div className="mt-4 flex items-center justify-center">
                <Heart size={14} className="text-amber-500/40 animate-pulse" />
              </div>
            </footer>

            {/* MODALS RENDER GRID */}

            {/* Dedication Modal */}
            <UtsargaModal
              isOpen={isUtsargaOpen}
              onClose={() => setIsUtsargaOpen(false)}
              lang={lang}
              info={info}
            />

            {/* Author Profile Modal */}
            <LekhokModal
              isOpen={isLekhokOpen}
              onClose={() => setIsLekhokOpen(false)}
              lang={lang}
              info={info}
            />

            {/* Single Song Lyrics View Modal */}
            {activeLyricsItem && (
              <LyricsModal
                item={activeLyricsItem}
                lang={lang}
                sectionNames={sectionNames}
                onClose={() => setActiveLyricsItem(null)}
                onPlayVideo={(url, title) => setActiveVideo({ url, title })}
                onShareClick={handleShareItem}
              />
            )}

            {/* YouTube Full Video Embed Frame Modal */}
            {activeVideo && (
              <VideoModal
                url={activeVideo.url}
                title={activeVideo.title}
                lang={lang}
                onClose={() => setActiveVideo(null)}
              />
            )}

            {/* PASSCODE Modal for Administrative Authentication */}
            {isAdminAuthOpen && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
                <div className="relative w-full max-w-sm bg-gradient-to-b from-[#012d25] to-[#011411] border border-amber-500/20 p-6 sm:p-8 rounded-3xl shadow-2xl animate-in fade-in zoom-in-95 duration-200">
                  <button
                    onClick={() => {
                      setIsAdminAuthOpen(false);
                      setAuthError(null);
                    }}
                    className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center bg-[#011e19] text-slate-400 hover:text-amber-400 focus:outline-none transition-all duration-150 cursor-pointer"
                  >
                    <X size={15} />
                  </button>

                  <div className="text-center mt-3">
                    <div className="w-12 h-12 rounded-2xl bg-amber-500/10 flex items-center justify-center text-amber-400 mx-auto mb-4">
                      <Lock size={20} />
                    </div>
                    <h3 className="text-lg font-extrabold text-amber-400 tracking-tight mb-6">
                      {t.adminLogin}
                    </h3>

                    <input
                      type="password"
                      value={passwordInput}
                      onChange={(e) => {
                        setPasswordInput(e.target.value);
                        if (authError) setAuthError(null);
                      }}
                      onKeyDown={(e) => e.key === 'Enter' && handleAdminAuthSubmit()}
                      placeholder={t.adminPassword}
                      className="w-full bg-[#000d0b]/80 border border-emerald-500/15 focus:border-amber-500/50 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder-teal-600/50 outline-none text-center transition-all mb-4 focus:shadow-md focus:shadow-amber-500/5"
                    />

                    {authError && (
                      <div className="p-2.5 mb-4 text-xs font-bold text-red-400 bg-red-500/10 border border-red-500/25 rounded-xl animate-in fade-in slide-in-from-top-2 duration-200">
                        ⚠️ {authError}
                      </div>
                    )}

                    <button
                      onClick={handleAdminAuthSubmit}
                      className="w-full bg-gradient-to-r from-amber-500 to-amber-300 hover:from-amber-400 hover:to-amber-200 text-[#011412] font-bold py-3 rounded-xl text-sm transition-all focus:outline-none shadow-lg shadow-amber-500/10 active:scale-98 cursor-pointer"
                    >
                      {t.loginBtn}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Full administrative database controls dashboard */}
            {isAdminPanelOpen && (
              <AdminPanel
                isOpen={isAdminPanelOpen}
                onClose={() => setIsAdminPanelOpen(false)}
                lang={lang}
                items={items}
                sections={sections}
                sectionNames={sectionNames}
                info={info}
                currentTheme={currentTheme}
                onUpdateInfo={(updatedInfo) => {
                  setInfo(updatedInfo);
                  saveInfoToFirebase(updatedInfo);
                }}
                onAddItem={(item) => {
                  const updated = [...items, item];
                  setItems(updated);
                  saveSingleItemToFirebase(item);
                }}
                onEditItem={(updatedItem) => {
                  const updated = items.map((item) => (item.id === updatedItem.id ? updatedItem : item));
                  setItems(updated);
                  saveSingleItemToFirebase(updatedItem);
                }}
                onDeleteItem={(id) => {
                  const updated = items.filter((item) => item.id !== id);
                  setItems(updated);
                  deleteItemFromFirebase(id);
                }}
                onAddSection={(id, bn, en) => {
                  const updatedSections = [...sections, id];
                  const updatedNames = {
                    ...sectionNames,
                    [id]: { bn, en },
                  };
                  setSections(updatedSections);
                  setSectionNames(updatedNames);
                  saveSectionsToFirebase(updatedSections);
                  saveSectionNamesToFirebase(updatedNames);
                }}
                onUpdateSectionNames={(updatedNames) => {
                  setSectionNames(updatedNames);
                  saveSectionNamesToFirebase(updatedNames);
                }}
                onDeleteSection={(id) => {
                  const updatedSections = sections.filter((sec) => sec !== id);
                  const updatedItems = items.filter((item) => item.category !== id);
                  const updatedNames = { ...sectionNames };
                  delete updatedNames[id];
                  
                  setSections(updatedSections);
                  setItems(updatedItems);
                  setSectionNames(updatedNames);
                  
                  saveSectionsToFirebase(updatedSections);
                  saveItemsToFirebase(updatedItems);
                  saveSectionNamesToFirebase(updatedNames);
                }}
                onChangeTheme={(themeId) => {
                  setCurrentTheme(themeId);
                  saveThemeToFirebase(themeId);
                }}
                students={students}
                onAddStudent={handleAddStudent}
                onDeleteStudent={handleDeleteStudent}
                onUpdateStudentAttendance={handleUpdateStudentAttendance}
                onUpdateStudent={handleUpdateStudent}
                onSyncAllStudents={async () => {
                  await saveStudentsToFirebase(students);
                  localStorage.setItem('swarg_students_backup', JSON.stringify(students));
                }}
                appDownload={appDownload}
                onUpdateAppDownload={(config) => {
                  setAppDownload(config);
                  saveAppDownloadToFirebase(config);
                }}
                notice={notice}
                onUpdateNotice={(config) => {
                  setNotice(config);
                  saveNoticeToFirebase(config);
                }}
                prayerTimesConfig={prayerTimesConfig}
                onUpdatePrayerTimesConfig={(config) => {
                  setPrayerTimesConfig(config);
                  savePrayerTimesConfigToFirebase(config);
                }}
                statusBarConfig={statusBarConfig}
                onUpdateStatusBarConfig={(config) => {
                  setStatusBarConfig(config);
                  saveStatusBarConfigToFirebase(config);
                }}
                isAdmissionEnabled={isAdmissionEnabled}
                onUpdateAdmissionEnabled={(enabled) => {
                  setIsAdmissionEnabled(enabled);
                  saveAdmissionEnabledToFirebase(enabled);
                }}
                onSendBroadcastNotification={saveNotificationToFirebase}
                notificationsList={notificationsList}
                onDeleteNotification={deleteNotificationFromFirebase}
              />
            )}

            {isAdmissionOpen && (
              <StudentAdmissionModal
                isOpen={isAdmissionOpen}
                onClose={() => setIsAdmissionOpen(false)}
                lang={lang}
                students={students}
                onAddStudent={handleAddStudent}
                isAdmissionEnabled={isAdmissionEnabled}
              />
            )}

            {isStudentPortalOpen && (
              <StudentPortalModal
                isOpen={isStudentPortalOpen}
                onClose={() => setIsStudentPortalOpen(false)}
                lang={lang}
                students={students}
              />
            )}

            {isAppDownloadOpen && (
              <AppDownloadModal
                isOpen={isAppDownloadOpen}
                onClose={() => setIsAppDownloadOpen(false)}
                lang={lang}
                appDownload={appDownload}
              />
            )}

            {/* All Notifications History Modal */}
            {isNotificationsOpen && (
              <div className="fixed inset-0 z-[105] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-300 font-sans">
                <div className="relative w-full max-w-lg bg-gradient-to-b from-[#012d25] to-[#011411] border border-amber-500/30 p-5 sm:p-6 rounded-3xl shadow-2xl flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-300">
                  {/* Close button */}
                  <button
                    onClick={() => setIsNotificationsOpen(false)}
                    className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center bg-[#011e19] text-slate-400 hover:text-amber-400 transition-colors cursor-pointer"
                  >
                    <X size={15} />
                  </button>

                  {/* Header */}
                  <div className="flex items-center gap-3 border-b border-amber-500/10 pb-4 mb-4">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400 shrink-0">
                      <Bell size={20} className="animate-pulse" />
                    </div>
                    <div>
                      <h2 className="text-lg font-extrabold text-amber-100 leading-tight">
                        {lang === 'bn' ? 'সকল বিজ্ঞপ্তি ও আপডেট' : 'All Notifications & Updates'}
                      </h2>
                      <p className="text-slate-400 text-xs font-medium">
                        {lang === 'bn' ? `${notificationsList.length}টি তথ্য সংযুক্ত আছে` : `${notificationsList.length} updates published`}
                      </p>
                    </div>
                  </div>

                  {/* List Container */}
                  <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-3 scrollbar-thin max-h-[55vh]">
                    {notificationsList.length === 0 ? (
                      <div className="flex flex-col items-center justify-center py-12 text-slate-500">
                        <Bell size={40} className="text-slate-600 mb-2.5 opacity-40 animate-pulse" />
                        <p className="text-sm font-semibold">{lang === 'bn' ? 'কোনো বিজ্ঞপ্তি পাওয়া যায়নি!' : 'No notifications found!'}</p>
                      </div>
                    ) : (
                      notificationsList.map((notif) => {
                        const dateFormatted = (() => {
                          try {
                            const date = new Date(notif.createdAt);
                            if (lang === 'bn') {
                              return date.toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' }) + ' ' + date.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' });
                            } else {
                              return date.toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' }) + ' ' + date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
                            }
                          } catch (e) {
                            return '';
                          }
                        })();

                        return (
                          <div
                            key={notif.id}
                            className="p-4 rounded-2xl bg-slate-900/60 border border-amber-500/10 hover:border-amber-500/20 transition-all duration-200"
                          >
                            <div className="flex justify-between items-start gap-2 mb-1">
                              <h3 className="text-sm font-bold text-amber-300 leading-snug">
                                {lang === 'bn' ? notif.titleBn : notif.titleEn}
                              </h3>
                              <span className="text-[9px] font-medium text-slate-500 shrink-0 select-none">
                                {dateFormatted}
                              </span>
                            </div>
                            <p className="text-xs text-slate-300 leading-relaxed font-normal whitespace-pre-line">
                              {lang === 'bn' ? notif.bodyBn : notif.bodyEn}
                            </p>
                          </div>
                        );
                      })
                    )}
                  </div>

                  {/* Footer */}
                  <div className="mt-4 pt-3 border-t border-amber-500/10 flex justify-end">
                    <button
                      onClick={() => setIsNotificationsOpen(false)}
                      className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
                    >
                      {lang === 'bn' ? 'বন্ধ করুন' : 'Close'}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {toastMessage && (
              <div 
                className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[100] bg-gradient-to-r from-teal-950 to-slate-900 border border-emerald-555/35 text-white font-sans shadow-2xl rounded-2xl px-5 py-3 text-xs sm:text-sm flex items-center gap-2.5 animate-in fade-in slide-in-from-bottom-5 duration-300 max-w-[90vw] sm:max-w-md"
              >
                <CheckCircle size={16} className="text-emerald-400 shrink-0" />
                <span className="font-medium leading-tight">{toastMessage}</span>
                <button 
                  onClick={() => setToastMessage(null)} 
                  className="ml-auto shrink-0 w-5 h-5 rounded-full flex items-center justify-center bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X size={10} />
                </button>
              </div>
            )}

            {/* Real-time Broadcast Notification Modal Popup */}
            {showNotificationPopup && activeNotification && (
              <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-300 font-sans">
                <div className="relative w-full max-w-sm bg-gradient-to-b from-[#012d25] to-[#011411] border border-amber-500/30 p-6 rounded-3xl shadow-2xl animate-in zoom-in-95 duration-300">
                  <button
                    onClick={() => {
                      if (activeNotification) {
                        localStorage.setItem('swarg_last_seen_notif_id', activeNotification.id);
                      }
                      setShowNotificationPopup(false);
                      setActiveNotification(null);
                    }}
                    className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center bg-[#011e19] text-slate-400 hover:text-amber-400 transition-colors cursor-pointer"
                  >
                    <X size={15} />
                  </button>

                  <div className="text-center mt-2 font-sans">
                    <div className="w-14 h-14 rounded-full bg-gradient-to-br from-amber-500 to-yellow-300 flex items-center justify-center text-slate-950 mx-auto mb-4 animate-bounce relative">
                      <span className="absolute inset-0 rounded-full bg-amber-500/30 animate-ping" />
                      <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="animate-wiggle">
                        <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
                        <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
                      </svg>
                    </div>

                    <h3 className="text-xs font-black text-amber-400 tracking-widest uppercase mb-1 text-center font-mono">
                      📢 {lang === 'bn' ? 'নতুন ঘোষণা' : 'New Broadcast'}
                    </h3>

                    <h4 className="text-sm font-extrabold text-slate-100 mb-2.5 px-2 line-clamp-2 leading-snug">
                      {lang === 'bn' ? activeNotification.titleBn : activeNotification.titleEn}
                    </h4>

                    <div className="bg-[#000d0b]/85 border border-emerald-500/15 rounded-2xl p-4 mb-4 max-h-[140px] overflow-y-auto text-xs text-slate-300 text-center leading-relaxed font-sans scrollbar-thin">
                      {lang === 'bn' ? activeNotification.bodyBn : activeNotification.bodyEn}
                    </div>

                    <div className="flex flex-col gap-2">
                      {('Notification' in window) && Notification.permission !== 'granted' && (
                        <button
                          onClick={handleRequestNotificationPermission}
                          className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black py-2.5 rounded-xl text-xs transition-all shadow-lg shadow-emerald-500/10 active:scale-95 cursor-pointer"
                        >
                          🔔 {lang === 'bn' ? 'ফোনে নোটিফিকেশন অন করুন' : 'Enable Phone Alerts'}
                        </button>
                      )}

                      <button
                        onClick={() => {
                          if (activeNotification) {
                            localStorage.setItem('swarg_last_seen_notif_id', activeNotification.id);
                          }
                          setShowNotificationPopup(false);
                          setActiveNotification(null);
                        }}
                        className="w-full bg-[#011e19] hover:bg-[#012d25] border border-amber-500/15 hover:border-amber-500/40 text-slate-200 hover:text-amber-400 font-bold py-2.5 rounded-xl text-xs transition-all active:scale-95 cursor-pointer"
                      >
                        {lang === 'bn' ? 'ঠিক আছে' : 'OK, Close'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Onboarding Notification Setup Prompt (Ask immediately on entry) */}
            {showOnboardingPermissionPrompt && (
              <div className="fixed inset-0 z-[105] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-300 font-sans">
                <div className="relative w-full max-w-sm bg-gradient-to-b from-[#012d25] to-[#011411] border border-emerald-500/30 p-6 rounded-3xl shadow-2xl animate-in zoom-in-95 duration-300">
                  <button
                    onClick={() => setShowOnboardingPermissionPrompt(false)}
                    className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center bg-[#011e19] text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer"
                  >
                    <X size={15} />
                  </button>

                  <div className="text-center mt-2 font-sans">
                    <div className="w-14 h-14 rounded-full bg-gradient-to-br from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 mx-auto mb-4 animate-bounce relative">
                      <span className="absolute inset-0 rounded-full bg-emerald-500/30 animate-ping" />
                      <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="animate-wiggle">
                        <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
                        <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
                      </svg>
                    </div>

                    <h3 className="text-xs font-black text-emerald-400 tracking-widest uppercase mb-1 text-center font-mono">
                      🔔 {lang === 'bn' ? 'নোটিফিকেশন সেটিং' : 'Enable Live Alerts'}
                    </h3>

                    <h4 className="text-[15px] font-extrabold text-slate-100 mb-2 leading-snug px-1">
                      {lang === 'bn' ? 'নতুন গজল ও আপডেট নোটিফিকেশন' : 'Get Real-time Notifications'}
                    </h4>

                    <p className="text-xs text-slate-300 leading-relaxed font-sans mb-5 px-1">
                      {lang === 'bn' 
                        ? 'নতুন নতুন পবিত্র কালাম, হামদ-নাত, গুরুত্বপূর্ণ আপডেট এবং নোটিশ পেতে সাইট নোটিফিকেশন অনুমোদন করুন।' 
                        : 'Enable push alerts to instantly receive spiritual updates, newly compiled gazals, lyrics and urgent announcements.'}
                    </p>

                    <div className="flex flex-col gap-2">
                      <button
                        onClick={() => {
                          setShowOnboardingPermissionPrompt(false);
                          handleRequestNotificationPermission();
                        }}
                        className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black py-2.5 rounded-xl text-xs transition-all shadow-lg shadow-emerald-500/10 active:scale-95 cursor-pointer"
                      >
                        ✅ {lang === 'bn' ? 'হ্যাঁ, চালু করতে চাই' : 'Yes, Enable Notifications'}
                      </button>

                      <button
                        onClick={() => setShowOnboardingPermissionPrompt(false)}
                        className="w-full bg-[#011e19] hover:bg-[#012d25] border border-slate-700/40 text-slate-400 hover:text-slate-200 font-bold py-2.5 rounded-xl text-xs transition-all active:scale-95 cursor-pointer"
                      >
                        {lang === 'bn' ? 'পরে করবো' : 'Later / Ask Me Later'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
